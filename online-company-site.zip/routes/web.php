<?php

use App\Http\Controllers\AdminPanel\AskquestionController;
use App\Http\Controllers\AdminPanel\ServiceController;
use App\Http\Controllers\AdminPanel\SubServiceController;
use App\Http\Controllers\user\HomeController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MainController;
use App\Http\Controllers\UserPanel\UserLoginController;
use App\Http\Controllers\AdminPanel\AdminLoginController;
use App\Http\Controllers\AdminPanel\BlogsController;
use App\Http\Controllers\AdminPanel\VideosController;





Route::get('/page', function () {
    return view('page');
});




// For Home Page
Route::any('/', 'MainController@home');


// OTP VERITY
Route::post('/otp-verify', 'MainController@otpVerify');

Route::any('contact',[MainController::class,'contact']);
Route::any('about',[MainController::class,'about']);
Route::any('signup',[MainController::class,'signup'])->name('user.signup');
Route::any('privacy-policy',[MainController::class,'privacy_policy']);
Route::any('/blogs/{slug}', 'MainController@blog1');
Route::any('/contact/message', 'MainController@contactForm');

// User Dashboard
Route::any('/user/basic-details',[UserLoginController::class,'basic_details_User'])->name('image'); 
Route::any('/user/document',[UserLoginController::class,'document_User']);  
Route::any('/user/user-status',[UserLoginController::class,'status_User']); 



Route::any('/user-logout',[UserLoginController::class,'userLogout'])->name('user.logout');
Route::post('/registerOnline',[UserLoginController::class,'store']);
Route::post('/upload-profile',[UserLoginController::class,'profile_Upload']);
Route::post('/subscriber',[UserLoginController::class,'storeSubscriber']);


Route::any('admin-login',[AdminLoginController::class,'view'])->name('admin.login');   

Route::group(['prefix'=>'/'],function(){
 
// Admin Dashboard
// Route::any('/logout',[AdminLoginController::class,'logout'])->name('admin.logout');


Route::group(['middleware'=>'auth:admin'],function(){

    Route::any('/admin/logout',[AdminLoginController::class,'logout'])->name('admin.logout');
    // Route::any('/admin/login',[AdminLoginController::class,'view']);
    // Route::any('/admin/user/list-ajax',[AdminLoginController::class,'user_list'])->name('admin.list');




    Route::any('/admin/dashboard/Ajax',[AdminLoginController::class,'user_list']);

    Route::any('/admin/dashboard',[AdminLoginController::class,'login'])->name('admin.dashboard');
    









    
    
    Route::any('/admin/user/{id}',[AdminLoginController::class,'show_user'])->name('user_view');
    Route::any('/admin/user-document/{id}',[AdminLoginController::class,'show_document']);
    
    //  Blogs
    Route::any('/admin/blogs/dashboard',[BlogsController::class,'index']);
    Route::any('/admin/blogs/add-new-post',[BlogsController::class,'addNewPost']);
    Route::any('/admin/blogs/all-post-list',[BlogsController::class,'allPostList']);

    Route::any('/admin/blogs/all-post-list/Ajax',[BlogsController::class,'allPostListAjax']);

    Route::any('/admin/blogs/organisation', [BlogsController::class,'organisationManagement']);
    Route::any('/admin/blogs/sector',[BlogsController::class,'sectorManagement']);
    Route::any('/admin/blogs/tags',[BlogsController::class,'tagsManagement']);
    Route::any('/admin/blogs/add-new-post-insert',[BlogsController::class,'insertPostData']);
    Route::get('/admin/blogs/update-post-data/{post_id}',[BlogsController::class,'updatePostDetails']);
    Route::any('/admin/blogs/post-update-data',[BlogsController::class,'updatePostDetailsData']);
    Route::any('/admin/blogs/update-vacancy-data/{post_id}',[BlogsController::class,'vacancyDetailsUpdate']);
    Route::any('/admin/blogs/update-post-date-data/{post_id}',[BlogsController::class,'updatePostDates']);
    Route::any('/admin/blogs/update-post-document-data/{post_id}',[BlogsController::class,'updatePostDocumentsDetails']);
    
    Route::post('/admin/blogs/organisation/add-organisation', 'AdminPanel\BlogsController@addOrganisation');
    Route::post('/admin/blogs/organisation/add-sector', 'AdminPanel\BlogsController@addSector');
    Route::post('/admin/blogs/organisation/add-tag', 'AdminPanel\BlogsController@addtag');
    



    Route::any('/admin/subcribers/dashboard',[AdminLoginController::class,'subcribersShow']);


    // Route::any('/admin/subscriber/list',[AdminLoginController::class,'subscriber_list']);

    Route::any('/admin/subcribers/dashboard/Ajax',[AdminLoginController::class,'subscriber_list']);
    
    



    //  Videos
    Route::any('/admin/videos/dashboard',[VideosController::class,'index']);
    Route::any('/admin/videos/all-post-list',[VideosController::class,'allVideoList']);

    Route::any('/admin/videos/all-post-list/Ajax',[VideosController::class,'allVideoListAjax']);

    Route::any('/admin/videos/add-new-post',[VideosController::class,'addNewvideoPost']);
    Route::any('/admin/videos/add-new-video-insert',[VideosController::class,'insertvideoData']);


    Route::any('/admin/videos/post-update-data',[VideosController::class,'updatePostDetailsData']);

    
    Route::get('/admin/videos/update-post-data/{video_id}',[VideosController::class,'updateVideoDetails']);
    Route::any('/admin/videos/update-post-data',[VideosController::class,'allVideoList']);
    Route::any('/admin/subcribers/dashboard',[AdminLoginController::class,'subcribersShow']);
    Route::any('/admin/subscriber/list-ajax',[AdminLoginController::class,'subscriber_list']);
    
    // our Services
    Route::any('/admin/addservice',[ServiceController::class,'adddata'])->name('admin.addservice');


    Route::get('/admin/homeservice',[ServiceController::class,'index'])->name('admin.showservice');

    Route::get('/admin/homeservice/Ajax',[ServiceController::class,'indexdata']);


    Route::any('/admin/servicedelete/{id}',[ServiceController::class,'delete'])->name('admin.service_delete');




    
    
    // sub services
    Route::any('/admin/addsubservice',[SubServiceController::class,'create'])->name('admin.addsubservice');

    Route::get('/admin/subhomeservice',[SubServiceController::class,'index'])->name('admin.showsubservice');

    Route::get('/admin/subhomeservice/Ajax',[SubServiceController::class,'indexdata']);



    Route::any('/delete_subservice/{id}',[SubServiceController::class,'deletesubservice'])->name('admin.subservices_delete');
    Route::get('/subservice/edit/{id}',[SubServiceController::class,'subserviceedit'])->name('admin.subservice_edit');
    
    Route::post('/admin/subservicve_update/{id}', [SubServiceController::class, 'subserviceupdate'])->name('admin.subservice_update');
    
    Route::any('/admin/addview',[HomeController::class,'create'])->name('admin.addview');
    Route::get('/admin/homeview',[HomeController::class,'index'])->name('admin.homeview');
    
    // web.php
    // Route:Route::get('/show-data/{homeViewId}', [HomeController::class, 'showData']);
    
    
    //ask question
    
    Route::any('/admin/ask_question',[AskquestionController::class,'askquestion'])->name('admin.ask_question');
    Route::get('/admin/ask_home',[AskquestionController::class,'index'])->name('admin.home_question');

    Route::get('/admin/ask_home/Ajax',[AskquestionController::class,'indexdata']);


    
    Route::get('/ask/edit/{id}',[AskquestionController::class,'edit'])->name('admin.question_edit');
    Route::post('/{id}',[AskquestionController::class,'update'])->name('admin.question_update');
    Route::any('/delete_question/{id}',[AskquestionController::class,'delete'])->name('admin.question_delete');
    
    //home services(view page)
    
    // Route::any('/gstregister/{id}',[HomeController::class,'gstregister']);
    // route::get('/{SubCategorySlug}',[HomeController::class,'gstregister'])->name('front.user');
    // route::get('/{SubCategorySlug}',[HomeController::class,'gstregister'])->name('front.user');
    route::get('/admin/viewpage',[HomeController::class,'viewpage'])->name('admin.view');
    
    Route::any('/delete_product/{id}',[HomeController::class,'delete'])->name('admin.product_delete');
    Route::get('/home/{id}/edit',[HomeController::class,'edit'])->name('admin.product_edit');
    // Route::post('/{id}',[HomeController::class,'update'])->name('admin.product_update');
    Route::post('/admin/home_update/{id}', [HomeController::class, 'update'])->name('admin.product_update');
    
    
    
    
    
});


});

route::get('/{SubCategorySlug}',[HomeController::class,'gstregister'])->name('front.user');


// All Home Page VieW
Route::any('itr-filling',[MainController::class,'itr_filling']);
Route::any('company-registration',[MainController::class,'company_registration']);
Route::any('corporate-compliance',[MainController::class,'corporate_compliance']);
Route::any('convert-business',[MainController::class,'convert_business']);
Route::any('shop-registration',[MainController::class,'shop_registration']);
Route::any('labour-compliance',[MainController::class,'labour_compliance']);
Route::any('gst-taxs',[MainController::class,'gst_taxs']);
Route::any('licenses',[MainController::class,'licenses']);
// Route::any('contact',[MainController::class,'contact']);
// Route::any('about',[MainController::class,'about']);
// Route::any('signup',[MainController::class,'signup'])->name('user.signup');
// Route::any('privacy-policy',[MainController::class,'privacy_policy']);
// Route::any('/blogs/{slug}', 'MainController@blog1');
// Route::any('/contact/message', 'MainController@contactForm');
Route::any('oc-professional',[MainController::class,'oc_professional']);









