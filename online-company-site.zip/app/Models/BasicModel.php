<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;


class BasicModel extends Model
{
    // 
    protected $connection = 'convocation';




    public function allbloglistdata($fields , $start , $limit, $search  )
{


  $dataArray = array(
      'total_count'=> 0,
      'data'=> array()
  );
   
  $fields_str  = implode(',',$fields);  
  

    $testCount = DB::connection($this->connection)->select("SELECT count(*) as total_posts FROM post_details $search");
 
 
      $testCountArray = json_decode(json_encode((array) $testCount), true);
    
      
      $testData = DB::connection($this->connection)->select("SELECT $fields_str FROM post_details
      $search limit  $start , $limit ");
  
      $testDataArray = json_decode(json_encode((array) $testData), true);



if(isset($testDataArray) && count($testDataArray)>0)
{
  $dataArray = array(
      'total_count'=> $testCountArray[0]['total_posts'],
      'data'=> $testDataArray,
      'summary'=> ''
  );

  return $dataArray;
}
else
{
return $dataArray;
}







}



    public function organisationList()
    {
        $organisationData = DB::connection($this->connection)->select("select * From post_organisation");
        $organisationDataArray = json_decode(json_encode((array) $organisationData), true);
    
        if (isset($organisationDataArray) && count($organisationDataArray) > 0) {
          return $organisationDataArray;
        } else {
          return $organisationDataArray;
        }
    }

    public function sectorList()
    {
        $sectorData = DB::connection($this->connection)->select("select * From post_sector");
        $sectorDataArray = json_decode(json_encode((array) $sectorData), true);
    
        if (isset($sectorDataArray) && count($sectorDataArray) > 0) {
          return $sectorDataArray;
        } else {
          return $sectorDataArray;
        }
    }

    public function tagsList()
    {
      $tagsData = DB::connection($this->connection)->select("select * From post_tags");
      $tagsDataArray = json_decode(json_encode((array) $tagsData), true);
      return $tagsDataArray;
  
    }

    public function durationList()
    {
        $typeData = DB::connection($this->connection)->select("select * From post_duration");
        $typeDataArray = json_decode(json_encode((array) $typeData), true);
    
        if (isset($typeDataArray) && count($typeDataArray) > 0) {
          return $typeDataArray;
        } else {
          return $typeDataArray;
        }
    }

    public function getRecentBlogs()
    {
        $recentBlogs = DB::connection($this->connection)->select("SELECT * , DATE_FORMAT( `post_create_date` , '%b %e' ) as post_date, DATE_FORMAT( `post_create_date` , '%h:%i %p' ) as post_time from post_details order by post_id desc limit 3");
    
        $recentBlogsData = json_decode(json_encode((array) $recentBlogs), true);
        //print_r($recentBlogsData);die;
        return $recentBlogsData;
    }

    public function getRecentvideos()
    {
        $recentvideoposts = DB::connection($this->connection)->select("SELECT * , DATE_FORMAT( `post_create_date` , '%b %e' ) as post_date, DATE_FORMAT( `post_create_date` , '%h:%i %p' ) as post_time from video_posts order by post_id desc limit 3");
    
        $recentBlogsData = json_decode(json_encode((array) $recentvideoposts), true);
        //print_r($recentBlogsData);die;
        return $recentBlogsData;
    }

    public function allvideoposts()
    {
        $allvideoposts = DB::connection($this->connection)->select("select * From post_details");
    
        $allvideopostsarr = json_decode(json_encode((array) $allvideoposts), true);
        //print_r($recentBlogsData);die;
        return $allvideopostsarr;
    }

    public function allJobList()
    {
        $organisationData = DB::connection($this->connection)->select("select * From post_details");
       // $organisationData =DB::connection($this->connection)->select("SELECT * , DATE_FORMAT( `post_create_date` , '%b %e' ) as post_date, DATE_FORMAT( `post_create_date` , '%h:%i %p' ) as post_time from post_details order by post_id desc limit 3");
        $organisationDataArray = json_decode(json_encode((array) $organisationData), true);
    
        if (isset($organisationDataArray) && count($organisationDataArray) > 0) {
          return $organisationDataArray;
        } else {
          return $organisationDataArray;
        }
    }

    public function updatePostStatus($post_id, $dataArray)
    {
      $status_update= DB::connection($this->connection)->table("post_details")->where("post_id" , $post_id)->update($dataArray);
      return true;
    }

    public function getPostDetails($post_id)
    {
      $postDetails = DB::connection($this->connection)->select("select * from post_date_details where post_id = $post_id");
      $postDetailsArray = json_decode(json_encode((array)  $postDetails), true);
      return $postDetailsArray;
    }

    public function getPostDocumentDetails($post_id)
    {
      $postDetails = DB::connection($this->connection)->select("select * from post_document_details where post_id = $post_id");
      $postDetailsArray = json_decode(json_encode((array)  $postDetails), true);
      return $postDetailsArray;
    }

    public function addneworg($dataArray)
    {
      $org_insert =  DB::connection($this->connection)->table("post_organisation")->insertGetId($dataArray);
      return $org_insert;
    }

    public function updateOrg($dataArray)
    {
      $org_update= DB::connection($this->connection)->table("post_organisation")->where("org_id" , $dataArray['org_id'])->update($dataArray);
      return true;
    }

    public function addnewSector($dataArray)
    {
      $sector_insert =  DB::connection($this->connection)->table("post_sector")->insertGetId($dataArray);
      return $sector_insert;
    }

    public function addnewTag($dataArray)
    {
      $tag_insert =  DB::connection($this->connection)->table("post_tags")->insertGetId($dataArray);
      return $tag_insert;
    }

    public function updateSector($dataArray)
    {
      $sector_update= DB::connection($this->connection)->table("post_sector")->where("sector_id" , $dataArray['sector_id'])->update($dataArray);
      return true;
    }

    public function updateTag($dataArray)
    {
      $tag_update= DB::connection($this->connection)->table("post_tags")->where("tag_id" , $dataArray['tag_id'])->update($dataArray);
      return true;
    }


    public function addNewPostDetails($dataArray)
    {
        $slug = $dataArray['post_url'];
        $checkforexisting = DB::connection($this->connection)->select("SELECT post_id, post_url FROM post_details WHERE post_url = ?", [$slug]);
        $checkforexistingArray = json_decode(json_encode((array)$checkforexisting), true);
    
        if (isset($checkforexistingArray) && count($checkforexistingArray) > 0) {
            if ($checkforexistingArray[0]['post_url'] == $slug) {
                return $checkforexistingArray[0]['post_id'];
            }
        } else {
            $result = DB::connection($this->connection)->table("post_details")->insertGetId($dataArray);
            return $result;
        }
    }

    // public function addNewPostDetails($dataArray)
    // {

    //   $slug = $dataArray['post_url'];
    //   $checkforexisting = DB::connection($this->connection)->select("SELECT post_id , post_url FROM post_details where post_url = '$slug'");
    //   $checkforexistingArray = json_decode(json_encode((array)  $checkforexisting), true);

    //   if (isset($checkforexistingArray) && count($checkforexistingArray) > 0) {
    //       if ($checkforexistingArray[0]['post_url'] == $slug) {
    //           return $checkforexistingArray[0]['post_id'];
    //       }
    //   } else {
    //       $result = DB::connection($this->connection)->table("post_details")->insertGetId($dataArray);
    //       return $result;
    //   }
    // }

    public function updatePostDetails($dataArray)
    {
      
      $details_update= DB::connection($this->connection)->table("post_details")->where("post_id" , $dataArray['post_id'])->update($dataArray);
      return $dataArray['post_id'];
    }

    public function insertVacancyData($dataArray)
    {
      $vacancy_details_insert = DB::connection($this->connection)->table("post_vacancy_details")->insert($dataArray);
      return true;
    }

    public function updateVacancyData($dataArray)
    {
      $details_update= DB::connection($this->connection)->table("post_vacancy_details")->where("id" , $dataArray['id'])->update($dataArray);
      return $dataArray['id'];
    }

    public function deleteDateDetails($post_id)
    {
      $result =  DB::connection($this->connection)->table('post_date_details')->where('post_id', $post_id)->delete();
      return $result;
    }

    public function deleteDocumentsDetails($post_id)
    {
      $result =  DB::connection($this->connection)->table('post_document_details')->where('post_id', $post_id)->delete();
      return $result;
    }

    public function updatelastDate($post_id , $last_date_to_apply)
    {
      $post_details = DB::connection($this->connection)->select("Update post_details Set post_last_date = '$last_date_to_apply' Where post_id = $post_id");
      return true;
    }

    public function addDateDetails($dataArray)
    {
      $post_date_details = DB::connection($this->connection)->table("post_date_details")->insert($dataArray);
      return true;
    }

    public function addDocumentLinkDetails($dataArray)
    {
      $post_date_details = DB::connection($this->connection)->table("post_document_details")->insert($dataArray);
      return true;
    }

    public function updateOtherData($dataArray)
    {
      $details_update= DB::connection($this->connection)->table("post_other_details")->where("id" , $dataArray['id'])->update($dataArray);
      return $dataArray['id'];
    }

    public function insertOtherData($dataArray)
    {
      $other_details_insert = DB::connection($this->connection)->table("post_other_details")->insert($dataArray);
      return true;
    }



    public function basicDataById($post_id)
    {
      $post_details = DB::connection($this->connection)->select("select * From post_details Where post_id = $post_id");
      $post_detailsDataArray = json_decode(json_encode((array) $post_details), true);
      return $post_detailsDataArray;
    }


    public function vacancyDataById($post_id)
    {
      $post_details = DB::connection($this->connection)->select("select * From post_vacancy_details Where post_id = $post_id");
      $post_detailsDataArray = json_decode(json_encode((array) $post_details), true);
      return $post_detailsDataArray;
    }

    public function postOtherDataById($post_id)
    {
      $post_details = DB::connection($this->connection)->select("select * From post_other_details Where post_id = $post_id");
      $post_detailsDataArray = json_decode(json_encode((array) $post_details), true);
      return $post_detailsDataArray;
    }
}
