<?php

namespace App\Models;

use Eloquent;
use Illuminate\Support\Facades\DB;

class UserActivityNew extends Eloquent
{

    protected $connection = 'convocation';


    
    public function getAllowedIps()
    {
    
      $userVP = DB::connection($this->connection)->select("SELECT crm_ip from crm_allowed_ips ");
       
      $userVPData = json_decode(json_encode((array) $userVP), true);
    
      return array_column($userVPData,'crm_ip');
    
    
    }


    public function getAllFileUpload()
    {
    
      $userVP = DB::connection($this->connection)->select("SELECT * from bulk_upload_log order by upload_time desc");
       
      $userVPData = json_decode(json_encode((array) $userVP), true);
    
      return $userVPData;
    
    
    }
    
    public function updateFileUpload($dbUpdateArray)
    {
    
       DB::connection($this->connection)->table('bulk_upload_log')->insert($dbUpdateArray);
    
       return  true;
    
    
    }


    public function updateActivity($user_id , $activity )
    {

       $activity_array = array('user_id'=> $user_id , 'activity'=> $activity );


       $userEvents = DB::connection($this->connection)->select("SELECT user_id from user_activity  where user_id like '$user_id'    AND  activity  like   '$activity' ");
       
       $userEventsData = json_decode(json_encode((array) $userEvents), true);
   
       if(isset($userEventsData) && count($userEventsData) < 1)
       {


        DB::connection($this->connection)->table('user_activity')->insertGetId($activity_array);

       }

       return true;

    }



    public function fetchLiveEvents()
    {
  
  
  $dataFields = array('event' , 'event_type', 'event_link' ,
   'event_date' ,  'event_expire_date' );
  
   $currentTime = time();
  
   $dataFields_str = implode(',',$dataFields);
  
      $userEvents = DB::connection($this->connection)->select("SELECT $dataFields_str from user_events  where event_date < $currentTime    AND  event_expire_date > $currentTime ");
       
      $userEventsData = json_decode(json_encode((array) $userEvents), true);
  
  if(isset($userEventsData) && count($userEventsData)>0)
  {
      return $userEventsData;
  }
     return $userEventsData;
  
  
    }
  

  
    public function fetchActivity($user_id)
    {
  
  $dataFields = array('user_activity.activity' , 'activity_status', 'activity_date','activity_message_type','activity_message' );
  
   $currentTime = time();
  
   $dataFields_str = implode(',',$dataFields);
  
      $userVP = DB::connection($this->connection)->select("SELECT $dataFields_str from user_activity inner join activity_message on user_activity.activity = activity_message.activity  where  user_id = '$user_id' order by activity_date DESC limit 0,5");
       
      $userVPData = json_decode(json_encode((array) $userVP), true);
  
  if(isset($userVPData) && count($userVPData)>0)
  {
      return $userVPData;
  }
     return $userVPData;
  
  
    }






    public function userLoginActivity($loginActivity)
    {

 
  DB::connection($this->connection)->table('login_log')->insert($loginActivity);

 return  true;

    }



// User test logs


public function userTestStartEnvironmentDetailsLog($loginActivity)
{


DB::connection($this->connection)->table('tfh_user_test_environment')->insert($loginActivity);

return  true;

}







public function userTestStartEnvironmentDetailsLogGet($user_test_session_id , $fieldNeed)
{
// tfh_user_test_environment
$fieldNeed_str =  implode(',',$fieldNeed);
$userEnvironmentDetails = DB::connection($this->connection)->select("SELECT $fieldNeed_str from tfh_user_test_environment   where  user_test_session_id = '$user_test_session_id'");
       
$userEnvironmentDetailsData = json_decode(json_encode((array) $userEnvironmentDetails), true);

return $userEnvironmentDetailsData;

}




    public function emailLogUpdate($mailLog , $log_id)
    {

    DB::connection($this->connection)->table('user_communication_email_log')->where('email_log_id',$log_id)->update($mailLog);

    }
    
    public function emailLog($mailLog)
    {

 $log_id =    DB::connection($this->connection)->table('user_communication_email_log')->insertGetId($mailLog);

 return  $log_id;

    }


    public function smsLog($smsLog)
    {

 $log_id =    DB::connection($this->connection)->table('user_communication_sms_log')->insertGetId($smsLog);

 return  'success';

    }





    public function updateContactData($requestData)
    {

    DB::connection($this->connection)->table('contact_us')->insert($requestData);

 return  true;

    }

    

   


    
    public function updateDateForFollowupUser($user_id,$followup_mail_date)
    {

    DB::connection($this->connection)->table('user_authentication')->where('user_id',$user_id)->update($followup_mail_date);

    }


    
    public function getAllUserForFollowup($days,$user_verification_status_allowed,$dataFields)
    {
 
   $dataFields_str = implode(',',$dataFields);
  
      $user_create_date = date('Y-m-d', strtotime("-$days days"));

      $user_verification_status_allowed_str = implode("','",$user_verification_status_allowed);



      $userFollowup = DB::connection($this->connection)->select("SELECT $dataFields_str from user_authentication   where  followup_mail_date < '$user_create_date' and user_verification_status in ('$user_verification_status_allowed_str')");
       
      $userFollowupData = json_decode(json_encode((array) $userFollowup), true);
  
 
      return $userFollowupData;
  
  
    }



    public function insertOtp($otpArray)
{

 $result = DB::connection($this->connection)->table('otp_verification')->insert($otpArray);  
 return true;


}


public function otpVerify($user_contact_no,$user_otp)
{

    $responseArr = array(
        'status'=>'error',
        'message'=>''
        
        );


        $otpVerifyStatus = $this->otpVerifyNew($user_contact_no , $user_otp);
        if($otpVerifyStatus)
        {
         $responseArr = array(
            'status'=>'success',
            'message'=>''
            
            );
    
        }

        return $responseArr;


}

public function otpVerifyNew($contact_no , $otp)
{

    
$results = DB::connection($this->connection)->select("select otp_verification_id from otp_verification where  contact_no = '$contact_no' AND  otp = '$otp' ");
 
$data = json_decode(json_encode((array) $results), true);

if(isset($data) && count($data)>0)
{


return true;  
 
}
else
{

return false;

}



}



}
