<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class subpart extends Model
{

    protected $table = 'sub_parts';
    protected $primaryKey = 'id';
    protected $fillable = ['name', 'slug','title','description','title1','image1','text1','title2','image2','text2','title3','image3','text3','title4','image4','text4','title5','image5','text5','title6','image6','text6','seo_title','seo_description','seo_keywords','seo_img','status','our_id'];

    
    
    public static function storesubservice($inputArr)
    {
        $filename7 = '';
    
        if(isset($inputArr['seo_img'])) {
            $image = $inputArr['seo_img'];
            $filename7 = $image->getClientOriginalName();
            $image->move('uploads/seo', $filename7);
        }







        $filename1 = '';
    
        if(isset($inputArr['input_image1'])) {
            $image = $inputArr['input_image1'];
            $filename1 = $image->getClientOriginalName();
            $image->move('uploads', $filename1);
        }

        $filename2 = '';
    
        if(isset($inputArr['input_image2'])) {
            $image = $inputArr['input_image2'];
            $filename2 = $image->getClientOriginalName();
            $image->move('uploads', $filename2);
        }

        $filename3 = '';
    
        if(isset($inputArr['input_image3'])) {
            $image = $inputArr['input_image3'];
            $filename3 = $image->getClientOriginalName();
            $image->move('uploads', $filename3);
        }
    
        $filename4 = '';
    
        if(isset($inputArr['input_image4'])) {
            $image = $inputArr['input_image4'];
            $filename4 = $image->getClientOriginalName();
            $image->move('uploads', $filename4);
        }
    
        $filename5 = '';
    
        if(isset($inputArr['input_image5'])) {
            $image = $inputArr['input_image5'];
            $filename5 = $image->getClientOriginalName();
            $image->move('uploads', $filename5);
        }
    
        $filename6 = '';
    
        if(isset($inputArr['input_image6'])) {
            $image = $inputArr['input_image6'];
            $filename6 = $image->getClientOriginalName();
            $image->move('uploads', $filename6);
        }
    

    








    
        // Convert seo_keywords to array if it's a string
        $seoKeywords = isset($inputArr['seo_keywords']) ? $inputArr['seo_keywords'] : [];
        if (!is_array($seoKeywords)) {
            $seoKeywords = explode(',', $seoKeywords);
        }
        
        // Implode the array into a comma-separated string
        $commaSeparatedKeywords = implode(',', $seoKeywords);













        $subservice = new subpart([
            'name' => $inputArr['name'],
            'slug' => $inputArr['slug'],
            'title' => $inputArr['title'],
            'description' => $inputArr['description'],
            'title1' => $inputArr['title1'],
            'image1' => $filename1,
            'text1' => $inputArr['text1'],
            'title2' => $inputArr['title2'],
            'image2' => $filename2,
            'text2' => $inputArr['text2'],
            'title3' => $inputArr['title3'],
            'image3' => $filename3,
            'text3' => $inputArr['text3'],
            'title4' => $inputArr['title4'],
            'image4' => $filename4,
            'text4' => $inputArr['text4'],
            'title5' => $inputArr['title5'],
            'image5' => $filename5,
            'text5' => $inputArr['text5'],
            'title6' => $inputArr['title6'],
            'image6' => $filename6,
            'text6' => $inputArr['text6'],
           
            'seo_title' => $inputArr['seo_title'],
            'seo_description' => $inputArr['seo_description'], 
            'seo_keywords' => $commaSeparatedKeywords, // Store as array
            'seo_img' => $filename7,
            'status' => $inputArr['status'],
            'our_id' => $inputArr['category'],
        ]);

        $subservice->save();

        return  $subservice;
    }
    use HasFactory;

    public function home_service(){
        return $this->hasMany(subpart::class);
    }

    // public function detail()
    // {
    //     return $this->hasOne(HomeView::class,'subpart_id')->where('status', 1);
    // }
    public function detail()
    {
        return $this->hasOne(subpart::class,'id')->where('status', 1);
    }

    public function questions()
    {
        return $this->hasMany(question::class,'subpart_id');
    }

    // public function sub_service(){
    //     return $this->hasMany(question::class);
    // }





    public function getAllsubservice($fields , $start , $limit, $search  )
    {
    
      $dataArray = array(
          'total_count'=> 0,
          'data'=> array()
      );
       
      $fields_str  = implode(',',$fields);  
      
    
        $testCount = DB::connection($this->connection)->select("SELECT count(*) as total_posts FROM sub_parts $search");
     
     
          $testCountArray = json_decode(json_encode((array) $testCount), true);
        
          
          $testData = DB::connection($this->connection)->select("SELECT $fields_str FROM sub_parts
          $search limit  $start , $limit ");
      
          $testDataArray = json_decode(json_encode((array) $testData), true);
    if(isset($testDataArray) && count($testDataArray)>0)
    {
      $dataArray = array(
          'total_count'=> $testCountArray[0]['total_posts'],
          'data'=> $testDataArray,
          'summary'=> ''
      );
    
      return $dataArray;
    }
    else
    {
    return $dataArray;
    }
    }










}
