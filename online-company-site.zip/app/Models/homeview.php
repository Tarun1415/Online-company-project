<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class homeview extends Model
{
    protected $table = 'home_views';
    protected $primaryKey = 'id';
    protected $fillable = ['name', 'description','title1','image1','text1','title2','image2','text2','title3','image3','text3','title4','image4','text4','title5','image5','text5','title6','image6','text6','seo_title','seo_description','seo_keywords','status','subpart_id'];

    public static function homeview($inputArr)
    {
        $filename1 = '';
    
        if(isset($inputArr['input_image1'])) {
            $image = $inputArr['input_image1'];
            $filename1 = $image->getClientOriginalName();
            $image->move('uploads', $filename1);
        }

        $filename2 = '';
    
        if(isset($inputArr['input_image2'])) {
            $image = $inputArr['input_image2'];
            $filename2 = $image->getClientOriginalName();
            $image->move('uploads', $filename2);
        }

        $filename3 = '';
    
        if(isset($inputArr['input_image3'])) {
            $image = $inputArr['input_image3'];
            $filename3 = $image->getClientOriginalName();
            $image->move('uploads', $filename3);
        }
    
        $filename4 = '';
    
        if(isset($inputArr['input_image4'])) {
            $image = $inputArr['input_image4'];
            $filename4 = $image->getClientOriginalName();
            $image->move('uploads', $filename4);
        }
    
        $filename5 = '';
    
        if(isset($inputArr['input_image5'])) {
            $image = $inputArr['input_image5'];
            $filename5 = $image->getClientOriginalName();
            $image->move('uploads', $filename5);
        }
    
        $filename6 = '';
    
        if(isset($inputArr['input_image6'])) {
            $image = $inputArr['input_image6'];
            $filename6 = $image->getClientOriginalName();
            $image->move('uploads', $filename6);
        }
    

    
    
        // Convert seo_keywords to array if it's a string
        $seoKeywords = isset($inputArr['seo_keywords']) ? $inputArr['seo_keywords'] : [];
        if (!is_array($seoKeywords)) {
            $seoKeywords = explode(',', $seoKeywords);
        }
        
        // Implode the array into a comma-separated string
        $commaSeparatedKeywords = implode(',', $seoKeywords);
    
        $homeview = new homeview([
            'name' => $inputArr['name'],
            'description' => $inputArr['description'],
            'title1' => $inputArr['title1'],
            'image1' => $filename1,
            'text1' => $inputArr['text1'],
            'title2' => $inputArr['title2'],
            'image2' => $filename2,
            'text2' => $inputArr['text2'],
            'title3' => $inputArr['title3'],
            'image3' => $filename3,
            'text3' => $inputArr['text3'],
            'title4' => $inputArr['title4'],
            'image4' => $filename4,
            'text4' => $inputArr['text4'],
            'title5' => $inputArr['title5'],
            'image5' => $filename5,
            'text5' => $inputArr['text5'],
            'title6' => $inputArr['title6'],
            'image6' => $filename6,
            'text6' => $inputArr['text6'],
           
            'seo_title' => $inputArr['seo_title'],
            'seo_description' => $inputArr['seo_description'], 
            'seo_keywords' => $commaSeparatedKeywords, // Store as array
            'status' => $inputArr['status'],
            'subpart_id' => $inputArr['category']
        ]);
    
        $homeview->save();
    
        return $homeview;
    }
    use HasFactory;
    public function subpart()
    {
        return $this->belongsTo(subpart::class, 'subpart_id');
    }
    }
