<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;


class VdoModel extends Model
{
    // 
    protected $connection = 'convocation';




    public function allvideolistdata($fields , $start , $limit, $search  )
    {
    
    
      $dataArray = array(
          'total_count'=> 0,
          'data'=> array()
      );
       
      $fields_str  = implode(',',$fields);  
      
    
        $testCount = DB::connection($this->connection)->select("SELECT count(*) as total_posts FROM video_posts $search");
     
     
          $testCountArray = json_decode(json_encode((array) $testCount), true);
        
          
          $testData = DB::connection($this->connection)->select("SELECT $fields_str FROM video_posts
          $search limit  $start , $limit ");
      
          $testDataArray = json_decode(json_encode((array) $testData), true);
    if(isset($testDataArray) && count($testDataArray)>0)
    {
      $dataArray = array(
          'total_count'=> $testCountArray[0]['total_posts'],
          'data'=> $testDataArray,
          'summary'=> ''
      );
    
      return $dataArray;
    }
    else
    {
    return $dataArray;
    }
    }
    















  

    public function getRecentvideos()
    {
        $recentvideoposts = DB::connection($this->connection)->select("SELECT * , DATE_FORMAT( `created_date` , '%b %e' ) as created_date, DATE_FORMAT( `created_date` , '%h:%i %p' ) as created_date from video_posts order by video_id desc limit 6");
    
        $recentvideodata = json_decode(json_encode((array) $recentvideoposts), true);
        //print_r($recentBlogsData);die;
        return $recentvideodata;
    }

    public function allvideoposts()
    {
        $allvideoposts = DB::connection($this->connection)->select("select * From video_posts");
    
        $allvideopostsarr = json_decode(json_encode((array) $allvideoposts), true);
        //print_r($recentBlogsData);die;
        return $allvideopostsarr;
    }

  

    public function updatePostStatus($video_id, $dataArray)
    {
      $status_update= DB::connection($this->connection)->table("video_posts")->where("video_id" , $video_id)->update($dataArray);
      return true;
    }

    public function addNewvideoPost($dataArray)
    {

      $slug = $dataArray['video_url'];
      $checkforexisting = DB::connection($this->connection)->select("SELECT video_id , video_url FROM video_posts where video_url = '$slug'");
      $checkforexistingArray = json_decode(json_encode((array)  $checkforexisting), true);

      if (isset($checkforexistingArray) && count($checkforexistingArray) > 0) {
          if ($checkforexistingArray[0]['video_url'] == $slug) {
              return $checkforexistingArray[0]['video_id'];
          }
      } else {
          $result = DB::connection($this->connection)->table("video_posts")->insertGetId($dataArray);
          return $result;
      }
    }

    public function updatevideoPost($dataArray)
    {
      
      $details_update= DB::connection($this->connection)->table("video_posts")->where("video_id" , $dataArray['video_id'])->update($dataArray);
      return $dataArray['video_id'];
    }


   
    public function updatelastDate($video_id , $last_date_to_apply)
    {
      $post_details = DB::connection($this->connection)->select("Update video_posts Set created_date = '$last_date_to_apply' Where video_id = $video_id");
      return true;
    }

 




    public function basicDataById($video_id)
    {
      $video_details = DB::connection($this->connection)->select("select * From video_posts Where video_id = $video_id");
      $video_detailsDataArray = json_decode(json_encode((array) $video_details), true);
      return $video_detailsDataArray;
    }


    public function updatePostDetails($dataArray)
    {
      
      $details_update= DB::connection($this->connection)->table("video_posts")->where("video_id" , $dataArray['video_id'])->update($dataArray);
      return $dataArray['video_id'];
    }

    
}
