<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class our extends Model
{

    protected $table = 'ours';
    protected $primaryKey = 'id';
    protected $fillable = ['name', 'slug','image','status'];

    
    
    public static function storeservice($inputArr)
    {
        $filename = '';

        if(isset($inputArr['input_image'])) {
            $image = $inputArr['input_image'];
            $filename = $image->getClientOriginalName();
            $image->move('uploads', $filename);
        }

        $service = new our([
            'name' => $inputArr['name'],
            'slug' => $inputArr['slug'],
            'image' => $filename,
            'status' => $inputArr['status'],
        ]);

        $service->save();

        return  $service;
    }
    use HasFactory;

    public function sub_service(){
        return $this->hasMany(subpart::class);
    }




    public function getAllservice($fields , $start , $limit, $search  )
    {
    
      $dataArray = array(
          'total_count'=> 0,
          'data'=> array()
      );
       
      $fields_str  = implode(',',$fields);  
      
    
        $testCount = DB::connection($this->connection)->select("SELECT count(*) as total_posts FROM ours $search");
     
     
          $testCountArray = json_decode(json_encode((array) $testCount), true);
        
          
          $testData = DB::connection($this->connection)->select("SELECT $fields_str FROM ours
          $search limit  $start , $limit ");
      
          $testDataArray = json_decode(json_encode((array) $testData), true);
    if(isset($testDataArray) && count($testDataArray)>0)
    {
      $dataArray = array(
          'total_count'=> $testCountArray[0]['total_posts'],
          'data'=> $testDataArray,
          'summary'=> ''
      );
    
      return $dataArray;
    }
    else
    {
    return $dataArray;
    }
    }








    
    
}
