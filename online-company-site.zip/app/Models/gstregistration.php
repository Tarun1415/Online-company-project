<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class gstregistration extends Model
{
    protected $table = 'gst_registrations';
    protected $primaryKey = 'id';
    protected $fillable = ['name', 'description','title1','text1','title2','text2','title3','text3','title4','text4','title5','text5','title6','text6','image','seo_title','seo_description','seo_keywords','status'];

    public static function storegst($inputArr)
    {
        $filename = '';
    
        if(isset($inputArr['input_image'])) {
            $image = $inputArr['input_image'];
            $filename = $image->getClientOriginalName();
            $image->move('uploads', $filename);
        }
    
        // Convert seo_keywords to array if it's a string
        $seoKeywords = isset($inputArr['seo_keywords']) ? $inputArr['seo_keywords'] : [];
        if (!is_array($seoKeywords)) {
            $seoKeywords = explode(',', $seoKeywords);
        }
        
        // Implode the array into a comma-separated string
        $commaSeparatedKeywords = implode(',', $seoKeywords);
    
        $gst = new gstregistration([
            'name' => $inputArr['name'],
            'description' => $inputArr['description'],
            'title1' => $inputArr['title1'],
            'text1' => $inputArr['text1'],
            'title2' => $inputArr['title2'],
            'text2' => $inputArr['text2'],
            'title3' => $inputArr['title3'],
            'text3' => $inputArr['text3'],
            'title4' => $inputArr['title4'],
            'text4' => $inputArr['text4'],
            'title5' => $inputArr['title5'],
            'text5' => $inputArr['text5'],
            'title6' => $inputArr['title6'],
            'text6' => $inputArr['text6'],
            'image' => $filename,
            'seo_title' => $inputArr['seo_title'],
            'seo_description' => $inputArr['seo_description'], 
            'seo_keywords' => $commaSeparatedKeywords, // Store as array
            'status' => $inputArr['status'],
        ]);
    
        $gst->save();
    
        return $gst;
    }
    
    
    // public static function storegst($inputArr)
    // {
    //     $filename = '';

    //     if(isset($inputArr['input_image'])) {
    //         $image = $inputArr['input_image'];
    //         $filename = $image->getClientOriginalName();
    //         $image->move('uploads', $filename);
    //     }

    //     $gst = new gstregistration([
    //         'name' => $inputArr['name'],
    //         'description' => $inputArr['description'],
    //         'title1' => $inputArr['title1'],
    //         'text1' => $inputArr['text1'],
    //         'title2' => $inputArr['title2'],
    //         'text2' => $inputArr['text2'],
    //         'title3' => $inputArr['title3'],
    //         'text3' => $inputArr['text3'],
    //         'title4' => $inputArr['title4'],
    //         'text4' => $inputArr['text4'],
    //         'title5' => $inputArr['title5'],
    //         'text5' => $inputArr['text5'],
    //         'title6' => $inputArr['title6'],
    //         'text6' => $inputArr['text6'],
    //         'image' => $filename,
    //         'seo_title' => $inputArr['seo_title'],
    //         'seo_description' => $inputArr['seo_description'],
    //         'seo_keywords' => $inputArr['seo_keywords'],
    //         'status' => $inputArr['status'],
    //     ]);

    //     $gst->save();

    //     return  $gst;
    // }
    use HasFactory;
}
