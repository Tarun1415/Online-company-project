<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
                                                      
                                                      
                                                       
class AdminLogin extends Model
{
    use HasFactory;


   
    








    public function adminLoginCheck($postData)
    {    
        $user_email = $postData['email'];
        $user_password = $postData['password'];
                                                                                 
        dd($user_email);

        $userExistCheck = DB::table('admins')->where('email', $user_email)->first();

      if ($userExistCheck && Hash::check($user_password, $userExistCheck->password))
    {
      return view('admin.dashboard');

    }
    else{
          return back()->withErrors(['email' => 'Invalid credentials']);
      }
    }

                                                                                                                           
    public function getAllUser()
    {
        // $all_user = DB::connection($this->connection)->select("SELECT * from lead_main ");

        $testCount = DB::connection($this->connection)->select("SELECT count(lead_id) as total_user from lead_main  LEFT JOIN services ON lead_main.service_required = services.service_id ");
   
        $testCountArray = json_decode(json_encode((array) $testCount), true);
    // print_r($testCountArray);die;


        $all_user = DB::connection($this->connection)->select("SELECT * from lead_main LEFT JOIN services ON lead_main.service_required = services.service_id");

        $user_all = json_decode(json_encode((array) $all_user), true);
        // print"\n\nprint all users ";
        // print_r($user_all);
        // exit();
        if(isset($user_all) && count($user_all)>0)
{
    $dataArray = array(
        'total_count'=> $testCountArray[0]['total_user'],
        'data'=> $user_all,
        'summary'=> ''
    );

    return $dataArray;
}
else
{
//   return $dataArray;
}

    }





    public function allsublistdata($fields , $start , $limit, $search  )
    {
    
      $dataArray = array(
          'total_count'=> 0,
          'data'=> array()
      );
       
      $fields_str  = implode(',',$fields);  
      
    
        $testCount = DB::connection($this->connection)->select("SELECT count(*) as total_posts FROM subscriber $search");
     
     
          $testCountArray = json_decode(json_encode((array) $testCount), true);
        
          
          $testData = DB::connection($this->connection)->select("SELECT $fields_str FROM subscriber
          $search limit  $start , $limit ");
      
          $testDataArray = json_decode(json_encode((array) $testData), true);
    if(isset($testDataArray) && count($testDataArray)>0)
    {
      $dataArray = array(
          'total_count'=> $testCountArray[0]['total_posts'],
          'data'=> $testDataArray,
          'summary'=> ''
      );
    
      return $dataArray;
    }
    else
    {
    return $dataArray;
    }
    }





    public function AllUserget($fields , $start , $limit, $search  )
    {
    
      $dataArray = array(
          'total_count'=> 0,
          'data'=> array()
      );
       
      $fields_str  = implode(',',$fields);  
      
    
        $testCount = DB::connection($this->connection)->select("SELECT count(*) as total_posts FROM lead_main $search");
     
     
          $testCountArray = json_decode(json_encode((array) $testCount), true);
        
          
          $testData = DB::connection($this->connection)->select("SELECT $fields_str FROM lead_main
          $search limit  $start , $limit ");
      
          $testDataArray = json_decode(json_encode((array) $testData), true);
    if(isset($testDataArray) && count($testDataArray)>0)
    {
      $dataArray = array(
          'total_count'=> $testCountArray[0]['total_posts'],
          'data'=> $testDataArray,
          'summary'=> ''
      );
    
      return $dataArray;
    }
    else
    {
    return $dataArray;
    }
    }
































  

    public function getAllSubscriber()
    {
    
        $all_subscriber = DB::connection($this->connection)->select("SELECT * from subscriber");

        $subscriber_all = json_decode(json_encode((array) $all_subscriber), true);

        return $subscriber_all;

    }


    public function getUsersDetails($lead_id)
    {
        

        $basicDetails = DB::connection($this->connection)->select("SELECT * from lead_main where lead_id=$lead_id");
        $basicDetailsArray = json_decode(json_encode((array) $basicDetails), true);
      
        if(!empty($basicDetailsArray[0]['service_required']))
        {
            $basicDetailsArray[0]['service_ids'] = explode(',',$basicDetailsArray[0]['service_required']);
        }
        else
        {
            $basicDetailsArray[0]['service_ids'] = array();
        }

        // print_r($basicDetailsArray);
        // exit();

        return $basicDetailsArray;
    }



    public function getUsers($lead_id)
    {
        $all_Services = DB::connection($this->connection)->select("SELECT * from services ");
        $all_ServicesArray = json_decode(json_encode((array) $all_Services), true);
      

        return $all_ServicesArray;
      

       }






       


    public function getAllServices()
    {
        $user_service = DB::connection($this->connection)->select("SELECT * from services ");

        $user_allservices = json_decode(json_encode((array) $user_service), true);
// print_r($user_allservices);die;
        return $user_allservices;
    }

    public function getDocumentRequired($user_id)
    {
        $user_documents = DB::connection($this->connection)->select("SELECT * from lead_main where lead_id='$user_id'");
    
        if (empty($user_documents)) {
            return null; // or handle this case as needed
        }
    
        $user_alldocuments = json_decode(json_encode((array) $user_documents), true);
    
        return $user_alldocuments[0];
    }
    
    public function getUploadeDocumentRequired($user_id)
    {
        $user_documents = DB::connection($this->connection)->select("SELECT * from user_document where user_id='$user_id'");
    
        if (empty($user_documents)) {
            return null; // or handle this case as needed
        }
    
        $user_uploadeddocuments = json_decode(json_encode((array) $user_documents), true);
    
        return $user_uploadeddocuments[0];
    }

    public function getDocument()
    {

        $admin_document = DB::connection($this->connection)->select("SELECT * from documents ");
        $admin_all_document = json_decode(json_encode((array) $admin_document), true);
        return $admin_all_document;
    }


    public function storeAdminDocument($lead_id, $postData)
    {
        //  print_r($lead_id);
        //  exit();   
        $user_document = DB::connection($this->connection)->table('lead_main')->where('lead_id', $lead_id)->update($postData);

        // print_r($user_document);
        // exit();   

        return $user_document;
    }


    public function basic_Detail($lead_id, $postData)
    {
        $admin_details = DB::connection($this->connection)->table('lead_main')->where('lead_id', $lead_id)->update($postData);

        return $admin_details;
    }


    public function profilePicCheck($lead_id)
    {


        $userExistCheck = DB::connection($this->connection)->select("SELECT user_profile,lead_id from lead_main where lead_id='$lead_id'");


        $userExistCheckData = json_decode(json_encode((array) $userExistCheck), true);

         //print_r($userExistCheckData);
         //exit();

        if (count($userExistCheckData) > 0) {
            $profileImgUrl = "/upload/user/" . $lead_id . "/user-document/" . $userExistCheckData[0]['user_profile'];
        }else
        {
            $profileImgUrl = "/assets/img/avatars/default-user.png";
        }

        return $profileImgUrl;
    }




    
}
