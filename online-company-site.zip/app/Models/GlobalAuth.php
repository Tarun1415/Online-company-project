<?php

namespace App\Models;

use Eloquent;
use Illuminate\Support\Facades\DB;

class GlobalAuth extends Eloquent
{
   
protected $connection = 'convocation';



public function registerGlobalUser($globalAuth,$roleArray,$contact_no)
{

    $results = DB::connection($this->connection)->select("select id from users where contact_no = '$contact_no' ");
 
    $data = json_decode(json_encode((array) $results), true);

    if(count($data)>0)
    {

        $globalUserId = $data[0]['id'];

    }
    else{
$globalUserId = DB::connection($this->connection)->table('users')->insertGetId($globalAuth);

$roleArray['user_id'] = $globalUserId;

DB::connection($this->connection)->table('role_user')->insert($roleArray);

    }


return $globalUserId;

}



}
