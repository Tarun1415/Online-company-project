<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class question extends Model
{
    protected $table = 'questions';
    protected $primaryKey = 'id';
    protected $fillable = ['name', 'slug','description','image','status','subpart_id'];

    
    
    public static function storequestion($inputArr)
    {
        $filename = '';

        if(isset($inputArr['input_image'])) {
            $image = $inputArr['input_image'];
            $filename = $image->getClientOriginalName();
            $image->move('uploads', $filename);
        }

        $service = new question([
            'name' => $inputArr['name'],
            // 'slug' => $inputArr['slug'],
            'description' => $inputArr['description'],
            'image' => $filename,
            'subpart_id'=>$inputArr['subpart_id'],
            'status' => $inputArr['status'],
        ]);

        $service->save();

        return  $service;
    }
    use HasFactory;





    public function getAllsubservice($fields , $start , $limit, $search  )
    {
    
      $dataArray = array(
          'total_count'=> 0,
          'data'=> array()
      );
       
      $fields_str  = implode(',',$fields);  
      
    
        $testCount = DB::connection($this->connection)->select("SELECT count(*) as total_posts FROM questions $search");
     
     
          $testCountArray = json_decode(json_encode((array) $testCount), true);
        
          
          $testData = DB::connection($this->connection)->select("SELECT $fields_str FROM questions
          $search limit  $start , $limit ");
      
          $testDataArray = json_decode(json_encode((array) $testData), true);
    if(isset($testDataArray) && count($testDataArray)>0)
    {
      $dataArray = array(
          'total_count'=> $testCountArray[0]['total_posts'],
          'data'=> $testDataArray,
          'summary'=> ''
      );
    
      return $dataArray;
    }
    else
    {
    return $dataArray;
    }
    }

    
}
