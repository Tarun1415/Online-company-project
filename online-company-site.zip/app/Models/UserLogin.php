<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;


class UserLogin extends Model
{
    use HasFactory;






    
    public function store_Basic_Detail($user_id, $postData)
    {

        $user_document = DB::connection($this->connection)->table('lead_main')->where('lead_id', $user_id)->update($postData);

        return $user_document;
    }

    public function postidbyurl($url)
    {
        $postData = DB::select("select post_id From post_details where post_url = '$url'");
        $postDataArray = json_decode(json_encode((array) $postData), true);

        if (isset($postDataArray) && count($postDataArray) > 0) {
            return $postDataArray;
        } else {
            return  array();
        }
    }

    public function postbasicdetails($post_id)
{
    $postData = DB::select("select *, DATE_FORMAT( `post_create_date` , '%b %e' ) as post_date, DATE_FORMAT( `post_create_date` , '%h:%i %p' ) as post_time From post_details where post_id = $post_id");
    $postDataArray = json_decode(json_encode((array) $postData), true);
    return $postDataArray;

}


public function postOrgDetails($org_id)
{
    $postOrgData = DB::select("select * From post_organisation where org_id = $org_id");
    $postOrgDataArray = json_decode(json_encode((array) $postOrgData), true);
    return $postOrgDataArray[0];

}


public function postSectorDetails($sector_id)
{
    $postSectorData = DB::select("select * From post_sector where sector_id = $sector_id");
    $postSectorDataArray = json_decode(json_encode((array) $postSectorData), true);
    return $postSectorDataArray[0];

}

public function similarJobs($post_id)
{
  
    $postData = DB::select("select *, DATE_FORMAT( `post_create_date` , '%b %e' ) as post_date, DATE_FORMAT( `post_create_date` , '%h:%i %p' ) as post_time From post_details where post_id != $post_id AND 
    post_status = 'live'
    ORDER BY post_id DESC LIMIT 2" );
    $postDataArray = json_decode(json_encode((array) $postData), true);
    return $postDataArray;
}


public function postViewCountUpdate($post_id)
{

$userCodeInsert = DB::connection($this->connection)->update("UPDATE `post_details` SET `view_count` = `view_count` +1 WHERE post_id = $post_id");

return 'true';

}


public function postvacancydetails($post_id)
{
    $Vacancy_details = DB::select("select * From post_vacancy_details where post_id = $post_id");
    $Vacancy_detailsArray = json_decode(json_encode((array) $Vacancy_details), true);
    return $Vacancy_detailsArray;

}

    public function store_profile($user_id, $documentUpdate)
    {
        $user_document = DB::connection($this->connection)->table('lead_main')->where('lead_id', $user_id)->update($documentUpdate);
        return $user_document;
    }



    public function getAllServices()
    {
        $user_service = DB::connection($this->connection)->select("SELECT * from services ");

        $user_allservices = json_decode(json_encode((array) $user_service), true);

        return $user_allservices;
    }
    public function getUsersservices($user_id)
    {
        

        $basicDetails = DB::connection($this->connection)->select("SELECT * from lead_main where user_id=$user_id");
        $basicDetailsArray = json_decode(json_encode((array) $basicDetails), true);
      
        if(!empty($basicDetailsArray[0]['service_required']))
        {
            $basicDetailsArray[0]['service_ids'] = explode(',',$basicDetailsArray[0]['service_required']);
        }
        else
        {
            $basicDetailsArray[0]['service_ids'] = array();
        }

        // print_r($basicDetailsArray);
        // exit();

        return $basicDetailsArray;
    }

    public function getAllBlogs()
    {
        $user_blog = DB::connection($this->connection)->select("SELECT * from post_details ");

        $user_allblogs = json_decode(json_encode((array) $user_blog), true);

        return $user_allblogs;
    }

    public function getRecentBlogs()
{
    $recentBlogs = DB::connection($this->connection)->select("SELECT * , DATE_FORMAT( `post_create_date` , '%b %e' ) as post_date, DATE_FORMAT( `post_create_date` , '%h:%i %p' ) as post_time from post_details order by post_id desc limit 3");

    $recentBlogsData = json_decode(json_encode((array) $recentBlogs), true);

    return $recentBlogsData;
}

public function getRecentvideos()
    {
        $recentvideoposts = DB::connection($this->connection)->select("SELECT * , DATE_FORMAT( `created_date` , '%b %e' ) as created_date, DATE_FORMAT( `created_date` , '%h:%i %p' ) as created_date from video_posts order by video_id desc limit 6");
    
        $recentvideodata = json_decode(json_encode((array) $recentvideoposts), true);
        //print_r($recentBlogsData);die;
        return $recentvideodata;
    }
    public function getDocumentRequired($user_id)
    {
        $user_documents = DB::connection($this->connection)->select("SELECT * from lead_main where lead_id='$user_id'");
    
        if (empty($user_documents)) {
            return null; // or handle this case as needed
        }
    
        $user_alldocuments = json_decode(json_encode((array) $user_documents), true);
    
        return $user_alldocuments[0];
    }
    
    public function getUploadeDocumentRequired($user_id)
    {
        $user_documents = DB::connection($this->connection)->select("SELECT * from user_document where user_id='$user_id'");
    
        if (empty($user_documents)) {
            return null; // or handle this case as needed
        }
    
        $user_uploadeddocuments = json_decode(json_encode((array) $user_documents), true);
    
        return $user_uploadeddocuments[0];
    }
    
    public function store_user_document($user_id, $documentUpdate)
    {
        // Check if user_id is provided
        if (empty($user_id)) {
            return ['status' => 'user id is required'];
        }
    
        // Check if document already exists
        $existing_document = DB::connection($this->connection)->table('user_document')->where('user_id', $user_id)->first();
    
        if ($existing_document) {
            // Update the document
            $user_doc_update = DB::connection($this->connection)->table('user_document')->where('user_id', $user_id)->update($documentUpdate);
            return $user_doc_update;
        } else {
            // Insert new document
            $user_doc_insert = DB::connection($this->connection)->table('user_document')->insert($documentUpdate);
            return $user_doc_insert;
        }
    }
    

    // public function getDocumentRequired($user_id)
    // {
    //     $user_documents = DB::connection($this->connection)->select("SELECT * from lead_main where lead_id='$user_id'");

    //     $user_alldocuments = json_decode(json_encode((array) $user_documents), true);

    //     return $user_alldocuments[0];
    // }
    // public function getUploadeDocumentRequired($user_id)
    // {
    //     $user_documents = DB::connection($this->connection)->select("SELECT * from user_document where user_id='$user_id'");

    //     $user_uploadeddocuments = json_decode(json_encode((array) $user_documents), true);

    //     return $user_uploadeddocuments[0];
    // }


    // public function store_user_document($user_id, $documentUpdate)
    // {
    //     $user_doc_insert = DB::connection($this->connection)->table("user_document")->where('user_id', 'like', $user_id)->update($documentUpdate);


    //     // $userIDExistCheck = json_decode(json_encode((array) $userIDExistCheckData), true);

    //     if ($user_id == "") {
    //         $user_doc_insert = array(
    //             'status' => 'user exist'
    //         );
    //     } else {
    //         $user_doc_insert = DB::connection($this->connection)->table('user_document')->insert($documentUpdate);
    //     }
    //     return $user_doc_insert;
    // }



    public function loginUser($user_id)
    {

        // $data_User = DB::table('lead_main')->select('*')->where('lead_id', $user_id)->get();
        $data_User = DB::connection($this->connection)->select("SELECT * from lead_main where lead_id='$user_id'");
        $user_data = json_decode(json_encode((array) $data_User), true);
        return $user_data[0];
        
    }



    public function registerUser($dataArray)
    {
        $user_contact = $dataArray['user_contact_number'];


        $userExistCheck = DB::connection($this->connection)->select("SELECT lead_main.user_id , user_profile_status , user_contact_number from lead_main where user_contact_number like '$user_contact'");

        $userExistCheckData = json_decode(json_encode((array) $userExistCheck), true);




        if (isset($userExistCheckData) && count($userExistCheckData) > 0) {
            $loginCheckResponse = array(
                'status' => 'user exist',
                'message' => 'Already Registered ! A user with same mobile number or email is already registered',
                'user_contact_number' => $userExistCheckData[0]['user_contact_number'],
                'user_id' => $userExistCheckData[0]['user_id'],
                'user_verification_status' => $userExistCheckData[0]['user_profile_status']

            );
        } else {



            // unset($dataArray['user_password']);
            // $dataArray['user_id'] = $user_id;
            $dataArray['create_date_time'] = time();

            $userInsert = DB::connection($this->connection)->table('lead_main')->insertGetId($dataArray);

            // print_r($leadInsert);
            // exit();


            $loginCheckResponse = array(
                'status' => 'success',
                'message' => 'Contact not exist',
                'user_contact_number' => $dataArray['user_contact_number'],
                'lead_id' => $userInsert,
                'user_verification_status' => 'initial'

            );
        }
        return $loginCheckResponse;
    }


    public function loginCheck($user_name)
    {

        $loginCheckResponse = array(
            'status' => 'not-exist',
            'message' => 'User Name or Password is incorrect'
        );

        $authString = '  AND  user_profile_status in ("registration-done","profile-not-completed")';
        //$authString = '';

        $allowedStatusArray = array('registration-done', 'profile-not-completed');



        $userExistCheck = DB::connection($this->connection)->select("SELECT lead_main.user_id , user_profile_status , user_contact_number from lead_main where user_contact_number = '$user_name' ");

        $userExistCheckData = json_decode(json_encode((array) $userExistCheck), true);

        // print_r($userExistCheckData);
        // exit();

        if (isset($userExistCheckData) && count($userExistCheckData) > 0) {
            $loginCheckResponse = array(
                'status' => 'success',
                'message' => 'Contact no exist',
                'user_id' => $userExistCheckData[0]['user_id'],
                'user_verification_status' => $userExistCheckData[0]['user_profile_status']

            );

            $loginActivity = array(
                'user_type' => 'user',
                'user_contact_no' => $userExistCheckData[0]['user_contact_number'],
                'id' => $userExistCheckData[0]['user_id'],
                'login_time' => time()
            );
            // $this->userActivityNew()->userLoginActivity($loginActivity);  

        }
        return $loginCheckResponse;
    }


    public function profilePicCheck($user_id)
    {


        $userExistCheck = DB::connection($this->connection)->select("SELECT user_profile,lead_id from lead_main where lead_id='$user_id'");


        $userExistCheckData = json_decode(json_encode((array) $userExistCheck), true);


        if ($userExistCheckData > 0) {
            $profileImgUrl = "/upload/user/" . $user_id . "/user-document/" . $userExistCheckData[0]['user_profile'];
        }


        return $profileImgUrl;
    }


public function userSubcriber($postData)
{
    $user_sub_insert = DB::connection($this->connection)->table('subscriber')->insert($postData);
    $userSub = json_decode(json_encode((array) $user_sub_insert), true);

    return $userSub;
}




    public function registerCompany($postData)
    {

        // print_r($postData);
        // exit();
        $user_name = $postData['user_contact_number'];


        $loginCheckResponse = array(
            'status' => 'not-exist',
            'message' => 'User Name or Password is incorrect'
        );

        $authString = '  AND  user_profile_status in ("registration-done","profile-not-completed")';
        //$authString = '';

        $allowedStatusArray = array('registration-done', 'profile-not-completed');



        $userExistCheck = DB::connection($this->connection)->select("SELECT lead_main.lead_id , user_profile_status , user_contact_number from lead_main where user_contact_number = '$user_name' ");

        $userExistCheckData = json_decode(json_encode((array) $userExistCheck), true);



        if (isset($userExistCheckData) && count($userExistCheckData) > 0) {

            $returnArray = array(
                'user_id' => $userExistCheckData[0]['lead_id']
            );


            return $returnArray;
        } else {

            $userInsert = DB::connection($this->connection)->table('lead_main')->insertGetId($postData);



            $returnArray = array(
                'user_id' => $userInsert
            );

            return $returnArray;
        }
    }
}
