<?php
use App\Models\our;
use App\Models\question;


// function getservice(){
//     return our::orderBy('name','ASC')
//     ->with('sub_service')
//     ->where('status',1)
//     ->get();
// }

function getservice() {
    return Our::orderBy('name', 'ASC')
        ->with(['sub_service' => function($query) {
            $query->where('status', 1);
        }])
        ->where('status', 1)
        ->get();
}

// function Askquestion(){
//     return question::orderBy('name','ASC')
//     ->with('sub_service')  
//     ->where('status',1)    
//     ->get();
// }

// function Askquestion(){
//     return question::orderBy('name','ASC')
//     ->where('status',1)
//     ->get();
// }



