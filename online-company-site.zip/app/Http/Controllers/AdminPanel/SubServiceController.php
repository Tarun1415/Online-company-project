<?php

namespace App\Http\Controllers\AdminPanel;

use App\Http\Controllers\Controller;
use App\Models\our;
use Illuminate\Support\Facades\Validator; // Add this line
use App\Models\gstregistration;
use App\Models\subpart;
use App\Models\homeview;
use Illuminate\Http\Request;

use Illuminate\Validation\Rule;


class SubServiceController extends Controller
{ 
public function index(Request $request)
{
    $services = Our::where('status', '1')->get();
    $categorie = Our::where('status', '1')->orderBy('name', 'ASC')->get();

    $selectedService = $request->input('service_name');

    $categories = Subpart::select('sub_parts.*', 'ours.name as serviceName')
        ->leftJoin('ours', 'ours.id', '=', 'sub_parts.our_id')
        ->when($selectedService, function ($query, $selectedService) {
            return $query->where('ours.name', $selectedService);
        })
        ->latest('sub_parts.id')
        ->paginate(10);

    return view('admin.sub_services.subservice_home', compact('categories', 'services', 'selectedService', 'categorie'));
}



public function indexdata(Request $request)
{
    $start = $request->input('offset', 0);
    $limit = $request->input('limit', 10);
    $keyword = $request->input('search', '');

    $query = Subpart::select('sub_parts.*', 'ours.name as serviceName')
        ->leftJoin('ours', 'ours.id', '=', 'sub_parts.our_id');

    if (!empty($keyword)) {
        $query->where(function ($q) use ($keyword) {
            $q->where('sub_parts.name', 'LIKE', "%$keyword%")
              ->orWhere('ours.name', 'LIKE', "%$keyword%");
        });
    }

    $total = $query->count();
    $rows = $query->offset($start)->limit($limit)->get();
    foreach ($rows as $key => $row) {
        $rows[$key]->action = '<a class="btn btn-primary text-white" href="/subservice/edit/' . $row->id . '">Update</a>';
        
    }

    return response()->json([
        'total' => $total,
        'rows' => $rows,
        'summary' => ''
    ]);
}




// public function indexdata(Request $request)
// {
//     $fields = ['*'];

//     if ($request->method() == 'GET') {
//         $requestData = $request->all();
        
//         $start = isset($requestData['offset']) ? $requestData['offset'] : 0;
//         $limit = isset($requestData['limit']) ? $requestData['limit'] : 3000;
//         $keyword = isset($requestData['search']) ? $requestData['search'] : '';

//         $search = '';
//         if (!empty($keyword)) {
//             $search = "where name like '%$keyword%' or name like '%$keyword%'";
//         }
        
//         $userData = $this->subserviceAuth()->getAllsubservice($fields, $start, $limit, $search);
//     }

//     if (isset($userData['data']) && count($userData['data']) > 0) {
//         $i = isset($requestData['offset']) ? $requestData['offset'] + 1 : 1;

//         foreach ($userData['data'] as $key => $val) {
//             $userData['data'][$key]['action'] = '
               
//                 <a class="btn btn-primary text-white" href="/subservice/edit/' . $val['id'] . '">Update</a>';
                
                
//             $i++;
//         }
//         // <a class="btn btn-success text-white" href="/delete_subservice/' . $val['id'] . '">Delete</a>
//     }
    
//     $finalArray = [
//         'total' => $userData['total_count'],
//         'rows' => $userData['data'],
//         'summary' => ''
//     ];

//     echo json_encode($finalArray);
//     exit();
// }






























    public function create(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|unique:sub_parts,name'
           
        ]);
    
        if ($validator->fails()) {
            return response()->json([
                'success' => false,
                'errors' => $validator->errors()
            ]);
        }
            $inputArr = $request->all();                             
        // Call the static method to store the blog
            subpart::storesubservice($inputArr);
            return response()->json([
                'success' => true,
                'message' =>"Service added successfully"
            ]);
     
}




// vhi code hai alag alag slug bana rha hai

//     public function create(Request $request){
//         $validator = \Validator::make($request->all(), [
//             'name' => ['required',
//              Rule::unique('sub_parts')->where(function ($query) use ($request) {
//                 return $query->where('our_id', $request->category);
//             })
//              ]
           
//         ]);
    
//         if ($validator->fails()) {
//             return response()->json([
//                 'success' => false,
//                 'errors' => $validator->errors()
//             ]);
//         }
//         if($request->isMethod('post')){
//             $inputArr = $request->all();
//             $inputArr['slug']  = $this->getSlug($request->name);                           
//         // Call the static method to store the blog
//         subpart::storesubservice($inputArr);
//         return response()->json([
//             'success' => true,
//             'message' =>"Sub Service added successfully"
//         ]);
//         }

//         else
//         {
//         $categories = our::orderBy('name','ASC')->get();
//         $data['categories'] = $categories;
//         return view('admin.sub_services.sub_serviceadd',$data);
//         }
// }

// private function getSlug($title) {
//     $slug = \Str::slug($title);
//     $checkSlug = subpart::whereSlug($slug)->exists();
//     if ($checkSlug) {
//         $numericPrefix = 1;
//         while(1) {
//             $newSlug = $slug . "-" .  $numericPrefix++;
//             $checkSlug = subpart::whereSlug($newSlug)->exists();
//             if (!$checkSlug) {
//                 $slug =  $newSlug;
//                 break;
//             }
//         }
//     }
//     return $slug;
// }













public function subserviceedit($id, Request $request){
    $categories = subpart::find($id);
    $services = our::all();

    if (is_null($categories)) {
        return redirect()->route('admin.sub_services.subservice_home');
    } else {
        $data = compact('categories', 'services');
        return view('admin.sub_services.subservice_edit')->with($data);
    }
}



public function subserviceupdate($id,Request $request)
                  {
                    // Retrieve the course instance
                    $categories =subpart::find($id);


                    if (is_null($categories)) {
                        return response()->json([
                            'status' => false,
                            'notFound' => true,
                            'message' => 'Course not found'
                        ]);
                    }                                                                                                                                                                                                                                                                                                                                   
                    // Validate form data
                    $request->validate([
                        'name' => 'required',
                        'description' => 'required',            
                        'input_image1' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                        'input_image2' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                        'input_image3' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                        'input_image4' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                        'input_image5' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                        'input_image6' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                  
                  
                        'status' => 'required',          
                    ]);
                  
              


                













                    // Handle file upload
                    $filename1 = $categories->image1; // Default filename
                  
                    if ($request->hasFile('input_image1')) {
                        $image = $request->file('input_image1');
                        $filename1 = $image->getClientOriginalName();
                        $image->move('uploads', $filename1);
                    }
                  
                  
                    $filename2 = $categories->image2; // Default filename
                  
                    if ($request->hasFile('input_image2')) {
                        $image = $request->file('input_image2');
                        $filename2 = $image->getClientOriginalName();
                        $image->move('uploads', $filename2);
                    }
                  
                    
                    $filename3 = $categories->image3; // Default filename
                  
                    if ($request->hasFile('input_image3')) {
                        $image = $request->file('input_image3');
                        $filename3 = $image->getClientOriginalName();
                        $image->move('uploads', $filename3);
                    }
                  
                    
                    $filename4 = $categories->image4; // Default filename
                  
                    if ($request->hasFile('input_image4')) {
                        $image = $request->file('input_image4');
                        $filename4 = $image->getClientOriginalName();
                        $image->move('uploads', $filename4);
                    }
                  
                    
                    $filename5 = $categories->image5; // Default filename
                  
                    if ($request->hasFile('input_image5')) {
                        $image = $request->file('input_image5');
                        $filename5= $image->getClientOriginalName();
                        $image->move('uploads', $filename5);
                    }
                  
                    
                    $filename6 = $categories->image6; // Default filename
                  
                    if ($request->hasFile('input_image6')) {
                        $image = $request->file('input_image6');
                        $filename6 = $image->getClientOriginalName();
                        $image->move('uploads', $filename6);
                    }
                  



                    $filename7 = $categories->seo_img; // Default filename
                  
                    if ($request->hasFile('seo_img')) {
                        $image = $request->file('seo_img');
                        $filename7 = $image->getClientOriginalName();
                        $image->move('uploads/seo', $filename7);
                    }
                  








                    $seoKeywords = isset($request['seo_keywords']) ? $request['seo_keywords'] : [];
                    if (!is_array($seoKeywords)) {
                        $seoKeywords = explode(',', $seoKeywords);
                    }
                    
                    // Implode the array into a comma-separated string
                    $commaSeparatedKeywords = implode(',', $seoKeywords);
            

                    // Update course attributes
                        $categories->our_id = $request->category;
                        $categories->name = $request->name;
                        $categories->slug = $request->slug;       
                        $categories->title = $request->title;
                        $categories->description = $request->description; // Assuming you've generated the slug in the frontend.
                        $categories->title1 = $request->title1;
                        $categories->image1 = $filename1;
                        $categories->text1 = $request->text1;
                        $categories->title2 = $request->title2;
                        $categories->image2 = $filename2;
                        $categories->text2 = $request->text2;
                        $categories->title3 = $request->title3;
                        $categories->image3 = $filename3;
                        $categories->text3 = $request->text3;
                        $categories->title4 = $request->title4;
                        $categories->image4 = $filename4;
                        $categories->text4= $request->text4;
                        $categories->title5 = $request->title5;
                        $categories->image5 = $filename5;
                        $categories->text5 = $request->text5;
                        $categories->title6 = $request->title6;
                        $categories->image6 = $filename6;
                        $categories->text6 = $request->text6;
                        
                  
                        $categories->seo_title = $request->seo_title;
                        $categories->seo_description = $request->seo_description;
                        $categories->seo_keywords = $commaSeparatedKeywords;
                        $categories->seo_img = $filename7;
                        $categories->status = $request->status;
                  
                        // Save the updated course
                        $categories->save();  
                  }
                  






























                 







public function deletesubservice($id){
    $categories = subpart::find($id)->delete();
    return redirect()->back();


 }



//  private function subserviceAuth()
//  {
//    $test = new \App\Models\subpart();
//      return $test;
//  }




}