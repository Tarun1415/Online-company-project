<?php

namespace App\Http\Controllers\AdminPanel;

use Illuminate\Http\Request;
use App\Jobs\EmailSend;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Jenssegers\Agent\Agent;
use Illuminate\Support\Facades\Storage;
use App\Jobs\FollowupEmailSend;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Admin;


class BlogsController extends Controller
{


    public function index()
    {
        return view('admin.BlogManager.home');
    }


    public function addNewPost()
    {
        // if(session('id'))
        // {

        // }
        // else{
        //     return redirect('/');
        // }

        $page = "blog-add";
                     
        $organisationList =  $this->naukariAdmin()->organisationList();
        $sectorList =  $this->naukariAdmin()->sectorList();
        $durationList =  $this->naukariAdmin()->durationList();
        $tagsList =  $this->naukariAdmin()->tagsList();
           // print_r($tagsList);die;
        return view('admin.BlogManager.addNewPost', compact('organisationList', 'sectorList', 'durationList', 'tagsList', 'page'));
    }

    





    public function allPostList()
    {

        $page = "blog-list";
        // $post_list =  $this->naukariAdmin()->allJobList();
      //  print_r($post_list);die;
        return view('admin.BlogManager.allblogslist', compact('page'));
    }









    public function allPostListAjax(Request $request)
{
    $fields = ['*'];

    if ($request->method() == 'GET') {
        $requestData = $request->all();
        
        $start = isset($requestData['offset']) ? $requestData['offset'] : 0;
        $limit = isset($requestData['limit']) ? $requestData['limit'] : 3000;
        $keyword = isset($requestData['search']) ? $requestData['search'] : '';

        $search = '';
        if (!empty($keyword)) {
            $search = "where post_display_name like '%$keyword%' or post_display_name like '%$keyword%'";
        }
        
        $userData = $this->naukariAdmin()->allbloglistdata($fields, $start, $limit, $search);
        // print_r($userData);
        // exit();
    }

    if (isset($userData['data']) && count($userData['data']) > 0) {
        $i = isset($requestData['offset']) ? $requestData['offset'] + 1 : 1;

        foreach ($userData['data'] as $key => $val) {
            $userData['data'][$key]['action'] = '<a class="btn btn-success text-white" href="/admin/blogs/update-post-data/' . $val['post_id'] . '">Update</a>';
            $i++;
        }
    }
    
    $finalArray = [
        'total' => $userData['total_count'],
        'rows' => $userData['data'],
        'summary' => ''
    ];

    echo json_encode($finalArray);
    exit();
}














    public function organisationManagement()
    {
        $page = "blog-organisation";

        $organisationList =  $this->naukariAdmin()->organisationList();
        return view('admin.BlogManager.organisation', compact('organisationList', 'page'));
        $responseArray = array( 
            'status' => 'success',
            'message' => 'Successfully updated'
        );
        print_r(json_encode($responseArray));
        exit();
    }

    public function sectorManagement()
    {     
        $page = "blog-sector";
                                                                                                                                 
        $sectorList =  $this->naukariAdmin()->sectorList();
        return view('admin.BlogManager.sector', compact('sectorList', 'page'));
        
    }


    public function tagsManagement()
    {
        $page = "blog-tag";

        $tagsList =  $this->naukariAdmin()->tagsList();

        return view('admin.BlogManager.tags', compact('tagsList', 'page'));
    }

    public function showrecentblogs()
    {
        //$page = "blog-tag";

        $RecentBlogs =  $this->naukariAdmin()->getRecentBlogs();

        return view('home-sections.recent-blog-posts', compact('RecentBlogs'));
    }



    public function insertPostData(Request $request)
    {
        if ($request->isMethod('post')) {
            $dataArray = $request->all();
            $fileArray = $request->file();
            $posturl = $dataArray['post_url'];
    
            unset($dataArray['_token']);
    
            if ($request->hasFile('featured_img')) {
                $file = $fileArray['featured_img'];
                $fileExtension = $file->getClientOriginalExtension();
                $fileName = 'featured-image-' . $posturl . '.' . $fileExtension;
                $localDestination = getcwd() . '/upload/blogs/';
                $file->move($localDestination, $fileName);
                $dataArray['featured_img'] = $fileName;
            }
    
            if ($request->hasFile('seo_image')) {
                $seoFile = $fileArray['seo_image'];
                $seoFileExtension = $seoFile->getClientOriginalExtension();
                $seoFileName = 'seo-image-' . $posturl . '.' . $seoFileExtension;
                $seoLocalDestination = getcwd() . '/upload/blogs/seo';
                $seoFile->move($seoLocalDestination, $seoFileName);
                $dataArray['seo_image'] = $seoFileName;
            }
    
            // Convert seo_keywords to array if it's a string and process it
            if (isset($dataArray['seo_keywords'])) {
                $seoKeywords = $dataArray['seo_keywords'];
                if (!is_array($seoKeywords)) {
                    $seoKeywords = explode(',', $seoKeywords);
                }
                $dataArray['seo_keywords'] = implode(',', $seoKeywords); // Store as comma-separated string
            } else {
                $dataArray['seo_keywords'] = ''; // Ensure it's set even if empty
            }
    
            // Insert the data into the database
            $insertedPostId = $this->naukariAdmin()->addNewPostDetails($dataArray);
            return redirect('/admin/blogs/all-post-list');
        }
    }
    














    // public function insertPostData(Request $request)
    // {
    //     if ($request->isMethod('post')) {
    //         $dataArray = $request->all();
    //         $fileArray = $request->file();
    //         $posturl = $dataArray['post_url'];
    
    //         unset($dataArray['_token']);
    
    //         if ($request->hasFile('featured_img')) {
    //             $file = $fileArray['featured_img'];
    //             $fileExtension = $file->getClientOriginalExtension();
    //             $fileName = 'featured-image-' . $posturl . '.' . $fileExtension;
    //             $localDestination = getcwd() . '/upload/blogs/';
    //             $file->move($localDestination, $fileName);
    //             $dataArray['featured_img'] = $fileName;
    //         }
    
    //         if ($request->hasFile('seo_image')) {
    //             $seoFile = $fileArray['seo_image'];
    //             $seoFileExtension = $seoFile->getClientOriginalExtension();
    //             $seoFileName = 'seo-image-' . $posturl . '.' . $seoFileExtension;
    //             $seoLocalDestination = getcwd() . '/upload/blogs/seo';
    //             $seoFile->move($seoLocalDestination, $seoFileName);
    //             $dataArray['seo_image'] = $seoFileName;
    //         }

    
    //         $insertedPostId = $this->naukariAdmin()->addNewPostDetails($dataArray);
    //         // return redirect('/admin/blogs/update-post-data/' . $insertedPostId);
    //         return redirect('/admin/blogs/all-post-list');

            
    //     }
    // }





    
    // public function insertPostData(Request $request)
    // {
    //     if ($request->isMethod('post')) {
    //         $dataArray = $request->all();

    //         $fileArray = $request->file();

    //         $posturl = $dataArray['post_url'];

    //         unset($dataArray['_token']);


    //         $file = $fileArray['featured_img'];
    //         $document = 'featured-image';



    //         if (!empty($file)) {
    //             $fileExtension = $file->getClientOriginalExtension();
    //             $fileName = $document . '-' . $posturl . '.' . $fileExtension;

    //             $localDestination = getcwd() . '/upload/blogs/';

    //             $file->move($localDestination, $fileName);

    //             $documentUpdate = array(

    //                 $document => $fileName
    //             );
    //         }

    //         $dataArray['featured_img'] = $fileName;
    //         $insertedPostId = $this->naukariAdmin()->addNewPostDetails($dataArray);
    //         return redirect('/admin/blogs/update-post-data/' . $insertedPostId);
    //     }
    // }



    public function updatePostDetails($post_id)
    {

        $page = "blog-dashboard";

        $jobBasicData = $this->naukariAdmin()->basicDataById($post_id);
        $organisationList =  $this->naukariAdmin()->organisationList();
        $sectorList =  $this->naukariAdmin()->sectorList();
        $durationList =  $this->naukariAdmin()->durationList();
        $tagsList =  $this->naukariAdmin()->tagsList();

        return view('admin.BlogManager.dataUpdatePage', compact('jobBasicData', 'organisationList', 'sectorList', 'durationList', 'tagsList', 'page'));
    }








    public function updatePostDetailsData(Request $request)
    {
        if ($request->isMethod('post')) {
            $dataArray = $request->except('_token');
    
            // Handle featured_img file upload
            if ($request->hasFile('featured_img')) {
                $file = $request->file('featured_img');
                $fileExtension = $file->getClientOriginalExtension();
                $posturl = $dataArray['post_url'] ?? ''; // Ensure post_url exists in $dataArray
                $fileName = 'featured-image-' . $posturl . '.' . $fileExtension;
                $localDestination = public_path('/upload/blogs/'); // Use public_path for destination
                $file->move($localDestination, $fileName);
                $dataArray['featured_img'] = $fileName;
            }
    
            // Handle seo_image file upload
            if ($request->hasFile('seo_image')) {
                $seoFile = $request->file('seo_image');
                $seoFileExtension = $seoFile->getClientOriginalExtension();
                $posturl = $dataArray['post_url'] ?? ''; // Ensure post_url exists in $dataArray
                $seoFileName = 'seo-image-' . $posturl . '.' . $seoFileExtension;
                $seoLocalDestination = public_path('/upload/blogs/seo/'); // Use public_path for destination
                $seoFile->move($seoLocalDestination, $seoFileName);
                $dataArray['seo_image'] = $seoFileName;
            }
    
            // Handle SEO keywords
            if (isset($dataArray['seo_keywords']) && is_array($dataArray['seo_keywords'])) {
                $dataArray['seo_keywords'] = implode(',', $dataArray['seo_keywords']);
            }
    
            $updateGetId = $this->naukariAdmin()->updatePostDetails($dataArray);
            return redirect('/admin/blogs/update-post-data/' . $updateGetId)->with('success', 'Post details updated successfully.');
        }
    }



    // public function updatePostDetailsData(Request $request)
    // {
    //     if ($request->isMethod('post')) {
    //         $dataArray = $request->all();
    //         $fileArray = $request->file();
    //         $posturl = $dataArray['post_url'];
    
    //         unset($dataArray['_token']);
    
    //         // Handle featured_img file upload
    //         if ($request->hasFile('featured_img')) {
    //             $file = $fileArray['featured_img'];
    //             $fileExtension = $file->getClientOriginalExtension();
    //             $fileName = 'featured-image-' . $posturl . '.' . $fileExtension;
    //             $localDestination = getcwd() . '/upload/blogs/';
    //             $file->move($localDestination, $fileName);
    //             $dataArray['featured_img'] = $fileName;
    //         }
    
    //         // Handle seo_image file upload
    //         if ($request->hasFile('seo_image')) {
    //             $seoFile = $fileArray['seo_image'];
    //             $seoFileExtension = $seoFile->getClientOriginalExtension();
    //             $seoFileName = 'seo-image-' . $posturl . '.' . $seoFileExtension;
    //             $seoLocalDestination = getcwd() . '/upload/blogs/seo';
    //             $seoFile->move($seoLocalDestination, $seoFileName);
    //             $dataArray['seo_image'] = $seoFileName;
    //         }
    
    //         $updateGetId = $this->naukariAdmin()->updatePostDetails($dataArray);
    //         return redirect('/admin/blogs/update-post-data/' . $updateGetId);
    //     }
    // }
    


    // public function updatePostDetailsData(Request $request)
    // {

    //     if ($request->isMethod('post')) {
    //         $dataArray = $request->all();
    //         $fileArray = $request->file();
    //         $posturl = $dataArray['post_url'];

    //         unset($dataArray['_token']);

    //         if (isset($dataArray['featured_img'])) {
    //             $file = $fileArray['featured_img'];
    //             $document = 'featured-image';

    //             if (!empty($file)) {
    //                 $fileExtension = $file->getClientOriginalExtension();
    //                 $fileName = $document . '-' . $posturl . '.' . $fileExtension;

    //                 $localDestination = getcwd() . '/upload/blogs/';
    //                 $file->move($localDestination, $fileName);

    //                 $documentUpdate = array(

    //                     $document => $fileName
    //                 );
    //             }

    //             $dataArray['featured_img'] = $fileName;
    //         }

    //         unset($dataArray['_token']);
    //         $updateGetId = $this->naukariAdmin()->updatePostDetails($dataArray);
    //         return redirect('/admin/blogs/update-post-data/' . $updateGetId);
    //     }
    // }









    public function vacancyDetailsUpdate(Request $request, $post_id)
    {
        // if(session('partner_id') || session('cw_name'))
        //       {

        //       }
        //       else{
        //           return redirect('/login');
        //       }
        if ($request->isMethod('post')) {
            $dataArray = $request->all();
            unset($dataArray['_token']);
            unset($dataArray['files']);
            $dataArray['post_id'] = $post_id;
            // print_r($dataArray);
            // exit();
            if (!empty($dataArray['id'])) {
                $Update = $this->naukariAdmin()->updateVacancyData($dataArray);
                return redirect('/admin/blogs/update-vacancy-data/' . $post_id);
            } else {
                unset($dataArray['id']);
                $insertdata = $this->naukariAdmin()->insertVacancyData($dataArray);
                return redirect('/admin/blogs/update-vacancy-data/' . $post_id);
            }
        }

        $page = "blog-dashboard";

        $vacancyData =  $this->naukariAdmin()->vacancyDataById($post_id);

        return view('admin.BlogManager.postVacancyDetails', compact('post_id', 'vacancyData', 'page'));
    }



    public function updatePostDates(Request $request, $post_id)
    {
        // if (session('partner_id') || session('cw_name')) {
        // } else {
        //     return redirect('/login');
        // }

        $default_keys_important_dates = array(
            'notification_release' => 'Notification Release',
            'online_application_start' => 'Application Start',
            'last_date_apply_date' => 'Last Date',
            'last_date_apply_date_offline' => 'Last Date (Offline)',
            'result_date' => 'Result Date',
            'cutoff_date' => 'Cut-off Release',
            'answer_key_date' => 'Answer Key',
            'admit_card_date' => 'Admit Card',
            'last_date_to_pay_fee' => 'Aplication Fees Submited Till',
            'last_date_to_print_online_form' => 'Print Application Form Till',
            'other_date_1' => 'any other if fill here',
            'other_date_2' => 'any other if fill here',
            'other_date_3' => 'any other if fill here',
            'other_date_4' => 'any other if fill here',
            'other_date_5' => 'any other if fill here',
            'other_date_6' => 'any other if fill here',
            'other_date_7' => 'any other if fill here',
            'other_date_8' => 'any other if fill here',
        );

        if ($request->isMethod('post')) {

            $dataArray = $request->all();
            unset($dataArray['_token']);
            $postDateDataDelete =  $this->naukariAdmin()->deleteDateDetails($post_id);
            $imp_date_key_arr = array_keys($default_keys_important_dates);
            $final_arr = array();

            foreach ($imp_date_key_arr as $impd) {

                foreach ($dataArray as $dKey => $dVal) {
                    if (strpos($dKey, $impd) !== false) {
                        $dKey_str = str_replace($impd . '_', '', $dKey);
                        $final_arr[$impd][trim($dKey_str)] = trim($dVal);
                    }
                }
            }


            $previous = array(')', ' (', ' : ', '/', "1st week of ", "2nd week of ", "3rd week of ", "4th week of ", "First Week of ", "Second Week of ", "Third week of ", "Fourth week of ", "");
            $new = array('', '', ' ', '-', '1', '8', '15', '22', '1', '8', '15', '22');

            if (isset($final_arr) && count($final_arr) > 0) {
                foreach ($final_arr as $param_key => $val) {

                    if (!empty($val['value'])) {
                        $param_array = array(
                            'post_id' => $post_id,
                            'value_key' => $param_key,
                            'value_display_name' => $val[$param_key],
                            'date' => $val['value'],
                        );
//online                  

                        $postDateData =  $this->naukariAdmin()->addDateDetails($param_array);


                        if ($param_key == 'last_date_apply_date' || $param_key == 'last_date_apply_date_offline') {

                            $value1 = $val['value'];

                            if (($pos = strpos($value1, "-")) !== FALSE) {
                                $value1 = explode('-', $value1);
                            }

                            $convertedTime = strtotime(str_replace($previous, $new, $value1));
                            $convertedDate = date('d M Y', $convertedTime);

                            $insertlastdate = $this->naukariAdmin()->updatelastDate($post_id, $convertedDate);
                        }
                    }
                }


                return redirect('/admin/blogs/update-post-date-data/' . $post_id);
            }
        }


        $important_dates_array = $this->naukariAdmin()->getPostDetails($post_id);
        $important_dates_array1 = array();
        if (isset($important_dates_array) && count($important_dates_array) > 0) {
            foreach ($important_dates_array as $impD) {
                $important_dates_array1[$impD['value_key']] = $impD;
            }
        }

        $page = "blog-dashboard";

        return view('admin.BlogManager.postDateDetails', compact('post_id', 'default_keys_important_dates', 'important_dates_array1', 'page'));
    }



    public function addOrganisation(Request $request)
    {

        if ($request->isMethod('post')) {
            $dataArray = $request->all();
            unset($dataArray['_token']);
            if(!empty($dataArray['org_id']))
            {
                $Update = $this->naukariAdmin()->updateOrg($dataArray);
                $responseArray = array(
                    'status' => 'success',
                    'data' => $dataArray['org_show_name'],
                    'message' => 'Successfully updated',
                    'id'=>$dataArray['org_id']
                  );
                  print_r(json_encode($responseArray));
                  exit();
            }
           
              else {
                    unset($dataArray['org_id']);
                    $insert = $this->naukariAdmin()->addneworg($dataArray);
                    $responseArray = array(
                        'status' => 'success',
                        'data' => $dataArray['org_show_name'],
                        'message' => 'Successfully Added',
                        'id'=>$insert
                      );
                  
                      print_r(json_encode($responseArray));
                      exit();
        }
    }
       
    }



    public function addSector(Request $request)
    {
        if ($request->isMethod('post')) {
            $dataArray = $request->all();
            unset($dataArray['_token']);
            if(!empty($dataArray['sector_id']))
            {
                $Update = $this->naukariAdmin()->updateSector($dataArray);
                $responseArray = array(
                    'status' => 'success',
                    'data' => $dataArray['sector_show_name'],
                    'message' => 'Successfully updated',
                    'id'=>$dataArray['sector_id']
                  );
                  print_r(json_encode($responseArray));
                  exit();
            }
           
              else {
                    unset($dataArray['sector_id']);
                    $insert = $this->naukariAdmin()->addnewSector($dataArray);
                    $responseArray = array(
                        'status' => 'success',
                        'data' => $dataArray['sector_show_name'],
                        'message' => 'Successfully Added',
                        'id'=>$insert
                      );
                  
                      print_r(json_encode($responseArray));
                      exit();
        }
    }
       
    }



    public function addtag(Request $request)
    {
      if ($request->isMethod('post')) {
        $dataArray = $request->all();
        unset($dataArray['_token']);

        print_r($dataArray);
        exit();
        if(!empty($dataArray['tag_id']))
        {
            $Update = $this->naukariAdmin()->updateTag($dataArray);
            $responseArray = array(
                'status' => 'success',
                'data' => $dataArray['tag_show_name'],
                'message' => 'Successfully updated',
                'id'=>$dataArray['tag_id']
              );
              print_r(json_encode($responseArray));
              exit();
        }
       
          else {
                unset($dataArray['tag_id']);
                $insert = $this->naukariAdmin()->addnewTag($dataArray);
                $responseArray = array(
                    'status' => 'success',
                    'data' => $dataArray['tag_show_name'],
                    'message' => 'Successfully Added',
                    'id'=>$insert
                  );
              
                  print_r(json_encode($responseArray));
                  exit();
    }
}
    }




    public function updatePostDocumentsDetails(Request $request, $post_id)
    {

    //   if(session('partner_id') || session('cw_name'))
    //   {
      
    //   }
    //   else{
    //       return redirect('/login');
    //   }

      $default_keys_important_dates = array(
        'official_website' => 'Official Website',
        'official_notification' => 'Official Notification',
        'apply_online_link' => 'Apply Online',
        'offline_apply_link' => 'Apply Offline',
        'other_doc_any1' => 'Extra Heading',
        'other_doc_any2' => 'Extra Heading',
        'result_link' => 'Result',
        'cutoff_link' => 'Cut-off',
        'answer_key_link' => 'Answer Key',
        'admit_card_link' => 'Admit Card',
        'application_fees_payment_link_online' => 'Application Fees Link Online',   
        'application_fees_payment_link_offline' => 'Application Fees Link Offline',     
        'other_doc_1' => 'any other if fill here',
        'other_doc_2' => 'any other if fill here',
        'other_doc_3' => 'any other if fill here',        
        'other_doc_4' => 'any other if fill here',
        'other_doc_5' => 'any other if fill here',        
        'other_doc_6' => 'any other if fill here',
        );

      if ($request->isMethod('post')) {

        $dataArray = $request->all();
        unset($dataArray['_token']);
       
        $postDocumentDataDelete =  $this->naukariAdmin()->deleteDocumentsDetails($post_id);
        $imp_date_key_arr = array_keys($default_keys_important_dates);
        $final_arr = array();
  
        foreach ($imp_date_key_arr as $impd) {
  
          foreach ($dataArray as $dKey => $dVal) {
            if (strpos($dKey, $impd) !== false) {
              $dKey_str = str_replace($impd . '_', '', $dKey);
              $final_arr[$impd][trim($dKey_str)] = trim($dVal);
            }
          }
        }

        
      $previous = array(')', ' (', ' : ', '/', "1st week of ", "2nd week of ", "3rd week of ", "4th week of ", "First Week of ", "Second Week of ", "Third week of ", "Fourth week of ", "");
      $new = array('', '', ' ', '-', '1', '8', '15', '22', '1', '8', '15', '22');

      if (isset($final_arr) && count($final_arr) > 0) {
        foreach ($final_arr as $param_key => $val) {

         
          if (!empty($val['value'])) {
            $param_array = array(
              'post_id' => $post_id,
              'value_key' => $param_key,
              'value_display_name' => $val[$param_key],
              'link' => $val['value'],
            );

      $postDateData =  $this->naukariAdmin()->addDocumentLinkDetails($param_array);

        }
        }
    

          return redirect('/admin/blogs/update-post-document-data/' . $post_id);
      }

        
      }


      $important_dates_array = $this->naukariAdmin()->getPostDocumentDetails($post_id);
      $important_dates_array1 = array();
      if (isset($important_dates_array) && count($important_dates_array) > 0) {
        foreach ($important_dates_array as $impD) {
          $important_dates_array1[$impD['value_key']] = $impD;
        }
      }

      $page="blog-dashboard";

      return view('admin.BlogManager.postDocumentDetails', compact('post_id', 'default_keys_important_dates', 'important_dates_array1','page'));
    }






























    private function naukariAdmin()
    {
        $test = new \App\Models\BasicModel();
        return $test;
    }
}
