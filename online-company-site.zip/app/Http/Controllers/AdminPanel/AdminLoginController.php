<?php

namespace App\Http\Controllers\AdminPanel;

use Illuminate\Http\Request;

use App\Jobs\EmailSend;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Jenssegers\Agent\Agent;
use Illuminate\Support\Facades\Storage;
use App\Jobs\FollowupEmailSend;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\Admin;


class AdminLoginController extends Controller
{
  public function view(Request $request)
  {
    if ($request->isMethod('post')) {


      $request->validate([
        'email' => 'required|email',
        'password' => 'required'
      ]);

      if (
        Auth::guard('admin')->attempt(
          ['email' => $request->email, 'password' => $request->password],
          $request->get('remember')
        )
      ) {
        return redirect()->route('admin.dashboard');
      } else {
        return redirect()->route('admin.login')->with('error', 'either Email/password is incorrect');
      }

    }
    return view('admin.login');

  }



  public function logout(Request $request)
  {

    Auth::guard('admin')->logout();
    // $request->session()->invalidate();
    // $request->session()->regenerateToken();

    return redirect()->route('admin.login')->with('success', 'Logged out successfully');
  }



  public function login()
  {
    return view('admin.dashboard');
  }


  public function user_list(Request $request)
  {
    $fields = ['*'];

    if ($request->method() == 'GET') {
      $requestData = $request->all();

      $start = isset($requestData['offset']) ? $requestData['offset'] : 0;
      $limit = isset($requestData['limit']) ? $requestData['limit'] : 3000;
      $keyword = isset($requestData['search']) ? $requestData['search'] : '';

      $search = '';
      if (!empty($keyword)) {
        $search = "where 	user_name like '%$keyword%' or 	user_name like '%$keyword%'";
      }

      $userData = $this->adminAuth()->AllUserget($fields, $start, $limit, $search);
      // print_r($userData);
      // exit();
    }

    if (isset($userData['data']) && count($userData['data']) > 0) {
      $i = isset($requestData['offset']) ? $requestData['offset'] + 1 : 1;

      foreach ($userData['data'] as $key => $val) {
        $userData['data'][$key]['action'] = '<a class="btn btn-success text-white" href="/admin/user/' . $val['lead_id'] . '">view</a>';
        $i++;

        // $userData['data'][$key]['action'] = '<a href="/admin/user/' . $val['lead_id'] . '" class="btn-sussess">view</a>';
      }
    }

    $finalArray = [
      'total' => $userData['total_count'],
      'rows' => $userData['data'],
      'summary' => ''
    ];

    echo json_encode($finalArray);
    exit();
  }



  public function show_user(Request $request, $lead_id)
  {

    // print_r($lead_id); die;
    // exit();

    $profileImgUrl = $this->adminAuth()->profilePicCheck($lead_id);


    //for form update
    if ($request->isMethod('post')) {
      $postData = $request->all();


      $request->validate([
        'user_name' => 'required|string|max:255|regex:/^[A-Za-z ]+$/',
        'user_email' => 'required|email',
        'service_required' => 'required'
      ]);

      unset($postData['_token']);

      $array = $postData['service_required'];
      $str = implode(",", $array);
      $postData['service_required'] = $str;

      $document_data = $this->adminAuth()->basic_Detail($lead_id, $postData);


      return redirect('/admin/dashboard/');
    }

    $userBasicDetails = $this->adminAuth()->getUsersDetails($lead_id);


    $allservices = $this->adminAuth()->getUsers($lead_id);
    // print_r($userBasicDetails);
    // print_r($allservices);
    // exit();

    return view('admin.user_view', compact('allservices', 'userBasicDetails', 'lead_id', 'profileImgUrl'));
  }



  public function show_document(Request $request, $lead_id)
  {

    $profileImgUrl = $this->adminAuth()->profilePicCheck($lead_id);
    if ($request->isMethod('post')) {
      $postData = $request->all();
      // print_r($postData);
      // exit();
      unset($postData['_token']);
      $array = $postData['document_required'];
      $str = implode(",", $array);
      $postData['document_required'] = $str;

      $admin_document = $this->adminAuth()->storeAdminDocument($lead_id, $postData);

      return redirect('/admin/dashboard');
    }
    $all_document = $this->adminAuth()->getDocumentRequired($lead_id);

    $all_documentuploaded = $this->adminAuth()->getUploadeDocumentRequired($lead_id);

    $array = $all_document['document_required'];
    $str = explode(",", $array);
    $all_document['document_required'] = $str;

    $document = $this->adminAuth()->getDocument();

    // dd($document);

    return view('admin.document', compact('document', 'lead_id', 'profileImgUrl','all_document','all_documentuploaded'));
  }


  public function subcribersShow()
  {
    // $profileImgUrl = $this->adminAuth()->profilePicCheck();

    return view('admin.subscribers');
  }

  public function subscriber_list(Request $request)
  {
    $fields = ['*'];

    if ($request->method() == 'GET') {
      $requestData = $request->all();

      $start = isset($requestData['offset']) ? $requestData['offset'] : 0;
      $limit = isset($requestData['limit']) ? $requestData['limit'] : 3000;
      $keyword = isset($requestData['search']) ? $requestData['search'] : '';

      $search = '';
      if (!empty($keyword)) {
        $search = "where 	email like '%$keyword%' or 	email like '%$keyword%'";
      }

      $userData = $this->adminAuth()->allsublistdata($fields, $start, $limit, $search);
      // print_r($userData);
      // exit();
    }


    $finalArray = [
      'total' => $userData['total_count'],
      'rows' => $userData['data'],
      'summary' => ''
    ];

    echo json_encode($finalArray);
    exit();
  }

   

  private function adminAuth()
  {
    $test = new \App\Models\AdminLogin();
    return $test;
  }
}

