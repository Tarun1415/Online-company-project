<?php

namespace App\Http\Controllers\AdminPanel;

use Illuminate\Http\Request;
use App\Jobs\EmailSend;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Jenssegers\Agent\Agent;
use Illuminate\Support\Facades\Storage;
use App\Jobs\FollowupEmailSend;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Admin;


class VideosController extends Controller
{


    public function index()
    {
        return view('admin.VideoManager.home');
        
    }


    public function addNewvideoPost()
    {
        $page = "blog-add";
        return view('admin.VideoManager.addNewvideoPost', compact( 'page'));
    }

    





    public function allVideoList()
    {

        $page = "blog-list";
        // $post_list =  $this->fetchVideo()->allvideoposts();
        return view('admin.VideoManager.allvideoslist', compact('page'));
    }



    // public function allVideoListAjax(Request $request)
    // {
    //     $fields = ['*'];
    
    //     if ($request->method() == 'GET') {
    //         $requestData = $request->all();
            
    //         $start = isset($requestData['offset']) ? $requestData['offset'] : 0;
    //         $limit = isset($requestData['limit']) ? $requestData['limit'] : 3000;
    //         $keyword = isset($requestData['search']) ? $requestData['search'] : '';
    
    //         $search = '';
    //         if (!empty($keyword)) {
    //             $search = "where video_title like '%$keyword%' or video_title like '%$keyword%'";
    //         }
            
    //         $userData = $this->fetchVideo()->allvideolistdata($fields, $start, $limit, $search);
    
    //         // print_r($userData);
    //         // exit();
    //     }
    
    //     if (isset($userData['data']) && count($userData['data']) > 0) {
    //         $i = isset($requestData['offset']) ? $requestData['offset'] + 1 : 1;
    
    //         foreach ($userData['data'] as $key => $val) {
    //             $userData['data'][$key]['action'] = '<a class="btn btn-success text-white" href="/admin/videos/update-post-data/' . $val['video_id'] . '">Update</a>';
    //             $userData['data'][$key]['video_url'] = '<div class="ratio ratio-16x9"><iframe width="240" height="105" src="' . $val['video_url'] . '" frameborder="0" allowfullscreen></iframe></div>';
    //             $i++;
    //         }
    //     }
            
    //     $finalArray = [
    //         'total' => $userData['total_count'],
    //         'rows' => $userData['data'],
    //         'summary' => ''
    //     ];
    
    //     echo json_encode($finalArray);
    //     exit();
    // }

    public function allVideoListAjax(Request $request)
{
    $fields = ['*'];

    if ($request->method() == 'GET') {
        $requestData = $request->all();
        
        $start = isset($requestData['offset']) ? $requestData['offset'] : 0;
        $limit = isset($requestData['limit']) ? $requestData['limit'] : 3000;
        $keyword = isset($requestData['search']) ? $requestData['search'] : '';

        $search = '';
        if (!empty($keyword)) {
            $search = "where video_title like '%$keyword%' or video_title like '%$keyword%'";
        }
        
        $userData = $this->fetchVideo()->allvideolistdata($fields, $start, $limit, $search);
    }

    if (isset($userData['data']) && count($userData['data']) > 0) {
        $i = isset($requestData['offset']) ? $requestData['offset'] + 1 : 1;

        foreach ($userData['data'] as $key => $val) {
            $userData['data'][$key]['action'] = '<a class="btn btn-success text-white" href="/admin/videos/update-post-data/' . $val['video_id'] . '">Update</a>';
            
            // Normalize YouTube URL to embed format
            $url = $val['video_url'];
            $videoId = '';

            if (preg_match('/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|live\/|v\/))([^\?&]*)/', $url, $matches)) {
                $videoId = $matches[1];
            }

            if ($videoId) {
                $userData['data'][$key]['video_url'] = '<div class="ratio ratio-16x9"><iframe width="240" height="105" src="https://www.youtube.com/embed/' . $videoId . '" frameborder="0" allowfullscreen></iframe></div>';
            }
            $i++;
        }
    }
        
    $finalArray = [
        'total' => $userData['total_count'],
        'rows' => $userData['data'],
        'summary' => ''
    ];

    echo json_encode($finalArray);
    exit();
}

    




















    public function showrecentVideos()
    {
        $RecentVideos =  $this->fetchVideo()->getRecentVideos();

        return view('home-sections.recent-video-posts', compact('RecentVideos'));
    }

    public function insertvideoData(Request $request)
    {
        if ($request->isMethod('post')) {
            $dataArray = $request->all();
            $videourl = $dataArray['video_url'];

            unset($dataArray['_token']);
            $insertedPostId = $this->fetchVideo()->addNewvideoPost($dataArray);

            return redirect('/admin/videos/all-post-list');
            //return redirect('/admin/Videos/update-post-data/' . $insertedPostId);
        }
    }

    public function updateVideoDetails($video_id)
    {

       // $page = "blog-dashboard";

        $jobBasicData = $this->fetchVideo()->basicDataById($video_id);   

        return view('admin.VideoManager.updatevideosposts', compact('jobBasicData'));
    }

    public function updatePostDetailsData(Request $request)
    {

        if ($request->isMethod('post')) {
            $dataArray = $request->all();

            $fileArray = $request->file();
            $posturl = $dataArray['video_url'];

            unset($dataArray['_token']);

            if (isset($dataArray['featured_img'])) {
                $file = $fileArray['featured_img'];
                $document = 'featured-image';

                if (!empty($file)) {
                    $fileExtension = $file->getClientOriginalExtension();
                    $fileName = $document . '-' . $posturl . '.' . $fileExtension;

                    $localDestination = getcwd() . '/upload/Videos/';

                    $file->move($localDestination, $fileName);

                    $documentUpdate = array(

                        $document => $fileName
                    );
                }
                $dataArray['featured_img'] = $fileName;
            }
            unset($dataArray['_token']);
            $updateGetId = $this->fetchVideo()->updatePostDetails($dataArray);

            return redirect('/admin/videos/all-post-list');
            // return redirect('/admin/Videos/update-post-data/' . $updateGetId);
        }
    }

    

    public function updatePostDates(Request $request, $post_id)
    {
        // if (session('partner_id') || session('cw_name')) {
        // } else {
        //     return redirect('/login');
        // }

        $default_keys_important_dates = array(
            'notification_release' => 'Notification Release',
            'online_application_start' => 'Application Start',
            'last_date_apply_date' => 'Last Date',
            'last_date_apply_date_offline' => 'Last Date (Offline)',
            'result_date' => 'Result Date',
            'cutoff_date' => 'Cut-off Release',
            'answer_key_date' => 'Answer Key',
            'admit_card_date' => 'Admit Card',
            'last_date_to_pay_fee' => 'Aplication Fees Submited Till',
            'last_date_to_print_online_form' => 'Print Application Form Till',
            'other_date_1' => 'any other if fill here',
            'other_date_2' => 'any other if fill here',
            'other_date_3' => 'any other if fill here',
            'other_date_4' => 'any other if fill here',
            'other_date_5' => 'any other if fill here',
            'other_date_6' => 'any other if fill here',
            'other_date_7' => 'any other if fill here',
            'other_date_8' => 'any other if fill here',
        );

        if ($request->isMethod('post')) {

            $dataArray = $request->all();
            unset($dataArray['_token']);
            $postDateDataDelete =  $this->fetchVideo()->deleteDateDetails($post_id);
            $imp_date_key_arr = array_keys($default_keys_important_dates);
            $final_arr = array();

            foreach ($imp_date_key_arr as $impd) {

                foreach ($dataArray as $dKey => $dVal) {
                    if (strpos($dKey, $impd) !== false) {
                        $dKey_str = str_replace($impd . '_', '', $dKey);
                        $final_arr[$impd][trim($dKey_str)] = trim($dVal);
                    }
                }
            }


            $previous = array(')', ' (', ' : ', '/', "1st week of ", "2nd week of ", "3rd week of ", "4th week of ", "First Week of ", "Second Week of ", "Third week of ", "Fourth week of ", "");
            $new = array('', '', ' ', '-', '1', '8', '15', '22', '1', '8', '15', '22');

            if (isset($final_arr) && count($final_arr) > 0) {
                foreach ($final_arr as $param_key => $val) {

                    if (!empty($val['value'])) {
                        $param_array = array(
                            'post_id' => $post_id,
                            'value_key' => $param_key,
                            'value_display_name' => $val[$param_key],
                            'date' => $val['value'],
                        );


                        $postDateData =  $this->fetchVideo()->addDateDetails($param_array);


                        if ($param_key == 'last_date_apply_date' || $param_key == 'last_date_apply_date_offline') {

                            $value1 = $val['value'];

                            if (($pos = strpos($value1, "-")) !== FALSE) {
                                $value1 = explode('-', $value1);
                            }

                            $convertedTime = strtotime(str_replace($previous, $new, $value1));
                            $convertedDate = date('d M Y', $convertedTime);

                            $insertlastdate = $this->fetchVideo()->updatelastDate($post_id, $convertedDate);
                        }
                    }
                }


                return redirect('/admin/Videos/update-post-date-data/' . $post_id);
            }
        }


        $important_dates_array = $this->fetchVideo()->getPostDetails($post_id);
        $important_dates_array1 = array();
        if (isset($important_dates_array) && count($important_dates_array) > 0) {
            foreach ($important_dates_array as $impD) {
                $important_dates_array1[$impD['value_key']] = $impD;
            }
        }

        $page = "blog-dashboard";

        return view('admin.VideoManager.postDateDetails', compact('post_id', 'default_keys_important_dates', 'important_dates_array1', 'page'));
    }



    

    private function fetchVideo()
    {
        $test = new \App\Models\VdoModel();
        return $test;
    }
}
