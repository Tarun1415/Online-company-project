<?php

namespace App\Http\Controllers\AdminPanel;

use App\Http\Controllers\Controller;
use App\Models\question;
use App\Models\subpart;
use Illuminate\Http\Request;


class AskquestionController extends Controller
{

    public function index(Request $request)
    {

        // $services = subpart::all();
        $services = subpart::where('status', '1')->get();
        // Get the selected service name from the request
        $selectedService = $request->input('service_name');
        $categorie = subpart::orderBy('name', 'ASC')->get();

        // Fetch sub-services based on the selected service name
        $categories = question::select('questions.*', 'sub_parts.name as serviceName')
            ->leftJoin('sub_parts', 'sub_parts.id', 'questions.subpart_id')
            ->when($selectedService, function ($query, $selectedService) {
                return $query->where('sub_parts.name', $selectedService);
            })

            ->latest('questions.id')
            // ->get();
            ->paginate(10); // Set pagination to 10 items per page

        return view('admin.ask_question.askquestion_home', compact('categories', 'services', 'selectedService', 'categorie'));

    }



    public function indexdata(Request $request)
    {
        $start = $request->input('offset', 0);
        $limit = $request->input('limit', 10);
        $keyword = $request->input('search', '');
    
        $query = question::select('questions.*', 'sub_parts.name as serviceName')
        ->leftJoin('sub_parts', 'sub_parts.id', 'questions.subpart_id');
    
        if (!empty($keyword)) {
            $query->where(function ($q) use ($keyword) {
                $q->where('questions.name', 'LIKE', "%$keyword%")
                  ->orWhere('sub_parts.name', 'LIKE', "%$keyword%");
            });
        }
    
        $total = $query->count();
        $rows = $query->offset($start)->limit($limit)->get();
        foreach ($rows as $key => $row) {
            $rows[$key]->action = '<a class="btn btn-primary text-white" href="/ask/edit/' . $row->id . '">Update</a>
            <a class="btn btn-danger text-white" href="/delete_question/' . $row->id . '">Delete</a>';
            
        }
    
        return response()->json([
            'total' => $total,
            'rows' => $rows,
            'summary' => ''
        ]);
    }


    public function askquestion(Request $request)
    {
        if ($request->isMethod('post')) {
            $inputArr = $request->all();
            question::storequestion($inputArr);
        } else {
            $categories = subpart::orderBy('name', 'ASC')->get();
            // return view('admin.sub_services.home_viewadd',$data);
            return view('admin.ask_question.ask_question', compact('categories'));
        }
    }


    public function edit($id, Request $request)
    {
        $categories = question::find($id);
        $services = subpart::all();
        if (is_null($categories)) {
            return redirect('admin.ask_question.askquestion_home');
        } else {
            $data = compact('categories', 'services');
            return view('admin.ask_question.ask_questionedit')->with($data);
        }
    }


    public function update($id, Request $request)
    {
        // Retrieve the course instance
        $categories = question::find($id);
        // Check if the course exists
        if (is_null($categories)) {
            return response()->json([
                'status' => false,
                'notFound' => true,
                'message' => 'Course not found'
            ]);
        }
        // Validate form data
        $request->validate([
            'name' => 'required',
            'status' => 'required',
        ]);

        // Handle file upload
        $filename = $categories->image; // Default filename

        if ($request->hasFile('input_image')) {
            $image = $request->file('input_image');
            $filename = $image->getClientOriginalName();
            $image->move('uploads', $filename);
        }
        // Update course attributes
        $categories->name = $request->name;
        $categories->description = $request->description;
        $categories->image = $filename;
        $categories->status = $request->status;
        // Save the updated course
        $categories->save();
    }

    public function delete($id)
    {
        $categories = question::find($id)->delete();
        return redirect()->back();


    }




    // private function questionAuth()
    // {
    //   $test = new \App\Models\question();
    //     return $test;
    // }

}

