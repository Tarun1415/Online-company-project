<?php

namespace App\Http\Controllers\AdminPanel;

use App\Http\Controllers\Controller;
use App\Models\our;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
       public function index(){
            // $categories = our::latest('id')->paginate(10);
            // $data['categories'] = $categories;
            // return view('admin.our_service.service_home',compact('categories'));
            return view('admin.our_service.service_home');

            }


            public function indexdata(Request $request)
            {
                $fields = ['*'];
            
                if ($request->method() == 'GET') {
                    $requestData = $request->all();
                    
                    $start = isset($requestData['offset']) ? $requestData['offset'] : 0;
                    $limit = isset($requestData['limit']) ? $requestData['limit'] : 3000;
                    $keyword = isset($requestData['search']) ? $requestData['search'] : '';
            
                    $search = '';
                    if (!empty($keyword)) {
                        $search = "where name like '%$keyword%' or name like '%$keyword%'";
                    }
                    
                    $userData = $this->serviceAuth()->getAllservice($fields, $start, $limit, $search);
                    // print_r($userData);
                    // exit();
                }
            
                if (isset($userData['data']) && count($userData['data']) > 0) {
                    $i = isset($requestData['offset']) ? $requestData['offset'] + 1 : 1;
            
                    foreach ($userData['data'] as $key => $val) {
                        $userData['data'][$key]['action'] = '<a class="btn btn-success text-white" href="/admin/servicedelete/' . $val['id'] . '">Delete</a>';
                        $i++;
          
                        // $userData['data'][$key]['action'] = '<a href="/admin/user/' . $val['lead_id'] . '" class="btn-sussess">view</a>';
                    }
                }
                
                $finalArray = [
                    'total' => $userData['total_count'],
                    'rows' => $userData['data'],
                    'summary' => ''
                ];
            
                echo json_encode($finalArray);
                exit();
            }


        public function adddata(Request $request)
            {
                $validator = \Validator::make($request->all(), [
                    'name' => 'required|unique:ours,name'
                   
                ]);
            
                if ($validator->fails()) {
                    return response()->json([
                        'success' => false,
                        'errors' => $validator->errors()
                    ]);
                }
                    $inputArr = $request->all();                             
                // Call the static method to store the blog
                    our::storeservice($inputArr);
                    return response()->json([
                        'success' => true,
                        'message' =>"Service added successfully"
                    ]);
             
        }
    

        public function delete($id){
                $categories = our::find($id)->delete();
                return redirect()->back();
                }


private function serviceAuth()
{
  $test = new our();
    return $test;
}


}
