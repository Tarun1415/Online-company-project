<?php

namespace App\Http\Controllers\UserPanel;

use Illuminate\Http\Request;
use App\Jobs\EmailSend;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Jenssegers\Agent\Agent;
use Illuminate\Support\Facades\Storage;
use App\Jobs\FollowupEmailSend;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Validator;
use Session;





class UserLoginController extends Controller
{

  public function basic_details_User(Request $request)
  {

    if (!session('user_id')) {

      return redirect('/');

    }
 
    if (session('user_id')) {
      $user_id = session('user_id');
      $profileImgUrl = $this->userAuth()->profilePicCheck($user_id);
      // print_r($profileImgUrl);
      // die;
    }


    //for form update
    if ($request->isMethod('post')) {
      $postData = $request->all();
      // print_r($postData);
      // exit();
      unset($postData['_token']);
      $array = $postData['services'];
      $str = implode(",", $array);
      $postData['service_required'] = $str;
      //print_r($postData);
      unset($postData['services']);
      
      // // $request->validate([
      // //   'user_name' => 'required|string|max:255|regex:/^[A-Za-z ]+$/',
      // // 'user_email' => 'required|email',
      // //   'service_required' => 'required'
      // // ]);

      // $array = $postData['service_required'];
      // $str = implode(",", $array);
      // $postData['service_required'] = $str;
      //print_r($postData);die;
      $document_data = $this->userAuth()->store_Basic_Detail($user_id, $postData);

      return redirect('/user/document');
    }
    

    $data = $this->userAuth()->loginUser($user_id);

    // exit();

    if (!empty($data['service_required'])) {

          $servicerequestArray = explode(',', $data['service_required']);
        } else {
          $servicerequestArray = array();
        }

        foreach ($servicerequestArray as $key => $service) {

          $service = intval($service);
          $servicerequestArray[$key] = $service;
        }

        $data['service_required'] = $servicerequestArray;
        

        $services = $this->userAuth()->getAllServices();
        $userselectedservices = $this->userAuth()->getUsersservices($user_id);
    // print_r($userselectedservices);
    // exit();
    return view('user.dashboard', compact('data', 'services', 'profileImgUrl','userselectedservices'));
  }




  // For Profile Update

  public function profile_Upload(Request $request)
  {


    if (session('user_id')) {
      $user_id = session('user_id');
     
     
    }

    $request->validate([
      'user_profile' => 'required|image|mimes:jpeg,png,jpg,gif',
  ]);

    

    if ($request->isMethod('post')) {
      $postData = $request->all();
      // print_r($postData);
      // exit();
      unset($postData['_token']);

      $fileArray = $request->file();
      $file = $request['user_profile'];

     

      if (!empty($file)) {
        $fileExtension = $file->getClientOriginalExtension();
        $fileName = $user_id . '-' . time() . '.' . $fileExtension;
        $localDestination = getcwd() . '/upload/user/' . $user_id . '/user-document';

        $file->move($localDestination, $fileName);

        $documentUpdate = array(
          'user_profile' => $fileName
        );
      }


      $document_data = $this->userAuth()->store_profile($user_id, $documentUpdate);

      return redirect('/user/basic-details');
    }
  }

  

  // For User Document

  public function document_User(Request $request)
  {

    if (session('user_id')) {
      $user_id = session('user_id');
      
      $profileImgUrl = $this->userAuth()->profilePicCheck($user_id);
      

    }


    //for form update

    if ($request->isMethod('post')) {
        $postData = $request->all();
      
        unset($postData['_token']);

        $fileArray = $request->file();
      
        $file = $fileArray['user_document'];

        $document = $postData['document'];

       //dd($file);

      if (!empty($file)) {
        $fileExtension = $file->getClientOriginalExtension();
        // dd($fileArray);
        $fileName = $document . '-' . $user_id . '.' . $fileExtension;
        $localDestination = getcwd() . '/upload/user/' . $user_id . '/user-document';
        $file->move($localDestination, $fileName);
        //  dd($fileName);

        $documentUpdate = array(
          'user_id' => $user_id,
          $document => $fileName
        );
      }
      Session::put('form_submitted', true);
 
      $document_data = $this->userAuth()->store_user_document($user_id, $documentUpdate);

      // return redirect('/user/user-status');

    }

    $all_document = $this->userAuth()->getDocumentRequired($user_id);

    $all_documentuploaded = $this->userAuth()->getUploadeDocumentRequired($user_id);

    $array = $all_document['document_required'];
    $str = explode(",", $array);
    $all_document['document_required'] = $str;

    // print_r($all_documentuploaded);
    // exit();

    return view('user.document', compact('all_document', 'user_id', 'profileImgUrl','all_documentuploaded'));
  }



  // For user Status
  public function status_User(Request $request)
  {

    if (!Session::get('form_submitted')) {
      return back()->with('error', 'Please submit the form first.');
  }

  

    if (session('user_id')) {
      $user_id = session('user_id');
      $profileImgUrl = $this->userAuth()->profilePicCheck($user_id);
    }

    return view('user.user_status', compact('profileImgUrl'));
  }



  public function store(Request $request)
  {

    $request->validate([
      'user_name' => 'required|string|max:255|regex:/^[A-Za-z ]+$/',
      'user_email' => 'required|email',
      'user_contact_number' => 'required|digits:10',
  ]);
    
    if ($request->isMethod('post')) {

      
      $postData = $request->all();
      unset($postData['_token']);

      //     print_r($postData);
      // exit();
      


      $registerCompany = $this->userAuth()->registerCompany($postData);

      session()->put('user_id', $registerCompany['user_id']);

      session()->save();

      return redirect('/user/basic-details');
    }
  }



  public function storeSubscriber(Request $request)
  {

    $request->validate([
      'email' => 'required|email',
  ]);
    
    if ($request->isMethod('post')) {

      
      $postData = $request->all();
      unset($postData['_token']);

      //     print_r($postData);
      // exit();
      


      $userSubcriber = $this->userAuth()->userSubcriber($postData);

      // session()->put('user_id', $userSubcriber['user_id']);

      // session()->save();

      return back();
    }
  }







  // user log out
  public function userLogOut(Request $request)
  {
      Auth::logout(); 

      Session::forget('user_id');
      // Use 'web' guard for users
      // $request->session()->invalidate(); // Invalidate the session
      // $request->session()->regenerateToken(); // Regenerate the CSRF token
  
      return redirect('/')->with('success', 'Logged out successfully');
  }
  
  
  // public function userLogOut(Request $request)
  // {
  //     Session::flush();
  //     \Auth::logout();
  //     return redirect('/');
  // }
  




  // Model for user
  private function userAuth()
  {
    $test = new \App\Models\UserLogin();
    return $test;
  }
}
