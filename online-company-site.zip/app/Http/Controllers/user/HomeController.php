<?php

namespace App\Http\Controllers\user;

use App\Http\Controllers\Controller;
use App\Models\homeview;
use App\Models\subpart;
use App\Models\our;
use Illuminate\Http\Request;

class HomeController extends Controller
{


    public function gstregister($SubCategorySlug)
    {
        // Fetch the subcategory along with its details and questions, and ensure it's active
        $page = subpart::with(['detail', 'questions' => function ($query) {
                            $query->where('status', 1); // Ensure questions are active
                        }])
                        ->where('slug', $SubCategorySlug)
                        ->where('status', 1) // Ensure the subcategory is active
                        ->first();
    
        // If the page is not found or inactive, handle the case (redirect or show error)
        // if (!$page) {
        //     return redirect()->route('some.error.page')->with('error', 'Subcategory not found or is inactive');
        // }
    
        // Render the view with the active subcategory
        return view('admin.home_subservice.home_view', compact('page'));
    }
    

    // public function gstregister($SubCategorySlug){
    //     $page = subpart::with('detail','questions')->where('slug',$SubCategorySlug)->first();

    //     // dd( $page );
    //     return view('admin.home_subservice.home_view',compact('page'));
    //     // return  $page;
       
    // }


    // public function gstregister($SubCategorySlug)
    // {
    //     $page = Subpart::with('detail')->where('slug', $SubCategorySlug)->first();

    //     // Check if the page exists
    //     if (!$page) {
    //         // Option 1: Abort with a 404 error
    //         abort(404, 'Page not found');

    //         // Option 2: Redirect to a specific route (e.g., home)
    //         // return redirect()->route('front.home')->with('error', 'Page not found');
    //     }

    //     return view('admin.home_subservice.home_view', compact('page'));
    // }
    // gst_register.blade.php







    public function viewpage()
    {
       return view('admin.home_subservice.viewpage');
    
    }




    public function index(Request $request)
    {
        // Fetch all services for the dropdown
        // $services = subpart::all();

        $services = subpart::where('status', '1')->get();
       

        // Get the selected service name from the request
        $selectedService = $request->input('service_name');
        

        // Fetch sub-services based on the selected service name
        $categories = homeview::select('home_views.*', 'sub_parts.name as serviceName')
            ->leftJoin('sub_parts', 'sub_parts.id', 'home_views.subpart_id')
            ->when($selectedService, function ($query, $selectedService) {
                return $query->where('sub_parts.name', $selectedService);
            })
          
            ->latest('home_views.id')
            // ->get();
            ->paginate(10); // Set pagination to 10 items per page

        return view('admin.home_subservice.homepage_view', compact('categories', 'services', 'selectedService'));
    }

    public function create(Request $request){

        if($request->isMethod('post')){
            $inputArr = $request->all();                             
        // Call the static method to store the blog
        homeview::homeview($inputArr);
        }

        else
        {
        $categories = subpart::orderBy('name','ASC')->get();
        $data['categories'] = $categories;
        return view('admin.sub_services.home_viewadd',$data);
        }
}


public function edit($id, Request $request){
    $categories = homeview::find($id);
    $services = subpart::all();

    if (is_null($categories)) {
        return redirect()->route('admin.home_subservice.homepage_view');
    } else {
        $data = compact('categories', 'services');
        return view('admin.sub_services.home_edit')->with($data);
    }
}





public function update($id,Request $request)
{
  // Retrieve the course instance
  $categories =homeview::find($id);
  // Check if the course exists
  if (is_null($categories)) {
      return response()->json([
          'status' => false,
          'notFound' => true,
          'message' => 'Course not found'
      ]);
  }                                                                                                                                                                                                                                                                                                                                   
  // Validate form data
  $request->validate([
      'name' => 'required',
      'description' => 'required',            
      'input_image1' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
      'input_image2' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
      'input_image3' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
      'input_image4' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
      'input_image5' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
      'input_image6' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2048',


      'status' => 'required',          
  ]);

  // Handle file upload
  $filename1 = $categories->image1; // Default filename

  if ($request->hasFile('input_image1')) {
      $image = $request->file('input_image1');
      $filename1 = $image->getClientOriginalName();
      $image->move('uploads', $filename1);
  }


  $filename2 = $categories->image2; // Default filename

  if ($request->hasFile('input_image2')) {
      $image = $request->file('input_image2');
      $filename2 = $image->getClientOriginalName();
      $image->move('uploads', $filename2);
  }

  
  $filename3 = $categories->image3; // Default filename

  if ($request->hasFile('input_image3')) {
      $image = $request->file('input_image3');
      $filename3 = $image->getClientOriginalName();
      $image->move('uploads', $filename3);
  }

  
  $filename4 = $categories->image4; // Default filename

  if ($request->hasFile('input_image4')) {
      $image = $request->file('input_image4');
      $filename4 = $image->getClientOriginalName();
      $image->move('uploads', $filename4);
  }

  
  $filename5 = $categories->image5; // Default filename

  if ($request->hasFile('input_image5')) {
      $image = $request->file('input_image5');
      $filename5= $image->getClientOriginalName();
      $image->move('uploads', $filename5);
  }

  
  $filename6 = $categories->image6; // Default filename

  if ($request->hasFile('input_image6')) {
      $image = $request->file('input_image6');
      $filename6 = $image->getClientOriginalName();
      $image->move('uploads', $filename6);
  }

  // Update course attributes
      $categories->name = $request->name;
      $categories->description = $request->description; // Assuming you've generated the slug in the frontend.
      $categories->title1 = $request->title1;
      $categories->image1 = $filename1;
      $categories->text1 = $request->text1;
      $categories->title2 = $request->title2;
      $categories->image2 = $filename2;
      $categories->text2 = $request->text2;
      $categories->title3 = $request->title3;
      $categories->image3 = $filename3;
      $categories->text3 = $request->text3;
      $categories->title4 = $request->title4;
      $categories->image4 = $filename4;
      $categories->text4= $request->text4;
      $categories->title5 = $request->title5;
      $categories->image5 = $filename5;
      $categories->text5 = $request->text5;
      $categories->title6 = $request->title6;
      $categories->image6 = $filename6;
      $categories->text6 = $request->text6;
      

      $categories->seo_title = $request->seo_title;
      $categories->seo_description = $request->seo_description;
      // $categories->seo_keywords = $request->seo_keywords;
      $categories->status = $request->status;

      // Save the updated course
      $categories->save();  
}



public function delete($id){
    $categories = homeview::find($id)->delete();
    return redirect()->back();


 }












}
