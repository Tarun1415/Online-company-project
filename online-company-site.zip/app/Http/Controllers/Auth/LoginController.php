<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest', ['except' => 'logout']);
    }


    public function showLoginForm()
    {


      if(\App::environment() == 'local')
      {
        $userIp = $_SERVER['REMOTE_ADDR'];
      
  //       print_r($userIp);
  // exit();
        $allowedIps =   $this->userActivityNew()->getAllowedIps();
          
       
     
        // Ip Based Login Stop for few time so directly returning return view('auth.login');

        return view('auth.login');

      // if(in_array($userIp,$allowedIps))
      // {
      //   return view('auth.login');
      
      // }
      // else{
      
      //   return abort(401);
      // }


        
      
      }
      else
      {
      
        // if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        // {
  
      // $userIp = $_SERVER['HTTP_X_FORWARDED_FOR']?$_SERVER['HTTP_X_FORWARDED_FOR']:$_SERVER['REMOTE_ADDR'];

    //   $userIp = $_SERVER['REMOTE_ADDR'];

      
      
    // $allowedIps =   $this->userActivityNew()->getAllowedIps();
      

    
  // if(in_array($userIp,$allowedIps))
  // {
  //   return view('auth.login');
  
  // }
  // else{
  
  //   return abort(401);
  // }

  // Ip Based Login Stop for few time so directly returning return view('auth.login');

  return view('auth.login');
        
  
  
          // }
      
      
      }

       
    }



    public function login(Request $request)
    {
        $this->validateLogin($request);

       

        if(Auth::attempt(['contact_no' => $request->contact_no, 'password' => $request->password, 'status' => 'enable'])) {
            // return redirect()->intended('dashboard');

            $user =  Auth::user();

            // print_r($user);
            // exit();

            if($user->hasRole('hr') )
            {
            
            // $dhLoginCheck = $this->dataHeadAuthenticate()->getDhDetailsByGlobalId($user->id);
            
            session()->put('global_user_id', $user->id);
            session()->put('hr_name', $user->name);
            session()->save();
            // login log
            $loginActivity = array(
            'user_type' => 'hr',
            'user_contact_no' => $request->contact_no,
            'id' => $user->id,
            'login_time' => time()
            );
            $this->userActivityNew()->userLoginActivity($loginActivity);
            
            // return redirect('/data-head/home');
            return redirect('/profile');
            
            
            }


            if($user->hasRole('data-head') )
{

$dhLoginCheck = $this->dataHeadAuthenticate()->getDhDetailsByGlobalId($user->id);

session()->put('global_user_id', $user->id);
session()->put('dh_id', $dhLoginCheck['dh_id']);
session()->put('dh_name', $dhLoginCheck['dh_name']);
session()->save();
// login log
$loginActivity = array(
'user_type' => 'Data Head',
'user_contact_no' => $dhLoginCheck['dh_contact_no'],
'id' => $dhLoginCheck['dh_id'],
'login_time' => time()
);
$this->userActivityNew()->userLoginActivity($loginActivity);

// return redirect('/data-head/home');
return redirect('/profile');


}



// ARO
if($user->hasRole('aro') )
{

$aroLoginCheck = $this->aroAuthenticate()->getAroDetailsByGlobalId($user->id);

session()->put('global_user_id', $user->id);
session()->put('aro_id', $aroLoginCheck['aro_id']);
session()->put('aro_name', $aroLoginCheck['aro_name']);
session()->save();
// login log
$loginActivity = array(
'user_type' => 'ARO',
'user_contact_no' => $aroLoginCheck['aro_contact_no'],
'id' => $aroLoginCheck['aro_id'],
'login_time' => time()
);
$this->userActivityNew()->userLoginActivity($loginActivity);

// return redirect('/aro/all-leads');
return redirect('/profile');

}


// TL
if($user->hasRole('team-lead') )
{

$tlLoginCheck = $this->teamLeaderAuthenticate()->getTlDetailsByGlobalId($user->id);

// print_r($tlLoginCheck);
// exit();

session()->put('global_user_id', $user->id);
session()->put('tl_id', $tlLoginCheck['tl_id']);
session()->put('tl_name', $tlLoginCheck['tl_name']);
session()->save();
// login log
$loginActivity = array(
'user_type' => 'Team leader',
'user_contact_no' => $tlLoginCheck['tl_contact_no'],
'id' => $tlLoginCheck['tl_id'],
'login_time' => time()
);
$this->userActivityNew()->userLoginActivity($loginActivity);

// return redirect('/team-leader/all-leads');
return redirect('/profile');

}
// manager
     if($user->hasRole('manager') )
     {


     
$managerLoginCheck = $this->managerAuthenticate()->getManagerDetailsByGlobalId($user->id);

session()->put('global_user_id', $user->id);
  session()->put('manager_id', $managerLoginCheck['manager_id']);
  session()->put('manager_name', $managerLoginCheck['manager_name']);
  session()->save();
  // login log
  $loginActivity = array(
    'user_type' => 'Manage',
    'user_contact_no' => $managerLoginCheck['manager_contact_no'],
    'id' => $managerLoginCheck['manager_id'],
    'login_time' => time()
);
    $this->userActivityNew()->userLoginActivity($loginActivity);

   

    // return redirect('/manager/all-leads');
    return redirect('/profile');

     }


     if($user->hasRole('administrator|superadministrator') )
     {


$partnerLoginCheck = $this->partnerAuthenticate()->getPartnerDetailsByGlobalId($user->id);

   session()->put('global_user_id', $user->id);
  session()->put('partner_id', $partnerLoginCheck['partner_id']);

  session()->save();
  // login log
  $loginActivity = array(
    'user_type' => 'Admin',
    'user_contact_no' => $partnerLoginCheck['partner_contact_no'],
    'id' => $partnerLoginCheck['partner_id'],
    'login_time' => time()
);
    $this->userActivityNew()->userLoginActivity($loginActivity);

    // return redirect('/partner/home');

    return redirect('/profile');



     }


   


    if($request->get('url'))
    {
        return redirect($request->get('url'));
    }


    

    return redirect('/profile');









        }  else {
           

         return  redirect("login")->with('error', array('message'=>'Wrong Credentials!','title'=>'Error'));

        }

       // return $this->sendFailedLoginResponse($request);
    }


    protected function validateLogin(Request $request)
    {
      
        $request->validate([
            $this->username() => 'required|string',
            'password' => 'required|string'
        ]);




    }




    protected function authenticated(Request $request, $user)
{


// // Login Log
//$this->setLoginLog($user->id);




// DATA HEAD
if($user->hasRole('data-head') )
{

$dhLoginCheck = $this->dataHeadAuthenticate()->getDhDetailsByGlobalId($user->id);

session()->put('global_user_id', $user->id);
session()->put('dh_id', $dhLoginCheck['dh_id']);
session()->put('dh_name', $dhLoginCheck['dh_name']);
session()->save();
// login log
$loginActivity = array(
'user_type' => 'Data Head',
'user_contact_no' => $dhLoginCheck['dh_contact_no'],
'id' => $dhLoginCheck['dh_id'],
'login_time' => time()
);
$this->userActivityNew()->userLoginActivity($loginActivity);

return redirect('/data-head/home');


}



// ARO
if($user->hasRole('aro') )
{

$aroLoginCheck = $this->aroAuthenticate()->getAroDetailsByGlobalId($user->id);

session()->put('global_user_id', $user->id);
session()->put('aro_id', $aroLoginCheck['aro_id']);
session()->put('aro_name', $aroLoginCheck['aro_name']);
session()->save();
// login log
$loginActivity = array(
'user_type' => 'ARO',
'user_contact_no' => $aroLoginCheck['aro_contact_no'],
'id' => $aroLoginCheck['aro_id'],
'login_time' => time()
);
$this->userActivityNew()->userLoginActivity($loginActivity);

return redirect('/aro/all-leads');


}


// TL
if($user->hasRole('team-lead') )
{

$tlLoginCheck = $this->teamLeaderAuthenticate()->getTlDetailsByGlobalId($user->id);

session()->put('global_user_id', $user->id);
session()->put('tl_id', $tlLoginCheck['tl_id']);
session()->put('tl_name', $tlLoginCheck['tl_name']);
session()->save();
// login log
$loginActivity = array(
'user_type' => 'Team leader',
'user_contact_no' => $tlLoginCheck['tl_contact_no'],
'id' => $tlLoginCheck['tl_id'],
'login_time' => time()
);
$this->userActivityNew()->userLoginActivity($loginActivity);

return redirect('/team-leader/all-leads');


}
// manager
     if($user->hasRole('manager') )
     {


     
$managerLoginCheck = $this->managerAuthenticate()->getManagerDetailsByGlobalId($user->id);

session()->put('global_user_id', $user->id);
  session()->put('manager_id', $managerLoginCheck['manager_id']);
  session()->put('manager_name', $managerLoginCheck['manager_name']);
  session()->save();
  // login log
  $loginActivity = array(
    'user_type' => 'Manage',
    'user_contact_no' => $managerLoginCheck['manager_contact_no'],
    'id' => $managerLoginCheck['manager_id'],
    'login_time' => time()
);
    $this->userActivityNew()->userLoginActivity($loginActivity);

   

    return redirect('/manager/all-leads');


     }


     if($user->hasRole('administrator|superadministrator') )
     {

$partnerLoginCheck = $this->partnerAuthenticate()->getPartnerDetailsByGlobalId($user->id);

  session()->put('global_user_id', $user->id);
  session()->put('partner_id', $partnerLoginCheck['partner_id']);

  session()->save();
  // login log
  $loginActivity = array(
    'user_type' => 'Admin',
    'user_contact_no' => $partnerLoginCheck['partner_contact_no'],
    'id' => $partnerLoginCheck['partner_id'],
    'login_time' => time()
);
    $this->userActivityNew()->userLoginActivity($loginActivity);

    return redirect('/partner/home');


     }


   


    if($request->get('url'))
    {
        return redirect($request->get('url'));
    }


    

    return redirect('/profile');
}


private function setLoginLog($user_id)
{

  
  if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
  {
$userIp = $_SERVER['HTTP_X_FORWARDED_FOR']?$_SERVER['HTTP_X_FORWARDED_FOR']:$_SERVER['REMOTE_ADDR'];

$logUpdateArray = array(
  'user_id' => $user_id,
  'ip_address' => $userIp
);


$this->authenticate()->loginLog($logUpdateArray);
  }


}

public function username()
{
    return 'contact_no';
}

private function dataHeadAuthenticate()
{
    
  $test = new \App\Models\DataHead\DataHeadAuth();
  return $test;
}

private function aroAuthenticate()
{
    
  $test = new \App\Models\Aro\AroAuth();
  return $test;
}


private function teamLeaderAuthenticate()
{
    
  $test = new \App\Models\TeamLeader\TeamLeaderAuth();
  return $test;
}




private function managerAuthenticate()
{
    
  $test = new \App\Models\Manager\ManagerAuth();
  return $test;
}



private function partnerAuthenticate()
{
    
  $test = new \App\Models\Partner\PartnerAuth();
  return $test;
}

private function userActivityNew()
{
    
  $test = new \App\Models\UserActivityNew();
  return $test;
}


}
