<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DateTime;
use DateInterval;
use DatePeriod;
use App\Library\AWSCognitoWrapper;
use App\Jobs\EmailSend;
use App\Jobs\ImageProctoring;
use App\Jobs\FollowupEmailSend;
use Mail;
use Illuminate\Support\Facades\Cache;
use PaytmWallet;
use Jenssegers\Agent\Agent;
use Illuminate\Support\Str;
use App\Traits\LeadAssignTrait;

use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;



use SEOMeta;
use OpenGraph;
use Twitter;
## or
use SEO;

class MainController extends Controller
{



  public function home(Request $request)
  {

    

    $agent = new Agent();
    $page = "home";


    SEOMeta::setTitle('Online Company | Team of profesionals looking for Company Professional services',false);
    SEOMeta::setDescription('Welcome to OnlineCompany Professional Services - India most affordable prices with a team of Professionals, delivering the best experience with a 4.9* rating on Facebook & Google and 60+ compliance experts.');
    SEOMeta::setCanonical('https://onlinecompany.co.in/');
    SEOMeta::setkeywords('OnlineCompany Professional Services, Affordable professional services in India, Compliance experts in India, 4.9-star rating on Facebook and Google, Top-rated professional services, Cost-effective solutions, Business compliance support, Expert solutions for startups and businesses, India business services, Reliable partner for your business journey');
    OpenGraph::setTitle('Online Company | Team of profesionals looking for Company Professional services');
    OpenGraph::setUrl('https://onlinecompany.co.in/');
    OpenGraph::addProperty('type', 'website');
    OpenGraph::setSiteName('onlinecompany');
    OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
    Twitter::setTitle('Online Company | Team of profesionals looking for Company Professional services');
    Twitter::addValue('card', 'summary');
    Twitter::setImage('');
    Twitter::addValue('creator', '@onlinecompany');

    $blogs = $this->userAuth()->getAllBlogs();
    //return view('home-sections.recent-blog-posts',compact('recentblogs'));
    //print_r($recentblogs);die;
    if(session('user_id'))
    {
      $user_id = session('user_id');
      // dd($user_id);
      $profileImgUrl = $this->userAuth()->profilePicCheck($user_id);
    }
    else
    {
      $profileImgUrl = "../assets/img/avatars/default-user.png";
    }

    if ($request->isMethod('post')) {
    $requestData = $request->all();

    unset($requestData['_token']);



    if ($requestData['action'] == 'login') {
      unset($requestData['action']);

    
     
      $user_name = $requestData['user_contact_number'];
      
      // dd($requestData);
      $responseLogin = $this->userAuth()->loginCheck($user_name);

      if ($responseLogin['status'] == 'success') {
        // Redirect
// dd($responseLogin);
        session()->put('user_id', $responseLogin['user_id']);
        session()->put('user_verification_status', $responseLogin['user_verification_status']);
        session()->save();

        return redirect('/user/basic-details');
      } else if ($responseLogin['status'] == 'not-exist') {
        
        // Make Registration

     

        if($requestData['otp_verify_flag'] == 'N')
        {
          $status = 'Mobile Number is not verified';
          if ($agent->isMobile() || $agent->isTablet()) {
            return view('main.home.register-mobile', compact('status','page','blogs'));
          } else {
            return view('main.home.register', compact('status','page','blogs'));
          }
        }
        else
        {
          unset($requestData['otp_verify_flag']);
        }

        $responseRegister = $this->userAuth()->registerUser($requestData);
// dd($responseRegister);
        session()->put('user_id', $responseRegister['lead_id']);
       
        session()->save();

        if ($responseRegister['status'] == 'user exist') {
          $status = $responseRegister['message'];
          if ($agent->isMobile() || $agent->isTablet()) {
            return view('main.home.register-mobile', compact('status','blogs'));
          } else {
            return view('main.home.register', compact('status','blogs'));
          }
        }



     

        if ($responseRegister['status'] == 'success') {
  
          // $this->assignLeadARO($responseRegister['lead_id']);
  
  
          session()->put('user_id', $responseRegister['lead_id']);
       
          session()->save();
          
          return redirect('/user/basic-details');
        }

      }
    }
  }
    else
    {

    $recentblogs =$this->userAuth()->getRecentBlogs();
    $RecentVideos =$this->userAuth()->getRecentVideos();

      if ($agent->isMobile() || $agent->isTablet()) {
        return view('main.home.index-mobile', compact('profileImgUrl','page','blogs','recentblogs','RecentVideos'));
     } else {
       return view('main.home.index', compact('profileImgUrl','page','blogs','recentblogs','RecentVideos'));
     }
 

    }


 
   
  }

  

  // All pages
  public function blog1($slug)
  {
    $agent = new Agent();
    $post_id =  $this->userAuth()->postidbyurl($slug);
    $basic_detais =  $this->userAuth()->postbasicdetails($post_id[0]['post_id']);

    SEOMeta::setTitle($basic_detais[0]['post_display_name'],false);
    SEOMeta::setDescription($basic_detais[0]['short_info']);
    SEOMeta::setCanonical('https://onlinecompany.co.in/');
    SEOMeta::setkeywords('');
    OpenGraph::setTitle($basic_detais[0]['post_display_name']);
    OpenGraph::setUrl('https://onlinecompany.co.in/');
    OpenGraph::addProperty('type', 'website');
    OpenGraph::setSiteName('onlinecompany');
    Twitter::setTitle($basic_detais[0]['post_display_name']);
    Twitter::addValue('card', 'summary');
    Twitter::addValue('creator', '@onlinecompany');


    $jobjsonld = array();

    if ($basic_detais[0]['post_status'] == 'live') {

        $jobjsonld['@context'] = "https://schema.org/";
        $jobjsonld['@type'] = "NewsArticle";

        $jobjsonld['mainEntityOfPage']['@type'] = 'WebPage';
        $jobjsonld['mainEntityOfPage']['@id'] = "https://fincrif.com/blogs/".$basic_detais[0]['post_url']."";

        $jobjsonld['headline'] = $basic_detais[0]['post_display_name'];
        $jobjsonld['description'] = $basic_detais[0]['short_info'];

        $siteurl = "http://127.0.0.1:8000/"; 
        // $jobjsonld['image'] = $siteurl . '/upload/blogs/' . $basic_detais[0]['post_url'] . '/featuredImg/' . $basic_detais[0]['featured_img'];
        


        $jobjsonld['image'] = $siteurl.'/upload/blogs/'.$basic_detais[0]['post_url'].'/featuredImg/'.$basic_detais[0]['featured_img'];
       
        $jobjsonld['author']['@type'] = 'Person';
        $jobjsonld['author']['name'] = 'Admin';
        $jobjsonld['author']['url'] = "https://fincrif.com";

        $jobjsonld['publisher']['@type'] = "Organization";
        $jobjsonld['publisher']['name'] = "Fincrif India";
        $jobjsonld['publisher']['logo']['@type'] = 'ImageObject';
        $jobjsonld['publisher']['logo']['url'] = 'https://fincrif.com/assets/img/fincrif%20logo4.jpg';
       

        $jobjsonld['datePublished'] = $basic_detais[0]['post_create_date'];
        $jobjsonld['dateModified'] =$basic_detais[0]['post_update_date'];
       
    }
   
    if(!empty($basic_detais[0]['post_org']))
    {
        $org_id = $basic_detais[0]['post_org'];
        $org_name = $this->userAuth()->postOrgDetails($org_id);
    }

    if(!empty($basic_detais[0]['post_sector']))
    {
        $sector_id = $basic_detais[0]['post_sector'];
        $sector = $this->userAuth()->postSectorDetails($sector_id);
    }

    $page = 'blog-details';
    $vacancy_details = $this->userAuth()->postvacancydetails($post_id[0]['post_id']);
    $similarPost = $this->userAuth()->similarJobs($basic_detais[0]['post_id']);
    // print_r($similarPost);
    // exit();

    $updatePostViewCounter = $this->userAuth()->postViewCountUpdate($basic_detais[0]['post_id']);
    $blogs = $this->userAuth()->getAllBlogs();
    $recentblogs =$this->userAuth()->getRecentBlogs();
    $RecentVideos =$this->userAuth()->getRecentVideos();
    //print_r($basic_detais[0]);die;
    if ($agent->isMobile() || $agent->isTablet()) {
      return view('blogs.mobile.blogs',compact('basic_detais','vacancy_details','similarPost','page','jobjsonld','blogs','recentblogs','RecentVideos'));
    } else {
      return view('blogs.blogs',compact('basic_detais','vacancy_details','similarPost','page','jobjsonld','blogs','recentblogs','RecentVideos'));
    }
  }

  // public function blog2()
  // {
  //   return view('blogs.blog-2');
  // }

  // public function blog3()
  // {
  //   return view('blogs.blog-3');
  // }

public function itr_filling()
{


  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('home-sections.itr-filling',compact('blogs','recentblogs','RecentVideos'));
}

public function company_registration()
{
  
  SEOMeta::setTitle('The Importance of Establishing a Formal Corporate Compliance Program',false);
  SEOMeta::setDescription(' A formal corporate compliance program is vital for corporations to ensure they adhere to all relevant rules and regulations governing their operations. This involves creating and enforcing policies, training employees on legal matters, staying updated on the law, implementing compliance procedures, and proactively monitoring for legal violations. Without such a program, companies face significant legal and reputational risks. Consider consulting with a corporate compliance partner to develop and implement an effective compliance plan for your organization.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/company-registration');
  SEOMeta::setkeywords('Corporate compliance, Legal framework, Compliance program, Policy enforcement, Employee training, Legal knowledge updates, Compliance procedures, Legal violations, Legal responsibility, Reputational damage, Compliance partner, Compliance plan.');
  OpenGraph::setTitle('The Importance of Establishing a Formal Corporate Compliance Program');
  OpenGraph::setUrl('https://onlinecompany.co.in/company-registration');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('The Importance of Establishing a Formal Corporate Compliance Program');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('home-sections.company-registration',compact('blogs','recentblogs','RecentVideos'));
}

public function corporate_compliance()
{
  SEOMeta::setTitle('Navigating Corporate Compliance: Ensuring Legal Adherence in Operations',false);
  SEOMeta::setDescription(' Discover the significance of corporate compliance in maintaining adherence to the intricate web of rules and laws governing business operations. This comprehensive approach involves policy creation and enforcement, staff training, legal updates, procedural frameworks, and vigilant oversight within the organization. Without a formal corporate compliance program, businesses expose themselves to substantial legal liabilities and potential damage to their reputation. Consider the importance of establishing and implementing a structured corporate compliance program, and explore the benefits of consulting with a corporate compliance partner for a seamless transition into legal compliance.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/corporate-compliance');
  SEOMeta::setkeywords(' Corporate compliance, Legal adherence, Policy creation, Staff training, Legal updates, Procedural framework, Oversight, Legal liabilities, Reputation management, Compliance program, Compliance partner, Business operations.');
  OpenGraph::setTitle('Navigating Corporate Compliance: Ensuring Legal Adherence in Operations');
  OpenGraph::setUrl('https://onlinecompany.co.in/corporate-compliance');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');  
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Navigating Corporate Compliance: Ensuring Legal Adherence in Operations');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('home-sections.corporate-compliance',compact('blogs','recentblogs','RecentVideos'));
}

public function convert_business()
{
  SEOMeta::setTitle('Transforming Pvt Ltd to OPC: The Companies Act, 2013 Conversion Process',false);
  SEOMeta::setDescription(' Delve into the procedures and possibilities of transforming a Private Limited Company (PLC) into an efficient and versatile One Person Company (OPC), as authorized by the Companies Act, 2013. With the introduction of Section 18 on April 1, 2014, this legal avenue allows registered private limited companies to undergo this strategic conversion, adapting their corporate structure to changing business needs. Explore the detailed process and prerequisites required for a seamless transition from a PLC to an OPC.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/convert-business');
  SEOMeta::setkeywords(' Conversion, Pvt Ltd, One Person Company, Companies Act 2013, Legal process, Corporate structure, Business transformation, Section 18, Private Limited Company, Registered, OPC, PLC.');
  OpenGraph::setTitle('Transforming Pvt Ltd to OPC: The Companies Act, 2013 Conversion Process');
  OpenGraph::setUrl('https://onlinecompany.co.in/convert-business');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Transforming Pvt Ltd to OPC: The Companies Act, 2013 Conversion Process');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('home-sections.convert-business',compact('blogs','recentblogs','RecentVideos'));
}

public function shop_registration()
{
  SEOMeta::setTitle('Shop Registration in India: The Importance of Shop and Establishment Certification',false);
  SEOMeta::setDescription(' Learn about the mandatory registration process for shops and business establishments in India under the applicable state Act. Whether your business operates from a physical location or from the comfort of your home, compliance with the law necessitates obtaining a Shop and Establishment Registration Certificate or Shop Licence ("Certificate"). Discover the key requirements and significance of this certification in ensuring legal compliance for businesses across the country.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/shop-registration');
  SEOMeta::setkeywords('Shop registration, Business establishments, Shop and Establishment Registration Certificate, Shop Licence, Indian businesses, Compliance, State Act, Legal requirements, Business registration, Home-based business, Certification.');
  OpenGraph::setTitle('Shop Registration in India: The Importance of Shop and Establishment Certification');
  OpenGraph::setUrl('https://onlinecompany.co.in/shop-registration');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Shop Registration in India: The Importance of Shop and Establishment Certification');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('home-sections.shop-registration',compact('blogs','recentblogs','RecentVideos'));
}

public function labour_compliance()
{
  SEOMeta::setTitle('Demystifying Labor Compliance in India: A Complex Landscape Unveiled',false);
  SEOMeta::setDescription(' Navigating the labyrinth of labor compliance in India can be a complex and demanding task. Multinational corporations with multiple locations find themselves managing an array of labor-related requirements every month, ranging from licenses and registrations to consent orders, permissions, and renewals. This challenge underscores the importance of understanding and efficiently meeting the various labor compliance obligations in the Indian context.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/labour-compliance');
  SEOMeta::setkeywords('Labour compliance, Labor laws, India, Multinational company, Licenses, Registrations, Consent orders, Permissions, Renewals, Compliance challenges, Indian labor regulations.');
  OpenGraph::setTitle('Demystifying Labor Compliance in India: A Complex Landscape Unveiled');
  OpenGraph::setUrl('https://onlinecompany.co.in/labour-compliance');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Demystifying Labor Compliance in India: A Complex Landscape Unveiled');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('home-sections.labour-compliance',compact('blogs','recentblogs','RecentVideos'));
}

public function gst_taxs()
{
  
  SEOMeta::setTitle('Unraveling the Impact of GST: Simplifying Indias Tax Structure',false);
  SEOMeta::setDescription('Explore the transformative effect of the Goods and Services Tax (GST) in India, which has streamlined the tax landscape by replacing numerous indirect taxes with a single, unified system. With its CGST, SGST, and IGST components, GST applies to both goods and services, reducing complexity, eliminating double taxation, and driving economic growth. Discover how GST has contributed to a more comprehensible and efficient tax structure, ultimately benefiting the Indian economy.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/gst-taxs');
  SEOMeta::setkeywords('GST, Goods and Services Tax, Tax reform, Tax structure, CGST, SGST, IGST, Indirect taxes, Economic growth, Tax simplification, Indian tax system.');
  OpenGraph::setTitle('Unraveling the Impact of GST: Simplifying Indias Tax Structure');
  OpenGraph::setUrl('https://onlinecompany.co.in/gst-taxs');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Unraveling the Impact of GST: Simplifying Indias Tax Structure');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('home-sections.gst-taxs',compact('blogs','recentblogs','RecentVideos'));
}


public function licenses()
{

  SEOMeta::setTitle('The Vital Role of Business Licenses and Registrations in City Compliance',false);
  SEOMeta::setDescription(' Delve into the significance of obtaining business licenses and registrations for new enterprises in various cities. While some business owners may consider delaying this step until they are financially stable, adhering to licensing regulations is essential from the outset. Business licenses not only grant the legal authority to operate but also enhance the companys credibility and open doors to potential city-wide support. Explore the importance of compliance and the benefits of securing these essential permits for a successful business venture.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/licenses');
  SEOMeta::setkeywords('License, Registration, Business licenses, City compliance, Legal requirements, Credibility, Business support, New enterprises, Compliance regulations, Permits, City permits.');
  OpenGraph::setTitle('Unraveling the Impact of GST: Simplifying Indias Tax Structure');
  OpenGraph::setUrl('https://onlinecompany.co.in/licenses');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Unraveling the Impact of GST: Simplifying Indias Tax Structure');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('home-sections.licenses',compact('blogs','recentblogs','RecentVideos'));
}

public function contact()
{

  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('home-sections.contact',compact('blogs','recentblogs','RecentVideos'));
}

public function about()
{
  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('home-sections.about',compact('blogs','recentblogs','RecentVideos'));
}

public function privacy_policy()
{
  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('home-sections.privacy-policy',compact('blogs','recentblogs','RecentVideos'));
}

public function signup()
{
  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('home-sections.signup',compact('blogs','recentblogs','RecentVideos'));
}


public function gst_registration()
{
  SEOMeta::setTitle('Mandatory GST Registration: Indias Threshold and Requirements',false);
  SEOMeta::setDescription('Discover the essentials of Goods and Services Tax (GST) registration in India. Businesses and individuals involved in the supply of goods or services must comply with GST regulations if their annual turnover exceeds Rs. 40 lakhs (for goods suppliers) or Rs. 20 lakhs (for service providers). This overview outlines the mandatory requirements and threshold limits for GST registration, ensuring you are well-informed about this crucial tax compliance in India.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/gst-registration');
  SEOMeta::setkeywords('GST Registration, Goods and Services Tax, Tax compliance, Indian taxation, Annual turnover, GST requirements, Goods suppliers, Service providers, Threshold limits, GST regulations.');
  OpenGraph::setTitle('Mandatory GST Registration: Indias Threshold and Requirements');
  OpenGraph::setUrl('https://onlinecompany.co.in/gst-registration');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Mandatory GST Registration: Indias Threshold and Requirements');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');      
  $blogs = $this->userAuth()->getAllBlogs();           
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('service-sub-pages.gst-registration',compact('blogs','recentblogs','RecentVideos'));
}

public function gst_filing()
{
  SEOMeta::setTitle('Demystifying GST Filing: Reporting Sales, Purchases, and Tax Payments',false);
  SEOMeta::setDescription('Gain clarity on the essential process of GST Filing, a crucial aspect of Goods and Services Tax compliance in India. This procedure involves submitting detailed records of sales, purchases, and tax payments to the government for a specific timeframe. Explore the significance of accurate and timely GST filing and how it ensures businesses adhere to tax regulations while maintaining transparency with the tax authorities.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/gst-filing');
  SEOMeta::setkeywords('GST Filing, Goods and Services Tax, Tax compliance, Tax returns, Sales details, Purchase records, Tax payments, GST portal, Indian taxation, Tax reporting, Transparency.');
  OpenGraph::setTitle('Demystifying GST Filing: Reporting Sales, Purchases, and Tax Payments');
  OpenGraph::setUrl('https://onlinecompany.co.in/gst-filing');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Demystifying GST Filing: Reporting Sales, Purchases, and Tax Payments');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $blogs = $this->userAuth()->getAllBlogs();
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('service-sub-pages.gst-filing',compact('blogs','recentblogs','RecentVideos'));
}

public function gst_advisory()
{
  SEOMeta::setTitle('Navigating GST Compliance with Expert GST Advisory Services',false);
  SEOMeta::setDescription(' Explore the invaluable support offered by GST Advisory services, where seasoned professionals guide businesses through the intricate web of Goods and Services Tax (GST) laws and regulations in India. These experts provide strategic counsel on critical aspects, including GST registration, return filing, and maximizing input tax credits, among others. Discover how GST Advisory services can streamline your compliance, ensuring smooth operations and adherence to GST rules.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/gst-advisory');
  SEOMeta::setkeywords('GST Advisory, Goods and Services Tax, Tax compliance, GST laws, GST regulations, Registration, Return filing, Input tax credit, Expert guidance, GST experts, Indian taxation.');
  OpenGraph::setTitle('Navigating GST Compliance with Expert GST Advisory Services');
  OpenGraph::setUrl('https://onlinecompany.co.in/gst-advisory');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Navigating GST Compliance with Expert GST Advisory Services');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $blogs = $this->userAuth()->getAllBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  return view('service-sub-pages.gst-advisory',compact('blogs','recentblogs','RecentVideos'));
}

public function tds_return_filing()
{
  SEOMeta::setTitle('Simplified TDS Return Filing: Reporting Deductions to the Income Tax Department',false);
  SEOMeta::setDescription('Gain insight into the straightforward process of TDS (Tax Deducted at Source) Return Filing, which involves the submission of deducted and deposited TDS details to the Income Tax Department. This essential procedure ensures businesses and individuals comply with tax regulations, accurately reporting their tax deductions and maintaining transparency with tax authorities. Explore the significance of timely and precise TDS return filing in India.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/tds-return-filing');
  SEOMeta::setkeywords('TDS Return Filing, Tax Deducted at Source, Income Tax Department, Tax compliance, Tax deductions, Financial reporting, Indian taxation, Deducted TDS details, Tax authorities.');
  OpenGraph::setTitle('Simplified TDS Return Filing: Reporting Deductions to the Income Tax Department');
  OpenGraph::setUrl('https://onlinecompany.co.in/tds-return-filing');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Simplified TDS Return Filing: Reporting Deductions to the Income Tax Department');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.tds-return-filing',compact('blogs','recentblogs','RecentVideos'));
}

public function individual_income_tax_filing()
{
  SEOMeta::setTitle('Simplified TDS Return Filing: Reporting Deductions to the Income Tax Department',false);
  SEOMeta::setDescription('Gain insight into the straightforward process of TDS (Tax Deducted at Source) Return Filing, which involves the submission of deducted and deposited TDS details to the Income Tax Department. This essential procedure ensures businesses and individuals comply with tax regulations, accurately reporting their tax deductions and maintaining transparency with tax authorities. Explore the significance of timely and precise TDS return filing in India.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/individual-income-tax-filing');
  SEOMeta::setkeywords('TDS Return Filing, Tax Deducted at Source, Income Tax Department, Tax compliance, Tax deductions, Financial reporting, Indian taxation, Deducted TDS details, Tax authorities.');
  OpenGraph::setTitle('Simplified TDS Return Filing: Reporting Deductions to the Income Tax Department');
  OpenGraph::setUrl('https://onlinecompany.co.in/individual-income-tax-filing');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Simplified TDS Return Filing: Reporting Deductions to the Income Tax Department');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.individual-income-tax-filing',compact('blogs','recentblogs','RecentVideos'));
}

public function proprietorship_tax_return_filing()
{
  SEOMeta::setTitle('Sole Proprietorship Tax Return Filing: Reporting Business Income for Entrepreneurs',false);
  SEOMeta::setDescription(' Dive into the essential process of Sole Proprietorship Tax Return Filing, where solo entrepreneurs report the income generated by their businesses during a fiscal year. This procedure is integral to income tax compliance for proprietors, ensuring accurate reporting of business earnings and fulfilling financial obligations. Explore the significance of timely and precise tax return filing for sole proprietors in India.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/proprietorship-tax-return-filing');
  SEOMeta::setkeywords('Sole Proprietorship, Tax Return Filing, Income Tax, Business income, Tax compliance, Financial reporting, Entrepreneurship, Fiscal year, Indian taxation, Proprietors tax obligations.');
  OpenGraph::setTitle('Sole Proprietorship Tax Return Filing: Reporting Business Income for Entrepreneurs');
  OpenGraph::setUrl('https://onlinecompany.co.in/proprietorship-tax-return-filing');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Sole Proprietorship Tax Return Filing: Reporting Business Income for Entrepreneurs');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.proprietorship-tax-return-filing',compact('blogs','recentblogs','RecentVideos'));
}

public function digital_signature_certificate()
{
  SEOMeta::setTitle('Unlocking Security and Trust: The Digital Signature Certificate (DSC)',false);
  SEOMeta::setDescription('  Explore the world of digital identity verification with the Digital Signature Certificate (DSC), a secure and unassailable tool that authenticates individuals, organizations, and governments in the electronic realm. This digital counterpart to traditional handwritten or rubber-stamped seals revolutionizes the way we sign and validate documents, ensuring heightened security and trust in the digital age. Delve into the significance and applications of the Digital Signature Certificate for a safer and more efficient online experience.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/digital-signature-certificate');
  SEOMeta::setkeywords('Digital Signature Certificate, DSC, Electronic identity verification, Digital identity, Electronic signature, Secure verification, Online trust, Digital authentication, Document signing, Cybersecurity, Digital age.');
  OpenGraph::setTitle('Unlocking Security and Trust: The Digital Signature Certificate (DSC)');
  OpenGraph::setUrl('https://onlinecompany.co.in/digital-signature-certificate');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Unlocking Security and Trust: The Digital Signature Certificate (DSC)');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.digital-signature-certificate',compact('blogs','recentblogs','RecentVideos'));
}


public function msme_ssi_registration()
{
    SEOMeta::setTitle('Empowering Growth: MSME/SSI Registration and Indias Small-Scale Industries',false);
    SEOMeta::setDescription('Uncover the significance of MSME/SSI Registration, a critical step in supporting Indias thriving Small Scale Industries (SSI). These sectors, known for their micro or small-scale production, manufacturing, and service delivery, are the backbone of the Indian economy, fostering employment opportunities and driving economic growth. Explore the importance of registration in empowering these industries and learn how they play a pivotal role in the countrys economic landscape.');
    SEOMeta::setCanonical('https://onlinecompany.co.in/msme-ssi-registration');
    SEOMeta::setkeywords('MSME Registration, SSI Registration, Small Scale Industries, Micro and Small Enterprises, Indian economy, Employment prospects, Economic growth, Small-scale production, Manufacturing, Service delivery, Economic foundation.');
    OpenGraph::setTitle('Empowering Growth: MSME/SSI Registration and Indias Small-Scale Industries');
    OpenGraph::setUrl('https://onlinecompany.co.in/msme-ssi-registration');
    OpenGraph::addProperty('type', 'website');
    OpenGraph::setSiteName('onlinecompany');
    OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
    Twitter::setTitle('Empowering Growth: MSME/SSI Registration and Indias Small-Scale Industries');
    Twitter::addValue('card', 'summary');
    Twitter::setImage('');
    Twitter::addValue('creator', '@onlinecompany');
    
    $recentblogs =$this->userAuth()->getRecentBlogs();
    $RecentVideos =$this->userAuth()->getRecentVideos();
    $blogs = $this->userAuth()->getAllBlogs();
    return view('service-sub-pages.msme-ssi-registration',compact('blogs','recentblogs','RecentVideos'));
}

public function iso_certification()
{
  SEOMeta::setTitle('Elevate Your Standards: The Significance of ISO Certification',false);
  SEOMeta::setDescription(' Discover the profound significance of ISO Certification, a prestigious mark of approval that attests to a companys adherence to international standards set by the International Organisation for Standardisation (ISO). ISO, a non-profit global organization, unites experts to develop and disseminate standards that drive technological advancements and address pressing global challenges. Delve into the world of ISO Certification and its role in elevating quality, trust, and global collaboration.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/iso-certification');
  SEOMeta::setkeywords('ISO Certification, International Organisation for Standardisation, Quality standards, Global standards, Certification mark, Standard compliance, Technological advancements, Global collaboration, Quality assurance, ISO standards.');
  OpenGraph::setTitle('Elevate Your Standards: The Significance of ISO Certification');
  OpenGraph::setUrl('https://onlinecompany.co.in/iso-certification');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Elevate Your Standards: The Significance of ISO Certification');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.iso-certification',compact('blogs','recentblogs','RecentVideos'));
}

public function fssai_registration_online()
{
  SEOMeta::setTitle('Safeguarding Food Safety: Online FSSAI Registration in India',false);
  SEOMeta::setDescription(' Explore the essential process of FSSAI Registration Online, a mandatory requirement for all food-related businesses in India as per the Food Safety and Standards Act of 2006. This registration ensures that food products produced, stored, or distributed by these enterprises comply with specific safety standards and regulations. Delve into the significance of online FSSAI registration in safeguarding food safety and upholding the well-being of consumers across the nation.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/fssai-registration-online');
  SEOMeta::setkeywords('FSSAI Registration, Food Safety and Standards Act, Online registration, Food safety compliance, Food business, Food safety standards, Consumer well-being, Food safety regulations, India, Food safety certificate.');
  OpenGraph::setTitle('Safeguarding Food Safety: Online FSSAI Registration in India');
  OpenGraph::setUrl('https://onlinecompany.co.in/fssai-registration-online');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Safeguarding Food Safety: Online FSSAI Registration in India');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.fssai-registration-online',compact('blogs','recentblogs','RecentVideos'));
}

public function iec_import_export_code()
{
  SEOMeta::setTitle('Navigating Global Trade: Understanding the IEC Import/Export Code in India',false);
  SEOMeta::setDescription(' Gain insight into the world of global trade with the Import/Export Code (IEC) in India, a 10-digit identification issued by the Directorate General of Foreign Trade (DGFT). This code is essential for businesses engaged in importing or exporting goods and services, ensuring compliance with international trade regulations. Explore the significance and purpose of the IEC code in facilitating seamless cross-border trade and enabling businesses to participate in the global marketplace.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/iec-import-export-code');
  SEOMeta::setkeywords('IEC code, Import/Export Code, Directorate General of Foreign Trade, International trade, Cross-border trade, Indian businesses, Global trade compliance, Exporters, Importers, Trade regulations, Global marketplace.');
  OpenGraph::setTitle('Navigating Global Trade: Understanding the IEC Import/Export Code in India');
  OpenGraph::setUrl('https://onlinecompany.co.in/iec-import-export-code');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Navigating Global Trade: Understanding the IEC Import/Export Code in India');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.iec-import-export-code',compact('blogs','recentblogs','RecentVideos'));
}

public function bis_registration()
{
  SEOMeta::setTitle('Elevating Quality: Understanding BIS Registration in India',false);
  SEOMeta::setDescription(' Explore the realm of product standardization, labeling, and quality certification through BIS Registration, a critical process regulated by the Bureau of Indian Standards (BIS), as established under the BIS Act of 2016. BIS plays a pivotal role in advancing orderly development and regulation in these areas, enhancing product quality, reducing consumer health risks, promoting import and export opportunities, and curbing product variety proliferation. Discover how BIS Registration contributes to the traceable and discernible benefits that bolster Indias national economy.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/bis-registration');
  SEOMeta::setkeywords(' BIS Registration, Bureau of Indian Standards, Product standardization, Quality certification, Indian National Standard Body, BIS Act, Quality standards, Product labeling, Traceable benefits, Consumer health, Import and export, Product quality, National economy.');
  OpenGraph::setTitle('Elevating Quality: Understanding BIS Registration in India');
  OpenGraph::setUrl('https://onlinecompany.co.in/iec-bis-registration');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Elevating Quality: Understanding BIS Registration in India');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.bis-registration',compact('blogs','recentblogs','RecentVideos'));
}

public function esi_registration()
{
  SEOMeta::setTitle('Empowering the Workforce: ESI Registration for Social Security in India',false);
  SEOMeta::setDescription(' Uncover the expansive social security initiative known as ESI Registration, designed to extend vital protection to employees in the organized sector in India. This program aims to safeguard employees against a range of lifes uncertainties, including disability, illness, maternity, and workplace-related injuries leading to death. ESI Registration also ensures access to medical care for covered employees and their dependents, fostering a more secure and supported workforce. Delve into the significance of this program in empowering the Indian workforce.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/esi-registration');
  SEOMeta::setkeywords('ESI Registration, Social security, Organized sector, Employee benefits, Workplace safety, Disability protection, Maternity benefits, Medical care, Employee well-being, Dependents, Indian workforce.');
  OpenGraph::setTitle('Empowering the Workforce: ESI Registration for Social Security in India');
  OpenGraph::setUrl('https://onlinecompany.co.in/esi-registration');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Empowering the Workforce: ESI Registration for Social Security in India');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.esi-registration',compact('blogs','recentblogs','RecentVideos'));
}

public function provident_fund_registration()
{
  SEOMeta::setTitle('Securing the Future: Provident Fund Registration for Employee Retirement Benefits',false);
  SEOMeta::setDescription('Explore the essential process of Provident Fund (PF) Registration, a mandatory requirement for businesses in India with 20 or more employees (or 10 employees in certain states). This registration is integral to providing retirement benefits to employees, ensuring their financial security and well-being post-retirement. Delve into the significance of PF Registration in securing the future of the workforce and fostering long-term financial stability.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/provident-fund-registration');
  SEOMeta::setkeywords('Provident Fund Registration, PF Registration, Retirement benefits, Employee retirement, Financial security, Employee well-being, Mandatory registration, Indian businesses, Workforce retirement, Long-term financial stability, Retirement planning.');
  OpenGraph::setTitle('Securing the Future: Provident Fund Registration for Employee Retirement Benefits');
  OpenGraph::setUrl('https://onlinecompany.co.in/provident-fund-registration');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Securing the Future: Provident Fund Registration for Employee Retirement Benefits');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.provident-fund-registration',compact('blogs','recentblogs','RecentVideos'));
}

public function professional_tax_registration()
{
  SEOMeta::setTitle('Professional Tax Registration: Navigating State Taxation for Professionals and Businesses',false);
  SEOMeta::setDescription('Explore the realm of Professional Tax Registration, a state-level tax imposed on salaried employees, professionals, and traders for the practice of their professions or the conduct of their businesses in India. This registration is a vital compliance requirement that ensures professionals and businesses contribute to state revenues while enabling them to operate legally. Delve into the importance of Professional Tax Registration and its role in state taxation for professionals and businesses.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/professional-tax-registration');
  SEOMeta::setkeywords('Professional Tax Registration, State taxation, Tax compliance, Salaried employees, Professionals, Traders, State tax, Business taxation, Professional tax in India, Tax on professionals, Tax on businesses, Tax registration.');
  OpenGraph::setTitle('Professional Tax Registration: Navigating State Taxation for Professionals and Businesses');
  OpenGraph::setUrl('https://onlinecompany.co.in/professional-tax-registration');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Professional Tax Registration: Navigating State Taxation for Professionals and Businesses');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.professional-tax-registration',compact('blogs','recentblogs','RecentVideos'));
}

public function shops_and_establishments_license()
{
  SEOMeta::setTitle('Shops and Establishments License: Ensuring Compliance and Employee Welfare',false);
  SEOMeta::setDescription(' Delve into the world of Shops and Establishments License, a compulsory registration mandated for businesses operating within a state. Issued by the state government, this license serves to regulate and oversee the working conditions of employees in shops, commercial establishments, and various businesses. Explore the significance of this license in ensuring both business compliance and the welfare of employees, promoting a balanced and well-regulated working environment.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/shops-and-establishments-license');
  SEOMeta::setkeywords('Shops and Establishments License, Business registration, State government, Employee working conditions, Commercial establishments, Regulatory compliance, Business operations, License requirements, State-specific license.');
  OpenGraph::setTitle('Shops and Establishments License: Ensuring Compliance and Employee Welfare');
  OpenGraph::setUrl('https://onlinecompany.co.in/shops-and-establishments-license');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Shops and Establishments License: Ensuring Compliance and Employee Welfare');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.shops-and-establishments-license',compact('blogs','recentblogs','RecentVideos'));
}

public function employees_stock_option_plan()
{
  SEOMeta::setTitle('Empowering Employees: Understanding Employee Stock Option Plans (ESOPs)',false);
  SEOMeta::setDescription('Explore the dynamic concept of Employee Stock Option Plans (ESOPs), a program that empowers employees by granting them the opportunity to purchase a specific number of company shares at a reduced price. ESOPs are a strategic tool used by companies to reward and incentivize their workforce while aligning their interests with the organizations success. Delve into the significance and benefits of ESOPs in fostering employee engagement and commitment.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/employees-stock-option-plan');
  SEOMeta::setkeywords('Employee Stock Option Plan, ESOP, Employee benefits, Stock options, Employee incentives, Company shares, Employee engagement, Compensation, Workforce rewards, Employee ownership.');
  OpenGraph::setTitle('Empowering Employees: Understanding Employee Stock Option Plans (ESOPs)');
  OpenGraph::setUrl('https://onlinecompany.co.in/employees-stock-option-plan');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Empowering Employees: Understanding Employee Stock Option Plans (ESOPs)');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.employees-stock-option-plan',compact('blogs','recentblogs','RecentVideos'));
}

public function posh_compliance()
{
  SEOMeta::setTitle('Empowering Safe Workplaces: Navigating POSH Compliance in India',false);
  SEOMeta::setDescription('Delve into the realm of POSH Compliance, a critical requirement outlined in the Prevention of Sexual Harassment (POSH) of Women at the Workplace Act, 2013. This Act necessitates that all employers in India with more than 10 employees establish and enforce policies and procedures to prevent sexual harassment within the workplace. Explore the significance of POSH Compliance in fostering safe and inclusive work environments, ensuring the well-being and dignity of employees.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/posh-compliance');
  SEOMeta::setkeywords('POSH Compliance, Prevention of Sexual Harassment Act, Workplace safety, Employee well-being, Indian workplace, Sexual harassment prevention, Workplace policies, Employee dignity, Workplace inclusivity, Safe workplaces, Legal compliance.');
  OpenGraph::setTitle('Empowering Safe Workplaces: Navigating POSH Compliance in India');
  OpenGraph::setUrl('https://onlinecompany.co.in/posh-compliance');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Empowering Safe Workplaces: Navigating POSH Compliance in India');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.posh-compliance',compact('blogs','recentblogs','RecentVideos'));
}

public function rbi_compliance()
{
  SEOMeta::setTitle('Crafting a Culture of Respect: Prioritizing POSH Compliance in India',false);
  SEOMeta::setDescription('Delve into the imperative world of POSH Compliance in India, where the Prevention of Sexual Harassment (POSH) of Women at the Workplace Act, 2013, is the guiding light. This act mandates that all employers with over 10 employees establish and enforce policies and procedures to prevent sexual harassment. Learn how POSH Compliance is instrumental in shaping a workplace culture that values respect, dignity, and the well-being of all employees, and fosters an inclusive and secure environment.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/rbi-compliance');
  SEOMeta::setkeywords('POSH Compliance, Prevention of Sexual Harassment Act, Workplace safety, Employee well-being, Indian workplace, Sexual harassment prevention, Workplace policies, Employee dignity, Workplace inclusivity, Respectful workplace, Legal compliance.');
  OpenGraph::setTitle('Empowering Safe Workplaces: Navigating POSH Compliance in India');
  OpenGraph::setUrl('https://onlinecompany.co.in/rbi-compliance');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Empowering Safe Workplaces: Navigating POSH Compliance in India');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.rbi-compliance',compact('blogs','recentblogs','RecentVideos'));
}

public function balance_sheet_preparation_and_matching()
{
  SEOMeta::setTitle('Mastering Financial Clarity: Balance Sheet Preparation and Alignment',false);
  SEOMeta::setDescription('Uncover the art of financial transparency through Balance Sheet Preparation and Matching, where a snapshot of a companys financial health is presented at a specific point in time. This essential financial statement meticulously details the assets, liabilities, and equity of the business, providing a comprehensive insight into its financial position. Explore the significance of expertly prepared balance sheets and the importance of aligning financial elements for a clear and accurate representation of a companys financial status.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/balance-sheet-preparation-and-matching');
  SEOMeta::setkeywords('Balance sheet, Financial statement, Financial position, Asset assessment, Liability analysis, Equity evaluation, Financial transparency, Accounting, Financial health, Companys financial status, Financial overview.  ');
  OpenGraph::setTitle('Mastering Financial Clarity: Balance Sheet Preparation and Alignment');
  OpenGraph::setUrl('https://onlinecompany.co.in/balance-sheet-preparation-and-matching');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Mastering Financial Clarity: Balance Sheet Preparation and Alignment');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.balance-sheet-preparation-and-matching',compact('blogs','recentblogs','RecentVideos'));
}

public function proprietorship_to_pvt_ltd_company()
{
  SEOMeta::setTitle('Evolving from Proprietorship to Private Limited Company: Benefits and Transformation',false);
  SEOMeta::setDescription(' Explore the strategic transition from a Proprietorship to a Private Limited Company, a decision driven by several compelling reasons. This transformation elevates business dynamics by limiting the liability of owners and shareholders to the value of their ownership stakes, shielding personal assets in times of financial distress. Additionally, a Private Limited Company gains access to increased funding opportunities through share sales and investments, enhancing financial flexibility. The distinct legal identity bestowed upon it also bolsters credibility in the competitive marketplace. Discover the myriad advantages and the process of this transformation for businesses.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/proprietorship-to-pvt-ltd-company');
  SEOMeta::setkeywords('Proprietorship to Private Limited Company, Business transformation, Limited liability, Personal assets protection, Funding opportunities, Share sales, Investments, Enhanced credibility, Legal identity, Business evolution, Company structure. ');
  OpenGraph::setTitle('Mastering Financial Clarity: Balance Sheet Preparation and Alignment');
  OpenGraph::setUrl('https://onlinecompany.co.in/proprietorship-to-pvt-ltd-company');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Mastering Financial Clarity: Balance Sheet Preparation and Alignment');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.proprietorship-to-pvt-ltd-company',compact('blogs','recentblogs','RecentVideos'));
}

public function compliance_check_secretarial_audit()
{
  SEOMeta::setTitle('Ensuring Corporate Compliance: The Role of Secretarial Audi',false);
  SEOMeta::setDescription(' Explore the pivotal role of Secretarial Audit in upholding corporate compliance. This independent review, conducted in accordance with the Companies Act, 2013, and other relevant laws, meticulously assesses a companys adherence to legal and regulatory requirements. Secretarial Audit hones in on various provisions of the law, identifying any instances of non-compliance and offering remedial recommendations. Delve into the significance of this audit in safeguarding a companys legal standing and its commitment to operating within the bounds of the law.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/proprietorship-to-pvt-ltd-company');
  SEOMeta::setkeywords('Compliance check, Secretarial audit, Companies Act 2013, Regulatory requirements, Legal compliance, Non-compliance, Corrective actions, Corporate governance, Audit process, Legal standing, Regulatory review. ');
  OpenGraph::setTitle('Mastering Financial Clarity: Balance Sheet Preparation and Alignment');
  OpenGraph::setUrl('https://onlinecompany.co.in/proprietorship-to-pvt-ltd-company');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Mastering Financial Clarity: Balance Sheet Preparation and Alignment');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.compliance-check-secretarial-audit',compact('blogs','recentblogs',''));
}

public function partnership_to_llp()
{
  SEOMeta::setTitle('Elevating Security: Transitioning from Partnership to Limited Liability Partnership (LLP)',false);
  SEOMeta::setDescription('Elevating Security: Transitioning from Partnership to Limited Liability Partnership (LLP)');
  SEOMeta::setCanonical('https://onlinecompany.co.in/partnership-to-llp');
  SEOMeta::setkeywords('Compliance check, Secretarial audit, Companies Act 2013, Regulatory requirements, Legal compliance, Non-compliance, Corrective actions, Corporate governance, Audit process, Legal standing, Regulatory review. ');
  OpenGraph::setTitle('Mastering Financial Clarity: Balance Sheet Preparation and Alignment');
  OpenGraph::setUrl('https://onlinecompany.co.in/partnership-to-llp');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Mastering Financial Clarity: Balance Sheet Preparation and Alignment');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.partnership-to-llp',compact('blogs','recentblogs','RecentVideos'));
}

public function private_to_public_limited_company()
{
  SEOMeta::setTitle('Unleashing Growth Potential: Transitioning from Private to Public Limited Company',false);
  SEOMeta::setDescription(' Explore the strategic evolution from a Private Limited Company to a Public Limited Company, a transformation that opens new vistas of business expansion and financial possibilities. One of the key advantages is the ability to raise funds from the public through the issuance of shares, providing a valuable avenue for business growth and diversification. Delve into the significance of this transition and the financial opportunities it unlocks for companies poised for expansion and market prominence.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/private-to-public-limited-company');
  SEOMeta::setkeywords('Private to Public Limited Company, Business transformation, Funding opportunities, Share issuance, Public funding, Business expansion, Capital raising, Financial growth, Market prominence, Company evolution.');
  OpenGraph::setTitle('Unleashing Growth Potential: Transitioning from Private to Public Limited Company');
  OpenGraph::setUrl('https://onlinecompany.co.in/private-to-public-limited-company');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Unleashing Growth Potential: Transitioning from Private to Public Limited Company');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.private-to-public-limited-company',compact('blogs','recentblogs','RecentVideos'));
}

public function private_limited_to_one_person_company()
{
  SEOMeta::setTitle('Unlocking Opportunities: Transitioning from Private Limited to One Person Company (OPC',false);
  SEOMeta::setDescription('Embark on a journey of business transformation as you transition from a Private Limited Company to a One Person Company (OPC), an evolution laden with benefits. The shift to an OPC offers valuable tax advantages, resembling that of a regular company, which can be advantageous compared to a sole proprietorship. It also bestows upon the business a separate legal identity, enhancing its credibility and market reputation. Moreover, the liability of the sole shareholder in an OPC is confined to the extent of their shareholding, offering peace of mind and security. Explore the significance of this transition and its potential to unlock new opportunities and efficiencies.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/private-limited-to-one-person-company');
  SEOMeta::setkeywords('Private Limited to One Person Company, Business transformation, Tax benefits, Separate legal entity, Market credibility, Limited liability, Sole shareholder, Business evolution, Tax advantages, OPC advantages.');
  OpenGraph::setTitle('Unlocking Opportunities: Transitioning from Private Limited to One Person Company (OPC');
  OpenGraph::setUrl('https://onlinecompany.co.in/private-limited-to-one-person-company');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Unlocking Opportunities: Transitioning from Private Limited to One Person Company (OPC');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.private-limited-to-one-person-company',compact('blogs','recentblogs','RecentVideos'));
}

public function private_limited_company()
{
  SEOMeta::setTitle('Unlocking Opportunities: Transitioning from Private Limited to One Person Company (OPC',false);
  SEOMeta::setDescription('Embark on a journey of business transformation as you transition from a Private Limited Company to a One Person Company (OPC), an evolution laden with benefits. The shift to an OPC offers valuable tax advantages, resembling that of a regular company, which can be advantageous compared to a sole proprietorship. It also bestows upon the business a separate legal identity, enhancing its credibility and market reputation. Moreover, the liability of the sole shareholder in an OPC is confined to the extent of their shareholding, offering peace of mind and security. Explore the significance of this transition and its potential to unlock new opportunities and efficiencies.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/private-limited-to-one-person-company');
  SEOMeta::setkeywords('Private Limited to One Person Company, Business transformation, Tax benefits, Separate legal entity, Market credibility, Limited liability, Sole shareholder, Business evolution, Tax advantages, OPC advantages.');
  OpenGraph::setTitle('Unlocking Opportunities: Transitioning from Private Limited to One Person Company (OPC');
  OpenGraph::setUrl('https://onlinecompany.co.in/private-limited-to-one-person-company');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Unlocking Opportunities: Transitioning from Private Limited to One Person Company (OPC');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.private-limited-company',compact('blogs','recentblogs','RecentVideos'));
}

public function limited_liability_partnership()
{
  SEOMeta::setTitle('Balancing Flexibility and Protection: The World of Limited Liability Partnerships (LLP)',false);
  SEOMeta::setDescription(' Explore the dynamic world of Limited Liability Partnerships (LLP), a unique corporate structure that seamlessly blends the flexibility of a partnership with the invaluable limited liability protection of a company. An LLP boasts a distinct legal identity and is registered as a separate legal entity, setting it apart from its partners. Delve into the significance of this structure, which empowers businesses to maintain flexibility while safeguarding personal assets and fostering credibility in the corporate landscape.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/limited-liability-partnership');
  SEOMeta::setkeywords('Private Limited to One Person Company, Business transformation, Tax benefits, Separate legal entity, Market credibility, Limited liability, Sole shareholder, Business evolution, Tax advantages, OPC advantages.');
  OpenGraph::setTitle('Balancing Flexibility and Protection: The World of Limited Liability Partnerships (LLP)');
  OpenGraph::setUrl('https://onlinecompany.co.in/limited-liability-partnership');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Unlocking Opportunities: Transitioning from Private Limited to One Person Company (OPC');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.limited-liability-partnership',compact('blogs','recentblogs','RecentVideos'));
}

public function one_person_company()
{
  SEOMeta::setTitle('Solo Entrepreneurship Reinvented: The Power of the One Person Company (OPC)',false);
  SEOMeta::setDescription(' Explore the innovative realm of the One Person Company (OPC), a distinctive corporate structure that empowers solo entrepreneurs to own and manage their own businesses. An OPC boasts a unique legal personality, separate from its owner, and is registered as a distinct legal entity. Delve into the significance of this structure, which redefines entrepreneurship by offering personal liability protection and enabling individual business ventures to thrive with a distinct legal identity.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/one-person-company');
  SEOMeta::setkeywords('One Person Company, OPC, Solo entrepreneurship, Corporate structure, Legal personality, Business management, Legal entity, Solo business ownership, Entrepreneurial innovation, Personal liability protection.');
  OpenGraph::setTitle('Solo Entrepreneurship Reinvented: The Power of the One Person Company (OPC)');
  OpenGraph::setUrl('https://onlinecompany.co.in/one-person-company');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Solo Entrepreneurship Reinvented: The Power of the One Person Company (OPC)');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.one-person-company',compact('blogs','recentblogs','RecentVideos'));
}

public function sole_proprietorship()
{
  SEOMeta::setTitle('Entrepreneurial Independence: The Dynamics of Sole Proprietorship',false);
  SEOMeta::setDescription(' Immerse yourself in the world of Sole Proprietorship, a business structure that epitomizes entrepreneurial independence. In this arrangement, a single individual owns and operates the business, but with a significant trade-off - complete legal liability for the companys obligations and liabilities. There is no legal separation between the owner and the business. Explore the intricacies and significance of this entrepreneurial journey where the individual is the heart and soul of the enterprise.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/sole-proprietorship');
  SEOMeta::setkeywords('Sole Proprietorship, Entrepreneurial independence, Business structure, Legal liability, Business ownership, Individual business, Entrepreneurship, Business dynamics, Owners obligations, Liability.');
  OpenGraph::setTitle('Entrepreneurial Independence: The Dynamics of Sole Proprietorship');
  OpenGraph::setUrl('https://onlinecompany.co.in/sole-proprietorship');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Entrepreneurial Independence: The Dynamics of Sole Proprietorship');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.sole-proprietorship',compact('blogs','recentblogs','RecentVideos'));
}

public function nidhi_company()
{
  SEOMeta::setTitle('Thrift and Trust: The World of Nidhi Companies in Financial Empowerment',false);
  SEOMeta::setDescription(' Delve into the realm of Nidhi Companies, unique non-banking financial entities (NBFCs) with a mission to foster frugal living and savings among their members. These companies exist to promote thrift and prudent financial practices, creating a platform for members to conserve and grow their money. Explore the significance of Nidhi Companies in financial empowerment, community support, and the cultivation of responsible financial habits.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/nidhi-company');
  SEOMeta::setkeywords('Nidhi Company, Thrift and savings, Financial empowerment, NBFC, Frugal living, Member savings, Responsible financial habits, Community support, Money conservation, Financial practices.');
  OpenGraph::setTitle('Thrift and Trust: The World of Nidhi Companies in Financial Empowerment');
  OpenGraph::setUrl('https://onlinecompany.co.in/nidhi-company');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Thrift and Trust: The World of Nidhi Companies in Financial Empowerment');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.nidhi-company',compact('blogs','recentblogs','RecentVideos'));
}


public function producer_company()
{
  SEOMeta::setTitle('Empowering Producers: The Dynamics of Producer Companies',false);
  SEOMeta::setDescription('Dive into the world of Producer Companies, a unique form of business formed by ten or more individuals actively involved in the production of primary goods or those aspiring to engage in activities related to primary produce. These companies are designed to empower producers, offering a platform for collective action and growth in the realm of primary produce. Explore the significance of Producer Companies in fostering cooperation, enhancing market access, and driving economic sustainability for producers.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/producer-company');
  SEOMeta::setkeywords('Producer Company, Primary produce, Cooperative farming, Producer empowerment, Market access, Economic sustainability, Agribusiness, Collective action, Rural development, Agricultural cooperation.');
  OpenGraph::setTitle('Empowering Producers: The Dynamics of Producer Companies');
  OpenGraph::setUrl('https://onlinecompany.co.in/producer-company');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Empowering Producers: The Dynamics of Producer Companies');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.producer-company',compact('blogs','recentblogs','RecentVideos'));
}

public function partnership_firm()
{
  SEOMeta::setTitle('Financial Integrity Upheld: Annual Auditing with Proper Receipts',false);
  SEOMeta::setDescription('Delve into the process of upholding financial integrity through Annual Auditing with Proper Receipts, where a companys financial records and transactions undergo meticulous examination each year to ensure accuracy and compliance with accounting regulations. Explore the significance of this annual practice in promoting transparency, accountability, and trust in financial management. The inclusion of proper receipts enhances the audit process, providing a comprehensive view of financial transactions.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/partnership-firm');
  SEOMeta::setkeywords('Annual auditing, Financial records, Accounting compliance, Financial integrity, Proper receipts, Audit process, Financial transparency, Accountability, Financial management, Compliance, Trust.');
  OpenGraph::setTitle('Financial Integrity Upheld: Annual Auditing with Proper Receipts');
  OpenGraph::setUrl('https://onlinecompany.co.in/partnership-firm');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Financial Integrity Upheld: Annual Auditing with Proper Receipts');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');
  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.partnership-firm',compact('blogs','recentblogs','RecentVideos'));
}


public function annual_auditing_with_proper_reciept()
{
  SEOMeta::setTitle('Financial Integrity Upheld: Annual Auditing with Proper Receipts',false);
  SEOMeta::setDescription('Delve into the process of upholding financial integrity through Annual Auditing with Proper Receipts, where a companys financial records and transactions undergo meticulous examination each year to ensure accuracy and compliance with accounting regulations. Explore the significance of this annual practice in promoting transparency, accountability, and trust in financial management. The inclusion of proper receipts enhances the audit process, providing a comprehensive view of financial transactions.');
  SEOMeta::setCanonical('https://onlinecompany.co.in/annual-auditing-with-proper-reciept');
  SEOMeta::setkeywords('Annual auditing, Financial records, Accounting compliance, Financial integrity, Proper receipts, Audit process, Financial transparency, Accountability, Financial management, Compliance, Trust.');
  OpenGraph::setTitle('Financial Integrity Upheld: Annual Auditing with Proper Receipts');
  OpenGraph::setUrl('https://onlinecompany.co.in/annual-auditing-with-proper-reciept');
  OpenGraph::addProperty('type', 'website');
  OpenGraph::setSiteName('onlinecompany');
  OpenGraph::addImage('', ['height' => 697, 'width' => 580]);
  Twitter::setTitle('Financial Integrity Upheld: Annual Auditing with Proper Receipts');
  Twitter::addValue('card', 'summary');
  Twitter::setImage('');
  Twitter::addValue('creator', '@onlinecompany');

  $recentblogs =$this->userAuth()->getRecentBlogs();
  $RecentVideos =$this->userAuth()->getRecentVideos();
  $blogs = $this->userAuth()->getAllBlogs();
  return view('service-sub-pages.annual-auditing-with-proper-reciept',compact('blogs','recentblogs','RecentVideos'));
}
                                                           
public function oc_professional()
{
  
  return view('home-sections.oc-professional');
}
















































  public function contactForm(Request $request)
  {

    if ($request->isMethod('post')) {

      $responseArray = array(
        'status' => '',
        'message' => ''
      );

      $data = $request->all();

      unset($data['_token']);

      //   Mail::send('mail', $data, function($message) {
      //     $message->to('himanshu.singh.cser@gmail.com', 'Today Stats')->subject
      //       ('You Have a New Querry From Online Company Site');
      //     $message->from('himanshu.singh@fincrif.com','no-reply');
      //  });

      // Mail::send('mail', $data, function ($message) {
      //   $message->to('support@onlinecompany.co.in', 'New Enquiry')->subject('You Have a New Querry From Online Company Site');
      //   $message->from('support@onlinecompany.co.in', 'no-reply');
      // });



      $responseArray = array(
        'status' => 'success',
        'message' => 'Querry Recived we will get back to you soon !'
      );

      print_r(json_encode($responseArray));
      exit();
    }
  }


  private function useractivitynew()
  {

    $test = new \App\Models\UserActivityNew();
    return $test;
  }


  public function  otpVerify(Request $request)
  {

    if ($request->isMethod('post')) {


      $requestData = $request->all();

      unset($requestData['_token']);

      if ($requestData['action'] == 'generate-otp') {

        $this->otpSent($requestData['contactNo']);
        $responseArray = array(
          'status' => 'success',
          'message' => 'otp generated'
        );

        print_r(json_encode($responseArray));
        exit();
      }


      if ($requestData['action'] == 'otp-verify') {

        $response = $this->useractivitynew()->otpVerifyNew($requestData['contactNo'], $requestData['otp']);
        if ($response) {

          $responseArray = array(
            'status' => 'success',
            'message' => 'otp verified'
          );
          
        } else {

          $responseArray = array(
            'status' => 'failed',
            'message' => 'wrong OTP'
          );
        }


        print_r(json_encode($responseArray));
        exit();
      }
    }
  }


  private function otpSent($user_contact_no)
  {

    $test_contact_no = array(
    "9795695116","9315573368","9319699891","8798749484"


    );


    $digits = 4;
    $otp =  rand(pow(10, $digits - 1), pow(10, $digits) - 1);
    $countryCode = '+91';


    if (!in_array($user_contact_no, $test_contact_no)) {


      $result = $this->OTPsend($otp, $user_contact_no);
    } else {
      $otp = 1234;
      $result = 'test code';
    }

    $otpArray = array(
      'contact_no' => $user_contact_no,
      'otp_type' => 'login',
      'otp' => $otp,
      'otp_response' => $result
    );


    $otpResponse =  $this->useractivitynew()->insertOtp($otpArray);

    return true;
  }


  private function OTPsend($otp, $user_contact_no)
  {

    $countryCode = '+91';

    $contact_no = $user_contact_no;

    // NEW SMS 91

    $smsArray = array(
      'sender' => 'IMPYED',
      'route' => 4,
      'country' => 91,
      'sms' => array(
        array(
          'message' => "Your Login or Sign Up OTP is $otp team IMPYE",
          'to' => array($contact_no)
        )
      )
      
    );
    
    

    //print_r(json_encode($smsArray,true));
    //exit();

    $authentication_key = '377527Anwopsiz628f0cb5P1';
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://api.msg91.com/api/v2/sendsms?DLT_TE_ID=1307165519304899163",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "POST",
      CURLOPT_POSTFIELDS => json_encode($smsArray, true),
      CURLOPT_SSL_VERIFYHOST => 0,
      CURLOPT_SSL_VERIFYPEER => 0,
      CURLOPT_HTTPHEADER => array(
        "authkey: {$authentication_key}",
        "content-type: application/json"
      ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
      return "cURL Error #:" . $err;
    } else {
      return  $response;
    }


    // NEW SMS 91



  }


  private function userAuth()
  {

    $test = new \App\Models\UserLogin();
    return $test;
  }


}
