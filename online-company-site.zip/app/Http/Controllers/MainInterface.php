<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
interface MainInterface {
    public function homePage(Request $request);
    public function after_register(Request $request);
    public function affiliate(Request $request);
    // will use for sign in 2019 users
    public function sign_in_2020(Request $request);
    public function user_detail(Request $request);
    public function achievement(Request $request);
    public function profile_contact(Request $request);
    public function about(Request $request);
    public function eligibility(Request $request);
    public function awards(Request $request);
    public function importantDates(Request $request);
    public function syllabus(Request $request);
    public function faq(Request $request);
    public function gallery(Request $request);
    public function media(Request $request);
    public function requirements(Request $request);
    public function guidelines(Request $request);
    public function cbtVsOnlineExam(Request $request);
    public function termscondition(Request $request);
    public function privacypolicy(Request $request);
    public function refundpolicy(Request $request);
    public function register(Request $request);
    public function profile_page(Request $request);
    public function exam_select(Request $request);
    public function details_verify(Request $request);
    public function payment_mode(Request $request);
    public function slot_booking(Request $request);
    public function result(Request $request);
    public function profile(Request $request);
    public function prizeClaim(Request $request);
    public function prizeClaimUserCheck(Request $request);    
    public function final_status(Request $request);
    public function university(Request $request);
    public function admitCardReleased(Request $request);
    public function redirect2019(Request $request);
    public function redirect2020(Request $request);
    
}



?>