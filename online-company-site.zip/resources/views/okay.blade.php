
@extends('layouts.default-new')
         
         @section('content')
 
     
         <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
         integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
         
         <link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet" />
     
       
         {{-- stariting wala yellow color start --}}
         {{-- </div>
      --}}
         <div class="bg-img">
           <div class="container-fluid">
           <div class="row">
           <div class="first-section">
             <div class="col-8 containerLeft mt-5">
               
                 <h2> TDS Return Filing</h2>
                 <p>TDS (Tax Deducted at Source) Return Filing refers to the process of filing the details of TDS deducted and deposited by a business or individual to the Income Tax Department.
                 </p>
                 <a href="signup"><button class="button btn-sm bg-white p-1" >
                   Get Started
                 </button></a>
               </div>
               </div>
             </div>
     
             @include('snippet.register-company')
             
           </div>
           </div>
         </div>
         </div> 
         {{-- staring wala yellow color and form end --}}
     
     
         <section id="features" class="features">
          <div class="container aos-init aos-animate" data-aos="fade-up">
    
              <ul class="nav nav-tabs row gy-4 d-flex" role="tablist">
    
                  <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                      <a class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-1" aria-selected="false"
                          role="tab" tabindex="-1">
                          <i class="bi bi-binoculars color-cyan"></i>
                          <h4>Conversion of Proprietorship to Private Limited Company </h4>
                      </a>
                  </li><!-- End Tab 1 Nav -->
    
                  <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                      <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-2" aria-selected="true"
                          role="tab">
                          <i class="bi bi-box-seam color-indigo"></i>
                          <h4>Benefit </h4>
                      </a>
                  </li><!-- End Tab 2 Nav -->
    
                  <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                      <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3" aria-selected="false"
                          role="tab" tabindex="-1">
                          <i class="bi bi-brightness-high color-teal"></i>
                          <h4>Criteria</h4>
                      </a>
                  </li><!-- End Tab 3 Nav -->
    
                  <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                      <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4" aria-selected="false"
                          role="tab" tabindex="-1">
                          <i class="bi bi-command color-red"></i>
                          <h4>Process </h4>
                      </a>
                  </li><!-- End Tab 4 Nav -->
    
                  <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                      <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5" aria-selected="false"
                          role="tab" tabindex="-1">
                          <i class="bi bi-easel color-blue"></i>
                          <h4>
                            Documents required
                          </h4>
                      </a>
                  </li><!-- End Tab 5 Nav -->
    
                  <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                      <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6" aria-selected="false"
                          role="tab" tabindex="-1">
                          <i class="bi bi-map color-orange"></i>
                          <h4>Requirements of start a Company </h4>
                      </a>
                  </li><!-- End Tab 6 Nav -->
    
              </ul>
    
              <div class="tab-content">
    
                  <div class="tab-pane active show" id="tab-1" role="tabpanel">
                      <div class="row gy-4">
                          <div class="col-lg-8 order-2 order-lg-1 aos-init aos-animate" data-aos="fade-up"
                              data-aos-delay="100">
                              <h3>ITR Filing</h3>
                              <p class="fst-italic">
                              The ability to record your income, investments, and taxes owing is provided through an income tax return. It should be filed to the Income Tax Department in accordance with the Government of India's definition. Every person, including self-employed people and those who own businesses, should file income tax returns using one of the many ITR forms the government has provided. Your income is made up of your wage, interest, dividends, capital gains, and so forth.
                              </p>
                              <h3>ITR 1</h3>
                              <p class="fst-italic">
                              If you get income in the form of a salary or pension, you must use this form. Additionally, you must complete this ITR form if you get income from rental property or other sources, other than lottery winnings or income from horse racing.
                              </p> <p class="fst-italic">
                              You cannot register using this form if your annual income is greater than 50 lakh rupees or if you have foreign assets. Additionally, the form cannot be utilised for income from a profession or business, revenue from multiple properties, income from agriculture exceeding $5,000, or income from taxable capital gains.
                              </p>
                              <h3>ITR 2</h3>
                              <p class="fst-italic">
                              This form must be used to file your ITR if your yearly income from housing, employment, pension benefits, or other sources exceeds 50 lakh. Form ITR 2 must be used to file income taxes if your spouse's or children's income is combined with your own. If, however, your income contains professional or company earnings, this form won't be utilised.
                              </p>
                              <h3>ITR 3</h3>
                              <p class="fst-italic">
                              If a person receives money from a business, they are qualified to report that income on form ITR 3. If your income comes from a pension, salary, or other sources, you can also use this form to report that information.
                              </p>
                              <h3>ITR 4</h3>
                              <p class="fst-italic">
                              Form 4 must be used to submit your income tax ITR if you chose to employ the presumptive income system under sections 44AD, 44ADA, and 44AE. However, you must use Form 3 to file your income tax if your total yearly revenue exceeds 2 crores.
                              </p>
                              <h3>ITR 5</h3>
                              <p class="fst-italic">
                              Limited liability partnerships (LLPs), groups of people (BOIs), and associations of people (AOPs) all file their income taxes using the ITR 5 Form.
                              </p>
                              <h3>ITR 6</h3>
                              <p class="fst-italic">
                              Companies that are not excluded under Section 11's rules for revenue from property kept for religious or charitable purposes must electronically file the ITR 6 Form.
                              </p>
                              <h3>ITR 7</h3>
                              <p class="fst-italic">
                              The ITR 7 form must be used to submit returns for any person or business that is required to provide income tax information under Sections 139 (4A), 139 (4B), 139 (4C), and 139 (4D). You can quickly file your ITR form electronically, or "e-filing," which makes the entire process quick, easy, and hassle-free.
                              </p>
                          </div>
                          <div class="col-lg-4 order-1 order-lg-2 text-center">
                              <img src="assets/img/features-2.svg" alt="" class="img-fluid">
                          </div>
                      </div>
                  </div><!-- End Tab Content 1 -->
    
                  <div class="tab-pane" id="tab-2" role="tabpanel">
                      <div class="row gy-4">
                          <div class="col-lg-8 order-2 order-lg-1">
                              <h3>Benefits of ITR Filing</h3>
                              
                              <p class="fst-italic">
                                  
                              Loan approval is simple: ITR filing can make it simple for you to have loans like personal loans, auto loans, home loans, etc. approved. Lenders always request the most recent three years of ITR documentation from borrowers throughout the loan processing phase. As a result, the banks are better able to quickly sanction you because they are aware of your stable income.
                              </p>
                              <p class="fst-italic">
                                  
                              For proving your address and income, one of the finest solutions is: An ITR paperwork will spare you the trouble if you don't have the right address proof when you apply for a loan or any other facility. You may actually provide it as evidence of your income. To prove your income and payment of regular taxes, be sure to keep your ITR receipt.
                              </p>
                              <p class="fst-italic"> Processing visas quickly: The ITR receipts from the previous three years are required by embassies of nations including the United States, United Kingdom, Australia, and Canada when you apply for a visa. In order to process a visa, you must be in compliance with tax law because it verifies your source of income and demonstrates your financial management skills.</p>
                                  <p class="fst-italic"> Claim a tax refund: Getting to claim a tax refund is one of the main advantages of submitting an ITR. If you invested in tax-saving investments and paid more income tax than necessary, you are eligible for a tax refund.</p>
                                   <p class="fst-italic"> Compensate for losses: In accordance with income tax regulations, people are not permitted to carry forward losses they have incurred in the current fiscal year to the following fiscal year. Therefore, it is crucial to submit an ITR by the deadline.</p>
                          </div>
                          <div class="col-lg-4 order-1 order-lg-2 text-center">
                              <img src="assets/img/features-2.svg" alt="" class="img-fluid">
                          </div>
                      </div>
                  </div><!-- End Tab Content 2 -->
    
                  <div class="tab-pane" id="tab-3" role="tabpanel">
                      <div class="row gy-4">
                          <div class="col-lg-8 order-2 order-lg-1">
                              <h3>Criteria</h3>
                              <p class="fst-italic">
                              Even if their income does not go above the tax level, the following people are still allowed to pay their income tax return:
                              </p>
                              <ul>
                                  <li><i class="bi bi-check-circle-fill"></i> Individuals whose annual sales volume is at least Rs. 60 lakh.
                                     </li>
                                  <li><i class="bi bi-check-circle-fill"></i> Those who have a TDS or TCS of more than Rs 25,000.</li>
                                  
                                  <li><i class="bi bi-check-circle-fill"></i> Those with annual professional incomes of over Rs. 10 lakh. </li>
                                  <li><i class="bi bi-check-circle-fill"></i> A person is qualified to pay the ITR if they deposit at least 50 lakh in their savings bank account. </li>
                                  
                              </ul>
                             
                          </div>
                          <div class="col-lg-4 order-1 order-lg-2 text-center">
                              <img src="assets/img/features-3.svg" alt="" class="img-fluid">
                          </div>
                      </div>
                  </div><!-- End Tab Content 3 -->
    
                  <div class="tab-pane" id="tab-4" role="tabpanel">
                      <div class="row gy-4">
                          <div class="col-lg-8 order-2 order-lg-1">
                              <h3>How to start Filing Income Tax Returns Online?</h3>
                              
                              <ul>
                                  <li><i class="bi bi-check-circle-fill"></i> Step 1: Visit the Income Tax e-Filing website, which is located at https://www.incometax.gov.in/iec/foportal/.</li>
                                  
                                  <li><i class="bi bi-check-circle-fill"></i> Step 2: Log into the e-Filing portal with your user ID and password.</li>
                                  <li><i class="bi bi-check-circle-fill"></i> Step 3: Select "e-File" > "Income Tax Returns" Using your dashboard, file your income tax 
                return.</li>
                                  <li><i class="bi bi-check-circle-fill"></i> Step 4: Choose 2021–2022 as the Assessment Year and press Continue.</li>
                                  <li><i class="bi bi-check-circle-fill"></i> Step 5: Click Continue after choosing Online as your filing method.</li>
                              </ul>
                          </div>
                          <div class="col-lg-4 order-1 order-lg-2 text-center">
                              <img src="assets/img/features-4.svg" alt="" class="img-fluid">
                          </div>
                      </div>
                  </div><!-- End Tab Content 4 -->
    
                  <div class="tab-pane" id="tab-5" role="tabpanel">
                      <div class="row gy-4">
                          <div class="col-lg-8 order-2 order-lg-1">
                              <h3>Documents Required for ITR Filing </h3>
                              <p class="fst-italic">
                              Documents for income tax returns (ITRs) vary depending on the tax filer's sources of income. However, regardless of the source of income, some documents are required for every taxpayer. Here is a list of the typical ITR documents that must be submitted in FY 2022–23 (AY 2023–24).
                              </p>
                              
                              <ul>
                                  <li><i class="bi bi-check-circle-fill"></i> PAN Card </li>
                                  <li><i class="bi bi-check-circle-fill"></i> Form 16 </li>
                                  <li><i class="bi bi-check-circle-fill"></i> Aadhar Card </li>
                                  <li><i class="bi bi-check-circle-fill"></i> Form16A/ Form16B/ Form16C </li>
                                  <li><i class="bi bi-check-circle-fill"></i> Bank account details </li>
                                  <li><i class="bi bi-check-circle-fill"></i> Bank statements/ passbook</li>
                                  <li><i class="bi bi-check-circle-fill"></i> Form 26AS</li>
                                  <li><i class="bi bi-check-circle-fill"></i> Capital gains details</li>
                              </ul>
                          </div>
                          <div class="col-lg-4 order-1 order-lg-2 text-center">
                              <img src="assets/img/features-5.svg" alt="" class="img-fluid">
                          </div>
                      </div>
                  </div><!-- End Tab Content 5 -->
    
                  <div class="tab-pane" id="tab-6" role="tabpanel">
                      <div class="row gy-4">
                          <div class="col-lg-8 order-2 order-lg-1">
                              <h3>Documents Required for Start Company</h3>
                              
                              
                              <ul>
                                  <li><i class="bi bi-check-circle-fill"></i> PAN Card</li>
                                  <li><i class="bi bi-check-circle-fill"></i>Aadhar Card</li>
                                  <li><i class="bi bi-check-circle-fill"></i> Bank account details</li>
                                  <li><i class="bi bi-check-circle-fill"></i> Bank statements/ passbook</li>
                              </ul>
                          </div>
                          <div class="col-lg-4 order-1 order-lg-2 text-center">
                              <img src="assets/img/features-6.svg" alt="" class="img-fluid">
                          </div>
                      </div>
                  </div><!-- End Tab Content 6 -->
    
              </div>
    
          </div>
      </section>
    
      <section id="faq" class="faq">
        <div class="container-fluid aos-init aos-animate" data-aos="fade-up">
      
          <div class="row gy-4">
      
            <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">
      
              <div class="content px-xl-5">
                <h3>Frequently Asked <strong>Questions</strong></h3>
                
              </div>
      
              <div class="accordion accordion-flush px-xl-5" id="faqlist">
      
                <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                      <i class="bi bi-question-circle question-icon"></i>
                      Does this process require my physical presence?
                    </button>
                  </h3>
                  <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                    <div class="accordion-body">
                    No, the procedure of forming a company in India is entirely online. You do not need to be physically there at all because you can complete all documents electronically. All the necessary forms and documentation must be digitised and sent to us.
                    </div>
                  </div>
                </div><!-- # Faq item-->
      
                <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="300">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                      <i class="bi bi-question-circle question-icon"></i>
                      Is an audit of a company's books required?
                    </button>
                  </h3>
                  <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                    <div class="accordion-body">
                    Yes, regardless of its revenue, a private limited firm is required to employ an auditor. In fact, within 30 days of formation, an auditor must be engaged. Given that penalties for non-compliance can reach millions of rupees and possibly result in the blacklisting of directors, compliance is crucial for a private limited business.
                    </div>
                  </div>
                </div><!-- # Faq item-->
      
                <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                      <i class="bi bi-question-circle question-icon"></i>
                      Who issues the corporation a certificate of registration?
                    </button>
                  </h3>
                  <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                    <div class="accordion-body">
                    The Ministry of Corporate Affairs makes available the company's registration certificate online.
                    </div>
                  </div>
                </div><!-- # Faq item-->
      
              </div>
      
            </div>
      
            <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img" style="background-image: url(&quot;assets/img/faq.jpg&quot;);">&nbsp;</div>
          </div>
      
        </div>
      </section>
     
        {{-- @include('home-sections.recent-blog-posts'); --}}
     
     
     
     
       {{-- cdn file bootstrap --}}
      
       <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
       integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
     </script>

 @endsection
 {{-- @stop --}}
 
 