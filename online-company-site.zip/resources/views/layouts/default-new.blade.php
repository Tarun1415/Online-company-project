<!DOCTYPE html>
<html lang="en">
<head>
    <title>@yield('title','Online Company Join Explore World')</title>
    <meta name="description" content="@yield('seo_description')">
    <meta name="keywords" content="@yield('seo_keywords')">
    <meta property="og:title" content="@yield('title')">
    <meta property="og:description" content="@yield('seo_description')">
    <meta property="og:image" content="@yield('seo_img')">
    <meta property="og:type" content="website">
    <meta property="og:url" content="{{ url()->current() }}">
</head>





{{-- @include('includes.user-head-new')
  
<body>
@include('includes.user-header-new')
    @yield('content')
@include('includes.footer-new') --}}





@include('includes.head-new')

<body>
    @include('includes.header-new')
    @yield('content')
    @include('includes.footer-new')
</body>
</html>











{{-- 
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>@yield('title')</title>
    <meta name="description" content="@yield('seo_description')">
    <meta name="keywords" content="@yield('seo_keywords')">
    
  </head>


  @include('includes.head-new')
  
<body>
@include('includes.header-new')
    @yield('content')

     
@include('includes.footer-new')

 
</body>
</html> --}}