<!DOCTYPE html>
<html lang="en">
  







  @include('includes.user-head-new')
  
<body>
@include('includes.user-header-new')
    @yield('content')
@include('includes.footer-new')

 
</body>
</html>