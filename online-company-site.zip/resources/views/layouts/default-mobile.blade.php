<!DOCTYPE html>
<html lang="en">

<head>
  @include('includes.head-new')
</head>
@include('includes.header-new')
<body>

    @yield('content')

     
@include('includes.footer-new')

 
</body>
</html>