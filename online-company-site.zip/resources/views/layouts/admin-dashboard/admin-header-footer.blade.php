<!DOCTYPE html>
<html lang="en">
  

  @include('includes.admin-head-new')
  
<body>
@include('includes.admin-header-new')
    @yield('content')

     


 
</body>
</html>