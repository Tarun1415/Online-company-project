<!DOCTYPE html>
<html lang="en">
  

  @include('includes.admin-head-new')
  
<body>
@include('includes.admin-login-header')
    @yield('content')

     
@include('includes.footer-new')

 
</body>
</html>