

@extends('admin.layouts.app')

@section('content')

{{-- <link rel="stylesheet" href="/assets/css/custom.css"> --}}
{{-- <link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">
</head>
<body> --}}
    <!-- Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="{{ asset('assets/img/logo/logo-dog-NGO.png') }}" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Preloader End -->
     {{-- @include('admin.inner-header') --}}
     <main>
  <div class="wrapper d-flex align-items-stretch section-bg">
{{-- @include('include.admin-sidebar') --}}


<div id="content" class="mx-1 mt-3">
 
<div class="col-12 d-flex justify-content-center px-0">
<div class="section-title col-auto">
<h1>Update Videos Content</h1></div>
</div>

<div class="row mt-4">
  <div class="col-4">
  {{-- <a class="btn btn-primary col-8" href="/admin/videos/update-post-data/{{$jobBasicData[0]['video_id']}}">Videos Basic Details</a> --}}
  
  {{-- <a class="btn btn-outline-primary col-2" href="/admin/blogs/update-post-other-data/{{$jobBasicData[0]['video_id']}}">Post Other Details</a> --}}
  
 
 
</div>
 
  <div class="col-12">
  <div class="card-body m-2" style="background-color: white;" >



  <form method="POST" action="/admin/videos/post-update-data" enctype= 'multipart/form-data'>
  {{csrf_field()}}

      <div class="form-group row">
          
          <input id="video_id" name="video_id" class="form-control d-none" type="text" value="{{$jobBasicData[0]['video_id']}}" required>

          <label class="col-4">Video Title</label>
        <div class="col-6">
          <input id="post_display_name" name="video_title" class="form-control"  type="text" placeholder="Enter Video Title/Heading" value="{{$jobBasicData[0]['video_title']}}" required>
        </div>

        <label class="col-4 mt-2">Video Url</label>
        <div class="col-6 mt-2">
          <input id="post_url" name="video_url" class="form-control" type="text" value="{{$jobBasicData[0]['video_url']}}">
        </div>

      </div>
      
    </div>

        <div class="col-12">
            <button id="action_button" class="btn btn-primary mt-4 ofset-6">Submit</button>
          </div>
      </div>
  </form>
  </div>
</div>
</div>
          </div>
        </main>
<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">

<script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>
<link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>



 <!-- For Slud Generation Start-->
 <script>
  function slugAutoGenerate() {
    var x = document.getElementById("post_display_name");
    x.value = x.value;
    slug = slugify(x.value);
    document.getElementById('post_url').value = slug;
  }

  function slugify(string) {
    const a = 'àáâäæãåāăąçćčđďèéêëēėęěğǵḧîïíīįìłḿñńǹňôöòóœøōõőṕŕřßśšşșťțûüùúūǘůűųẃẍÿýžźż·/_,:;'
    const b = 'aaaaaaaaaacccddeeeeeeeegghiiiiiilmnnnnoooooooooprrsssssttuuuuuuuuuwxyyzzz------'
    const p = new RegExp(a.split('').join('|'), 'g')

    return string.toString().toLowerCase()
      .replace(/\s+/g, '-') // Replace spaces with -
      .replace(p, c => b.charAt(a.indexOf(c))) // Replace special characters
      .replace(/&/g, '-and-') // Replace & with 'and'
      .replace(/[^\w\-]+/g, '') // Remove all non-word characters
      .replace(/\-\-+/g, '-') // Replace multiple - with single -
      .replace(/^-+/, '') // Trim - from start of text
      .replace(/-+$/, '') // Trim - from end of text
  }
</script>
<!-- For Slug Generation End -->

<script type="text/javascript">
  $(document).ready(function() {
      var editor = new FroalaEditor('#example')

      $('#datatable').dataTable();

  });
</script>

<script>
  function reupload()
{

$('#featured_img_btn').removeClass('d-none');

$('.featuredImgView').addClass('d-none');
$('#reuploadBtn').addClass('d-none');

}
</script>


<script>
  // Set a timeout to hide the preloader after 3 seconds (3000 milliseconds)
  setTimeout(function () {
      // Hide the preloader
      document.getElementById('preloader-active').style.display = 'none';
  }, 3000);
</script>

@endsection