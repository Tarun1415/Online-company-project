
@extends('admin.layouts.app')

@section('content')


{{-- <link rel="stylesheet" href="/assets/css/custom.css"> --}}
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

    <!-- Preloader Start -->
    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="{{ asset('assets/img/logo/logo-dog-NGO.png') }}" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Preloader End -->
    {{-- @include('admin.inner-header') --}}
    <main>
  <div class="wrapper d-flex align-items-stretch section-bg">
{{-- @include('include.admin-sidebar') --}}
  

<div id="content" class="mx-1 mt-3">
  
<div class="col-12 d-flex justify-content-center px-0">
<div class="section-title col-auto">
<h1>Add Videos Details</h1></div>

</div>


<div class="row mt-4">
  <div class="col-12">
  <div class="card-body m-2" style="background-color: white;" >
  <form method="POST" action="/admin/videos/add-new-video-insert" enctype= 'multipart/form-data'>
  {{csrf_field()}}

      <div class="form-group row">
          
        <div class="col-6">
          <input id="video_title" name="video_title" class="form-control" onkeyup="slugAutoGenerate()" type="text" placeholder="Enter Video Title" required>
        </div>

        <div class="col-6">
          <input id="video_url" name="video_url" class="form-control" type="text" placeholder="Video_url">
        </div>

        <div class="col-12 mt-2">
          <textarea id="video_info" name="video_info" class="form-control" type="text" placeholder="Video description"></textarea>
        </div>
    
        <div class="col-2 mt-3">
            <button id="action_button" class="btn btn-primary">Submit</button>
          </div>

      </div>

  </form>
  </div>
  </div>
</div>


</div>
</div>
</div>
</main>       
<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">

<script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>




<link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">

<script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>



<!-- Include the plugin's CSS and JS: -->

<script type="text/javascript">
    $(document).ready(function() {
      
        $('#datatable').dataTable();



    });
</script>

<script>
    function statusChange(node, post_id) {
      var changeStatus = $(node).val();
        
      console.log(changeStatus + ' ' + post_id);
      ajaxurl = '/partner/blogs/post-status-update/' + post_id + '/' + changeStatus,
        console.log(ajaxurl);
        $.ajax({
              type: 'POST',
              cache: false,
              url: ajaxurl,
              headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},

              success: function() {
                swal("Sucessfully Status Changed to " + changeStatus);                
              }
            });
    }
  </script>

{{-- @include('include.footer-new') --}}
<script>
  // Set a timeout to hide the preloader after 3 seconds (3000 milliseconds)
  setTimeout(function () {
      // Hide the preloader
      document.getElementById('preloader-active').style.display = 'none';
  }, 3000);
</script>
@endsection

@section('customJs')

@endsection






