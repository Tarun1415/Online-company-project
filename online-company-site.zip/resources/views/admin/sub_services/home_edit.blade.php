@extends('admin.layouts.app')
@section('content')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet" href="/assets/css/custom.css">
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

<div class="wrapper d-flex align-items-stretch section-bg">

  

<div id="content" class="mx-1 mt-3">

{{-- <div class="col-12 d-flex justify-content-center px-0">
<div class="section-title col-auto">
<h1>Add Categories</h1></div>
</div> --}}
<section class="content-header">					
    <div class="container-fluid my-2">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 style="color: blue">Update Product Details</h1>
            </div>
            <div class="col-sm-6 text-right">
                
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</section>

<section class="content" style="background-color: azure">
    <!-- Default box -->
    <div class="container-fluid">
        <form method="post" id="register-form" enctype="multipart/form-data" onsubmit="saveRegister(event)">
            @csrf
            <div class="card">
                <div class="card-body">								
                    <div class="row">

                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="name">subservice name</label>
                                <select name="category" id="category" class="form-control">
                                    <option value="">Select SubService</option>
                                        @foreach ($services as $service)
                                        <option value="{{ $service->id }}" {{ $categories->subpart_id == $service->id ? 'selected' : '' }}>
                                            {{ $service->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="name">Title Name</label>
                                <input type="text" name="name" id="title" class="form-control" placeholder="name"  value="{{$categories->name}}">	
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="description">Post Description</label>
                            <textarea name="description" id="description" class="form-control" rows="4" placeholder="Post Description">{{$categories->description}}</textarea>
                        </div> 
                    </div> 
                                

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title1">Title1</label>
                                <input type="text" name="title1" id="title1" class="form-control" placeholder="title1" value="{{$categories->title1}}">
                            </div>

                            
                                <div class="form-group mb-3">
                                    <label for="exampleInputEmail1">Image1</label>
                                    <input type="file" class="form-control" name="input_image1" id="inputImage" aria-describedby="emailHelp">
                                    @if(!empty($categories->image1))
                                    <div>
                                    
                                        <img src="{{asset('uploads/'.$categories->image1)}}" class="img-thumbnail" width="50" >
                                    </div>
                                    @endif
                                </div>
                            
                            <label for="text1">Text1</label>
                            <textarea name="text1" id="text1" class="form-control" rows="4" placeholder="Post Description" >{{$categories->text1}}</textarea>
                        </div>
                        
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title2">Title2</label>
                                <input type="text" name="title2" id="title2" class="form-control" placeholder="title2" value="{{$categories->title2}}">
                            </div>

                            <div class="form-group mb-3">
                                <label for="exampleInputEmail1">Image2</label>
                                <input type="file" class="form-control" name="input_image2" id="inputImage" aria-describedby="emailHelp">
                                @if(!empty($categories->image2))
                                <div>
                                
                                    <img src="{{asset('uploads/'.$categories->image2)}}" class="img-thumbnail" width="50" >
                                </div>
                                @endif
                            </div>
                            <label for="text2">Text2</label>
                            <textarea name="text2" id="text2" class="form-control" rows="4" placeholder="Post Description">{{$categories->text2}}</textarea>

                        </div> 

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title3">Title3</label>
                                <input type="text" name="title3" id="title3" class="form-control" placeholder="title3" value="{{$categories->title3}}">
                            </div>

                            <div class="form-group mb-3">
                                <label for="exampleInputEmail1">Image3</label>
                                <input type="file" class="form-control" name="input_image3" id="inputImage" aria-describedby="emailHelp">
                                @if(!empty($categories->image3))
                                <div>
                                
                                    <img src="{{asset('uploads/'.$categories->image3)}}" class="img-thumbnail" width="50" >
                                </div>
                                @endif
                            </div>
                            <label for="text3">Text3</label>
                            <textarea name="text3" id="text3" class="form-control" rows="4" placeholder="Post Description" >{{$categories->text3}}</textarea>
                        </div> 

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title4">Title4</label>
                                <input type="text" name="title4" id="title4" class="form-control" placeholder="title4" value="{{$categories->title4}}">
                            </div>
                            <div class="form-group mb-3">
                                <label for="exampleInputEmail1">Image4</label>
                                <input type="file" class="form-control" name="input_image4" id="inputImage" aria-describedby="emailHelp">
                                @if(!empty($categories->image4))
                                <div>
                                
                                    <img src="{{asset('uploads/'.$categories->image4)}}" class="img-thumbnail" width="50" >
                                </div>
                                @endif
                            </div>
                            <label for="text1">Text4</label>
                            <textarea name="text4" id="text4" class="form-control" rows="4" placeholder="Post Description">{{$categories->text4}}</textarea>
                        </div> 

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title5">Title5</label>
                                <input type="text" name="title5" id="title5" class="form-control" placeholder="title5" value="{{$categories->title5}}">
                            </div>
                            <div class="form-group mb-3">
                                <label for="exampleInputEmail1">Image5</label>
                                <input type="file" class="form-control" name="input_image5" id="inputImage" aria-describedby="emailHelp">
                                @if(!empty($categories->image5))
                                <div>
                                
                                    <img src="{{asset('uploads/'.$categories->image5)}}" class="img-thumbnail" width="50" >
                                </div>
                                @endif
                            </div>
                            <label for="text1">Text5</label>
                            <textarea name="text5" id="text5" class="form-control" rows="4" placeholder="Post Description" >{{$categories->text5}}</textarea>
                        </div> 

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title6">Title6</label>
                                <input type="text" name="title6" id="title6" class="form-control" placeholder="title6" value="{{$categories->title6}}">
                            </div>
                            <div class="form-group mb-3">
                                <label for="exampleInputEmail1">Image6</label>
                                <input type="file" class="form-control" name="input_image6" id="inputImage" aria-describedby="emailHelp">
                                @if(!empty($categories->image6))
                                <div>
                                
                                    <img src="{{asset('uploads/'.$categories->image6)}}" class="img-thumbnail" width="50" >
                                </div>
                                @endif
                            </div>
                            <label for="text6">Text6</label>
                            <textarea name="text6" id="text6" class="form-control" rows="4" placeholder="Post Description" >{{$categories->text6}}</textarea>
                        </div> 

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="seo_title">SEO Tittle</label>
                                <input type="text" name="seo_title" id="seo_title" class="form-control" placeholder="seo_title" value="{{$categories->seo_title}}">
                            </div>
                            <label for="seo_description">SEO Description</label>
                            <textarea name="seo_description" id="seo_description" class="form-control" rows="4" placeholder="SEO Description">{{$categories->seo_description}}</textarea>
                        </div> 




                        <div class="form-group row" id="seo-keywords-container">
                            <label for="seo_keywords" class="col-12">SEO Keywords</label>
                            @php
                                $seo_keywords = !empty($categories->seo_keywords) ? json_decode($categories->seo_keywords, true) : [];
                            @endphp
                            @if (!empty($seo_keywords))
                                @foreach ($seo_keywords as $keyword)
                                    <div class="col-md-6 mb-3">
                                        <div class="input-group">
                                            <input type="text" name="seo_keywords[]" class="form-control" value="{{ $keyword }}">
                                            <div class="input-group-append">
                                                <button type="button" class="btn btn-danger remove-keyword">-</button>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            @endif
                            <div class="col-md-6 mb-3">
                                <input type="text" name="seo_keywords[]" class="form-control" placeholder="Enter SEO Keyword">
                            </div>
                            <div class="col-md-2 mb-3">
                                <button type="button" class="btn btn-success add-keyword">+</button>
                            </div>
                        </div>
                        
                      

                        

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="status">status</label>
                                <select name="status" id="status" class="form-control">
                                    <option {{($categories->status==1) ? 'selected':''}} value=1>Active</option>
                                    <option {{($categories->status==0) ? 'selected':''}} value=0>InActive</option>
                                </select>
                            </div>
                        </div>	

                    </div>
                </div>							
            </div>
            <div class="pb-5 pt-3">                
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="{{route('admin.homeview')}}" class="btn btn-outline-dark ml-3">Cancel</a>
            </div>
        </form>
    </div>
</section>
</div>
</div>
        
<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">

<script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>




<link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">

<script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.js"></script>






<script>
    document.addEventListener("DOMContentLoaded", function() {
        const keywordsContainer = document.getElementById("seo-keywords-container");
        const addButton = document.querySelector(".add-keyword");

        addButton.addEventListener("click", function() {
            const newKeywordField = document.createElement("div");
            newKeywordField.classList.add("col-md-6", "mb-3");
            newKeywordField.innerHTML = `
                <div class="input-group">
                    <input type="text" name="seo_keywords[]" class="form-control" placeholder="Enter SEO Keyword">
                    <div class="input-group-append">
                        <button type="button" class="btn btn-danger remove-keyword">-</button>
                    </div>
                </div>
            `;
            keywordsContainer.insertBefore(newKeywordField, addButton.parentNode);

            const removeButton = newKeywordField.querySelector(".remove-keyword");
            removeButton.addEventListener("click", function() {
                newKeywordField.remove();
            });
        });

        document.querySelectorAll(".remove-keyword").forEach(button => {
            button.addEventListener("click", function() {
                button.closest(".col-md-6").remove();
            });
        });
    });
</script>








<script>
   

      $(document).ready(function () {
$('#text1').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})

      $(document).ready(function () {
$('#text2').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text3').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text4').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text5').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text6').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})

      function saveRegister(e) {
    e.preventDefault();
    var formData = new FormData($('#register-form')[0]);
    formData.append('_method', 'POST'); // Assuming you're using POST for updating
    formData.append('_token', $('meta[name="csrf-token"]').attr('content')); // Add CSRF token

    Swal.fire({
        title: "Do you want to save the changes?",
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: "Update",
        denyButtonText: `Don't Update`
    }).then((result) => {
        if (result.isConfirmed) {
            // If the user confirms the update, proceed with the AJAX request
            $.ajax({
                url: "{{ route('admin.product_update',$categories->id) }}",
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    console.log(response);
                    // Show success message
                    Swal.fire("Update!", "", "success");
                    // Redirect to the home page after successful update
                    window.location.href = "{{ route('admin.homeview') }}";
                },
                error: function(xhr, status, error) {
                    // Show error message if the AJAX request fails
                    Swal.fire("Error!", "An error occurred while updating the question post.", "error");
                }
            });
        } else if (result.isDenied) {
            
        }
    });
}





</script>



@endsection

@section('customJs')

@endsection







