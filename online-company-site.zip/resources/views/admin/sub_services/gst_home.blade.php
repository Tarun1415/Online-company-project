@extends('layouts.admin-dashboard.admin-header-footer')

@section('content')

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<link rel="stylesheet" href="/assets/css/custom.css">
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

<div class="wrapper d-flex align-items-stretch section-bg">
@include('includes.admin-sidebar')
  

<div id="content" class="mx-1 mt-3">


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <section class="content-header">					
        <div class="container-fluid my-2">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 style="color:blue">GST Registration</h1>
                </div>
                <div class="col-sm-6 text-right">
                    <a href="{{route('admin.showsubservice')}}"class="btn btn-dark">back</a>
                    <a href="{{route('admin.gstregistrations')}}"class="btn btn-dark">GST Registration</a>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- Main content -->
    <section class="content">
        <!-- Default box -->
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <div class="card-tools">
                        {{-- <div class="input-group input-group" style="width: 250px;">
                            <input type="text" name="table_search" class="form-control float-right" placeholder="Search">
        
                            <div class="input-group-append">
                              <button type="submit" class="btn btn-default">
                                <i class="fas fa-search"></i>
                              </button>
                            </div>
                          </div> --}}
                    </div>
                </div>
                <div class="card-body table-responsive p-0">								
                    <table class="table table-hover text-nowrap">
                        <thead style="background-color:azure">
                            <tr >
                                <th width="60"><h1>NO</h1></th>
                                <th width="80"></th>
                                <th><h1>Name</h1></th>
                                <th><h1>Title1</h1></th>
                                <th><h1>Title2</h1></th>
                                <th><h1>Title3</h1></th>
                                <th><h1>Title4</h1></th>
                                <th><h1>Title5</h1></th>
                                <th><h1>Title6</h1></th>
                                <th width="100"><h1>Status</h1></th>
                                <th width="100"><h1>Action<h1></th>
                            </tr>
                        </thead>
                        <tbody>
                                                       
                            @if($categories->isNotEmpty())
    
                            @foreach ($categories as $index => $category)    
                            <tr>
                                <td>{{ $index + 1 }}</td>
                                
                                <td>    
                                    <img src="{{asset('uploads/'.$category->image)}}" class="img-thumbnail" width="50" >
                                    
                                </td>
                                
                                <td><h1>{{ $category->name}}</h1></td>
                                <td><h1>{{ $category->title1}}</h1></td>   
                                <td><h1>{{ $category->title2}}</h1></td>   
                                <td><h1>{{ $category->title3}}</h1></td>   
                                <td><h1>{{ $category->title4}}</h1></td>   
                                <td><h1>{{ $category->title5}}</h1></td>   
                                <td><h1>{{ $category->title6}}</h1></td>   
                                <td>
                                    @if($category->status == 1)
                                    <span class="badge badge-success"><h1>Active</h1></span>
                                    @else
                                    <span class="badge badge-warning"><h1>Inactive</h1></span>
                                    @endif
                                </td>                             
                          {{-- <td>
                                @if($category->status == 1)
                                <svg class="text-success-500 h-6 w-6 text-success" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
    
                                @else
                                <svg class="text-danger h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                                @endif
                            </td>     --}}
                                <td>
                                    {{-- <button class="filament-link-button"> --}}
                                        <button class="badge badge-info">
                                   <a href="{{route('admin.gstregistrations_edit',$category->id)}}">
                                       
                                            Update <!-- Replace "Update" with your desired button text -->
                                            <svg class="filament-link-icon w-4 h-4 mr-1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                                                <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z"></path>
                                            </svg>
                                      
                                    </a>
                                </button>                                                    
                                <a href="{{ route('admin.gstregistrations_delete', $category->id) }}" class="btn btn-primary delete-btn">Delete</a>
                                    <script>
                                        $(document).ready(function() {
                                            // Add click event listener to delete buttons with class 'delete-btn'
                                            $('.delete-btn').on('click', function(e) {
                                                e.preventDefault(); //Prevent default link behavior
    
                                                //Store the href attribute value (delete route) in a variable
                                                var deleteRoute = $(this).attr('href');
    
                                                // Show SweetAlert confirmation dialog
                                                Swal.fire({
                                                    title: "Are you sure?",
                                                    text: "",
                                                    icon: "warning",
                                                    showCancelButton: true,
                                                    confirmButtonColor: "#3085d6",
                                                    cancelButtonColor: "#d33",
                                                    confirmButtonText: "Yes, delete it!"
                                                }).then((result) => {
                                                    // If user confirms deletion
                                                    if (result.isConfirmed) {
                                                        // Perform AJAX request to delete the item
                                                        $.ajax({
                                                            url: deleteRoute,
                                                            method: "POST",
                                                            data: {
                                                                _method: 'DELETE', // Use POST method with _method=DELETE for Laravel
                                                                _token: '{{ csrf_token() }}' // Add CSRF token for security
                                                            },
                                                            success: function(response) {
                                                                // Show success message
                                                                Swal.fire({
                                                                    title: "Deleted!",
                                                                    text: "Your file has been deleted.",
                                                                    icon: "success"
                                                                }).then(() => {
                                                                    // Reload the page after successful deletion
                                                                    location.reload();
                                                                });
                                                            },
                                                            error: function(xhr, status, error) {
                                                                // Show error message
                                                                Swal.fire({
                                                                    title: "Error!",
                                                                    text: "An error occurred while deleting the file.",
                                                                    icon: "error"
                                                                });
                                                            }
                                                        });
                                                    }
                                                });
                                            });
                                        });
                                    </script>                                   
                                </td>
                            </tr>    
                            @endforeach   
                            @else
                            <tr>
                                <td colspan="5">records not found</td>
                            </tr>
                            @endif                            
                        </tbody>
                    </table>										
                </div>
                <div class="card-footer clearfix">
                    {{-- <ul class="pagination pagination m-0 float-right">
                      <li class="page-item"><a class="page-link" href="#">«</a></li>
                      <li class="page-item"><a class="page-link" href="#">1</a></li>
                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                      <li class="page-item"><a class="page-link" href="#">»</a></li>
                    </ul> --}}
                </div>
            </div>
        </div>
        <!-- /.card -->
    </section>
</div>
</div>
<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
<script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>
<link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

@endsection