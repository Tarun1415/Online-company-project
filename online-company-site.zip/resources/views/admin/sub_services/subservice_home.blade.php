@extends('admin.layouts.app')
@section('content')

    <link rel="stylesheet" href="/assets/css/custom.css">
    <link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- Bootstrap JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.dropdown-toggle').dropdown();
        });
    </script>

    <link rel="stylesheet" href="/assets/css/custom.css">
    <link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

    <div class="wrapper d-flex align-items-stretch section-bg">
      


        <div id="content" class="mx-1 mt-3">


            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
            <div class="container-fluid">
                <div class="card">
                    <section class="content-header">
                        <div class="container-fluid my-2">
                            {{-- <div class="row mb-2"> --}}
                                <div class=""> 
                                <div class="col-sm- 12">
                                  


                                    {{-- yaha se start --}}

                                    <head>
                                        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css"
                                            rel="stylesheet">
                                    </head>


                                    <section class="content" style="background-color: white">
                                        <div class="container-fluid">
                                            {{-- <button type="button" class="btn btn-dark" id="create-service-button">Add SubService</button> --}}
                                            <div class="container-fluid mt-4" id="create-service" style="display:none">
                                                <h4>ADD SUB SERVICE</h4>
                                                <form method="post" id="register-form" enctype="multipart/form-data"
                                                    onsubmit="saveRegister(event)">
                                                    @csrf
                                                    <div class="card">
                                                        <div class="card-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="mb-3">
                                                                        <label for="category">Services</label>
                                                                        <select name="category" id="category"
                                                                            class="form-control">
                                                                            <option value="">Select Service</option>
                                                                            @if ($categorie->isNotEmpty())
                                                                                @foreach ($categorie as $category)
                                                                                    <option value="{{ $category->id }}">
                                                                                        {{ $category->name }}</option>
                                                                                @endforeach
                                                                            @endif
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="name">SubserviceName</label>
                                                                        <input type="text" name="name" id="name"
                                                                            class="form-control"
                                                                            placeholder="Sub Service Name" required
                                                                            oninput="generateSlug()">
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="slug">Post Url</label>
                                                                        <input type="text" readonly name="slug"
                                                                            id="slug" class="form-control"
                                                                            placeholder="Slug">
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="name">Title Name</label>
                                                                        <input type="text" name="title" id="title" class="form-control" placeholder="name">	
                                                                    </div>
                                                                </div>
                                        
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="description">Post Description</label>
                                                                        <textarea name="description" id="description" class="form-control" rows="4" placeholder="Post Description"></textarea>
                                                                    </div>
                                                                </div> 
                                        
                                        
                                        
                                        
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="title1">Title1</label>
                                                                        <input type="text" name="title1" id="title1" class="form-control" placeholder="title1">
                                                                    </div>
                                        
                                                                  
                                                                        <div class="form-group mb-3">
                                                                            <label for="exampleInputEmail1">Image1</label>
                                                                            <input type="file" class="form-control" name="input_image1" id="inputImage" aria-describedby="emailHelp">
                                                                        </div>
                                                                
                                        
                                                                    <label for="text1">Text1</label>
                                                                    <textarea name="text1" id="text1" class="form-control" rows="4" placeholder="Post Description"></textarea>
                                                                </div>
                                                                
                                                                
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="title2">Title2</label>
                                                                        <input type="text" name="title2" id="title2" class="form-control" placeholder="title2">
                                                                    </div>
                                        
                                                                    <div class="form-group mb-3">
                                                                        <label for="exampleInputEmail1">Image2</label>
                                                                        <input type="file" class="form-control" name="input_image2" id="inputImage" aria-describedby="emailHelp">
                                                                    </div>
                                        
                                                                    <label for="text2">Text2</label>
                                                                    <textarea name="text2" id="text2" class="form-control" rows="4" placeholder="Post Description"></textarea>
                                        
                                                                </div> 
                                        
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="title3">Title3</label>
                                                                        <input type="text" name="title3" id="title3" class="form-control" placeholder="title3">
                                                                    </div>
                                        
                                                                    <div class="form-group mb-3">
                                                                        <label for="exampleInputEmail1">Image3</label>
                                                                        <input type="file" class="form-control" name="input_image3" id="inputImage" aria-describedby="emailHelp">
                                                                    </div>
                                        
                                                                    <label for="text3">Text3</label>
                                                                    <textarea name="text3" id="text3" class="form-control" rows="4" placeholder="Post Description"></textarea>
                                                                </div> 
                                        
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="title4">Title4</label>
                                                                        <input type="text" name="title4" id="title4" class="form-control" placeholder="title4">
                                                                    </div>
                                                                    <div class="form-group mb-3">
                                                                        <label for="exampleInputEmail1">Image4</label>
                                                                        <input type="file" class="form-control" name="input_image4" id="inputImage" aria-describedby="emailHelp">
                                                                    </div>
                                                                    <label for="text1">Text4</label>
                                                                    <textarea name="text4" id="text4" class="form-control" rows="4" placeholder="Post Description"></textarea>
                                                                </div> 
                                        
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="title5">Title5</label>
                                                                        <input type="text" name="title5" id="title5" class="form-control" placeholder="title5">
                                                                    </div>
                                                                    <div class="form-group mb-3">
                                                                        <label for="exampleInputEmail1">Image5</label>
                                                                        <input type="file" class="form-control" name="input_image5" id="inputImage" aria-describedby="emailHelp">
                                                                    </div>
                                                                    <label for="text1">Text5</label>
                                                                    <textarea name="text5" id="text5" class="form-control" rows="4" placeholder="Post Description"></textarea>
                                                                </div> 
                                        
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="title6">Title6</label>
                                                                        <input type="text" name="title6" id="title6" class="form-control" placeholder="title6">
                                                                    </div>
                                                                    <div class="form-group mb-3">
                                                                        <label for="exampleInputEmail1">Image6</label>
                                                                        <input type="file" class="form-control" name="input_image6" id="inputImage" aria-describedby="emailHelp">
                                                                    </div>
                                                                    <label for="text6">Text6</label>
                                                                    <textarea name="text6" id="text6" class="form-control" rows="4" placeholder="Post Description"></textarea>
                                                                </div>                                                                            
                                                                     
                                                             
                                                            <div>
                                        
                                                            </div>
                                        
                                                            <div class="col-md-6">
                                                                <div class="mb-3">
                                                                    <label for="seo_title">SEO Tittle</label>
                                                                    <input type="text" name="seo_title" id="seo_title" class="form-control" placeholder="seo_title">
                                                                </div>
                                                                <label for="seo_description">SEO Description</label>
                                                                <textarea name="seo_description" id="seo_description" class="form-control" rows="4" placeholder="seo_description"></textarea>
                                        
                                                            </div> 
                                        
                                                            <div class="form-group row" id="seo-keywords-container">
                                                                <label for="exampleInputEmail1">SEO Keywords</label>
                                                                {{-- <label class="col-4">SEO Keywords</label> --}}
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <input type="text" name="seo_keywords[]" class="form-control" placeholder="Enter SEO Keyword">
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-2">
                                                                    <button type="button" class="btn btn-success add-keyword">+</button>
                                                                </div>
                                                            </div>

                                                            <div class="form-group mb-3">
                                                                <label for="exampleInputEmail1">Upload SEO Image</label>
                                                                <input type="file" class="form-control" name="seo_img" id="inputImage" aria-describedby="emailHelp">
                                                            </div>
                                                                <div class="col-md-6">
                                                                    <div class="mb-3">
                                                                        <label for="status">Status</label>
                                                                        <select name="status" id="status"
                                                                            class="form-control">
                                                                            <option value="1">Active</option>
                                                                            <option value="0">Inactive</option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="pb-5 pt-3">
                                                        <button type="submit" class="btn btn-primary">Add Sub
                                                            Service</button>
                                                        <button type="button" id="closeAddServiceForm"
                                                            class="btn btn-outline-dark ml-3">Cancel</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </section>

                                    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">

<script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>




<link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">

<script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.js"></script>






<script>
    document.addEventListener("DOMContentLoaded", function() {
        const keywordsContainer = document.getElementById("seo-keywords-container");
        const addButton = document.querySelector(".add-keyword");

        addButton.addEventListener("click", function() {
            const newKeywordField = document.createElement("div");
            newKeywordField.classList.add("col-md-6", "mb-3");
            newKeywordField.innerHTML = `
                <div class="input-group">
                    <input type="text" name="seo_keywords[]" class="form-control" placeholder="Enter SEO Keyword">
                    <div class="input-group-append">
                        <button type="button" class="btn btn-danger remove-keyword">-</button>
                    </div>
                </div>
            `;
            keywordsContainer.insertBefore(newKeywordField, addButton.parentNode);

            // Add event listener to remove keyword button
            const removeButton = newKeywordField.querySelector(".remove-keyword");
            removeButton.addEventListener("click", function() {
                newKeywordField.remove();
            });
        });
    });
</script>





<script>
   

      $(document).ready(function () {
$('#text1').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})

      $(document).ready(function () {
$('#text2').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text3').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text4').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text5').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text6').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
</script>


                                    <!-- jQuery (necessary for Bootstrap's JavaScript plugins, optional if not using Bootstrap) -->
                                    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
                                    <!-- Bootstrap JS (optional, for better styling) -->
                                    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>

                                    <script>
                                        document.addEventListener('DOMContentLoaded', (event) => {
                                            document.getElementById('create-service-button').addEventListener('click', function() {
                                                document.getElementById('create-service').style.display = 'block';
                                            });

                                            document.getElementById('closeAddServiceForm').addEventListener('click', function() {
                                                document.getElementById('create-service').style.display = 'none';
                                            });
                                        });




                                        ///ye code only check karta hai ki subservice hai ya nhi



                                        function generateSlug() {
                                            var PostTitle = $('#name').val();
                                            var slug = PostTitle.toLowerCase().replace(/\s+/g, '-').replace(/[^\w\-]+/g, '');
                                            $('#slug').val(slug);
                                        }

                                        function saveRegister(e) {
                                            e.preventDefault();
                                            console.log($('#register-form'));
                                            var registerData = $('#register-form')[0];
                                            var formData = new FormData(registerData);

                                            $.ajax({
                                                url: "{{ route('admin.addsubservice') }}",
                                                method: "POST",
                                                data: formData,
                                                contentType: false,
                                                processData: false,
                                                success: function(response) {
                                                    console.log('fffffffffffffffffffff', response);
                                                    if (response.success == false) {
                                                        displayErrors(response.errors);
                                                    } else {
                                                        Swal.fire({
                                                            title: "Add successfully !",
                                                            text: "Service added successfully!",
                                                            icon: "success",
                                                            showConfirmButton: false,
                                                            timer: 1500

                                                        });
                                                        setTimeout(() => {
                                                            window.location.href = "{{ route('admin.showsubservice') }}";
                                                        }, 3000);
                                                    }

                                                }
                                            });
                                        }

                                        function displayErrors(errors) {
                                            // Clear previous errors
                                            $('.error-message').remove();

                                            $.each(errors, function(key, messages) {
                                                var input = $('input[name=' + key + ']');
                                                var errorMessage = $('<span class="error-message text-danger">' + messages[0] + '</span>');
                                                input.after(errorMessage);
                                            });
                                        }


                                    
                                    </script>





                                    {{-- Fillter --}}

                                    <!-- Second Dropdown menu -->


                                    {{-- <div class="dropdown" style="display: inline-block; margin-left: 10px;">
                                        <form action="{{ route('admin.showsubservice') }}" method="GET">
                                            <div class="row mb-2">
                                                <div class="col-md-6">
                                                    <select name="service_name" class="form-control">
                                                        <option value="">All Service</option>
                                                        @foreach ($services as $service)
                                                            <option value="{{ $service->name }}"
                                                                {{ $selectedService == $service->name ? 'selected' : '' }}>
                                                                {{ $service->name }}
                                                            </option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <div class="col-md-6">
                                                    <button type="submit" class="btn btn-primary">Filter</button>
                                                </div>

                                            </div>
                                        </form>

                                    </div> --}}
                                </div>

                                <div class="col-sm-12 text-right">
                                    <button type="button" class="btn btn-dark" id="create-service-button">Add
                                        SubService</button>
                                </div>
                            </div>
                        </div>

                        <div id="content" class="mx-1 mt-3">
                            <div class="col-12 d-flex justify-content-center px-0">
                                <div class="section-title col-auto">
                                    <h1>All Sub Services</h1>
                                </div>
                            </div>
                            <div class="row mx-0">
                                <div class="col-12 d-none1 px-0" id="table-div">
                                    <div class="card p-3">
                                        {{-- <div class="dropdown" style="display: inline-block; margin-left: 10px;">
                                            <form action="{{ route('admin.showsubservice') }}" method="GET">
                                                <div class="row mb-2">
                                                    <div class="col-md-6">
                                                        <select name="service_name" class="form-control">
                                                            <option value="">All Services</option>
                                                            @foreach ($services as $service)
                                                                <option value="{{ $service->name }}"
                                                                    {{ $selectedService == $service->name ? 'selected' : '' }}>
                                                                    {{ $service->name }}
                                                                </option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <button type="submit" class="btn btn-primary">Filter</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div> --}}
                                    <button class="btn btn-success col-2 d-none" id="multipleAroUpdate" onClick="updateMultipleTags()" style="height:40px;">
                                        Update <span class="badge badge-light" id="selectedAros">0</span>
                                    </button>
                                    <table class="table-responsive-sm"
                                    id="table"
                                    data-show-refresh="true"
                                    data-pagination="true"
                                    data-show-export="true"
                                    data-search="true"
                                    data-search-on-enter-key="true"
                                    data-show-search-button="true"
                                    data-url="{{ url('admin/subhomeservice/Ajax') }}"
                                    data-side-pagination="server"
                                    data-locale="en-us"
                                    data-show-columns="true"
                                    data-buttons-class="primary-bg"
                                    data-header-style="headerStyle"
                                    data-toolbar="#toolbar"
                                    data-reorderable-columns="false">
                                    <thead>
                                        <tr class="button-style">
                                            <th data-field="serial" data-formatter="serialNumberFormatter">SN.</th>
                                            <th data-field="serviceName" data-sortable="false">Service Name</th>
                                            <th data-field="name" data-sortable="false">SubService Name</th>
                                            <th data-field="status" data-sortable="false" data-formatter="statusFormatter">Status</th>
                                            <th data-field="action" data-sortable="false">Action</th>
                                        </tr>
                                    </thead>
                                </table>

                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Scripts and styles for table and Summernote -->
                        <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
                        <script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
                        <script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
                        <script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>
                        <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">
                        <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.js"></script>
                        
                        <script>
                        function statusChange(node, aro_id) {
                            var changeStatus = $(node).val();
                            var ajaxurl = '/partner/statusupdate/' + aro_id + '/' + changeStatus;
                        
                            swal({
                                title: "Do you want to change status to " + changeStatus + "?",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#DD6B55",
                                confirmButtonText: "Yes!",
                                cancelButtonText: "No!",
                                closeOnConfirm: false,
                                closeOnCancel: true
                            },
                            function(isConfirm) {
                                if (isConfirm) {
                                    $.ajax({
                                        type: 'POST',
                                        cache: false,
                                        url: ajaxurl,
                                        success: function(response) {
                                            var responseArr = JSON.parse(response);
                                        }
                                    });
                                    $('#table').bootstrapTable('refresh');
                                    swal.close();
                                }
                            });
                        }
                        
                        function availabilityChange(node, aro_id) {
                            var changeStatus = $(node).val();
                            var ajaxurl = '/partner/availabilityupdate/' + aro_id + '/' + changeStatus;
                        
                            swal({
                                title: "Do you want to change Availability to " + changeStatus + "?",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#DD6B55",
                                confirmButtonText: "Yes!",
                                cancelButtonText: "No!",
                                closeOnConfirm: false,
                                closeOnCancel: true
                            },
                            function(isConfirm) {
                                if (isConfirm) {
                                    $.ajax({
                                        type: 'POST',
                                        cache: false,
                                        url: ajaxurl,
                                        success: function(response) {
                                            var responseArr = JSON.parse(response);
                                        }
                                    });
                                    $('#table').bootstrapTable('refresh');
                                    swal.close();
                                }
                            });
                        }
                        
                        $(function() {
                            $('#table').bootstrapTable({
                                exportDataType: 'all',
                                exportTypes: ['csv'],
                                rowStyle: function(row, index) {
                                    return {
                                        classes: 'button-style',
                                    };
                                },
                                queryParams: function(p) {
                                    return {
                                        limit: p.limit,
                                        offset: p.offset,
                                        search: p.search,
                                        order: p.order,
                                        user_verification_status: $('#user_verification_status').val()
                                    };
                                },
                                onLoadSuccess: function(data) {
                                    $('#table-div').removeClass('d-none');
                                }
                            });
                        
                            $('#searchBtn').on('click', function() {
                                $('#table').bootstrapTable('destroy'); //Destroy bootstrap table
                                $('#table').bootstrapTable({
                                    exportDataType: 'all',
                                    exportTypes: ['csv'],
                                    rowStyle: function(row, index) {
                                        return {
                                            classes: 'button-style',
                                        };
                                    },
                                    queryParams: function(p) {
                                        return {
                                            limit: p.limit,
                                            offset: p.offset,
                                            search: p.search,
                                            order: p.order,
                                            user_verification_status: $('#user_verification_status').val()
                                        };
                                    }
                                });
                            });
                        });
                        
                        function addKeywordInput(event) {
                            event.preventDefault(); // Prevent default form submission
                            const container = document.getElementById("seo_keywords_container");
                            const newKeywordInput = `
                                <div class="input-group mb-2">
                                    <input name="bank_seo_keyword[]" class="form-control" type="text" placeholder="Enter SEO Keyword">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-secondary btn-sm remove_keyword_btn" type="button">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </div>
                                </div>
                            `;
                            container.insertAdjacentHTML("beforeend", newKeywordInput);
                        }
                        
                        function removeKeywordInput(event) {
                            const keywordInput = event.target.closest(".input-group");
                            if (keywordInput) {
                                keywordInput.remove();
                            }
                        }
                        
                        document.getElementById("add_keyword_btn").addEventListener("click", addKeywordInput);
                        
                        document.addEventListener("click", function(event) {
                            if (event.target && event.target.classList.contains("remove_keyword_btn")) {
                                removeKeywordInput(event);
                            }
                        });
                        
                        function statusFormatter(value, row, index) {
                            return value == 1 ? 'Active' : 'Inactive';
                        }
                        
                        function serialNumberFormatter(value, row, index) {
                        var options = $('#table').bootstrapTable('getOptions');
                        var pageNumber = options.pageNumber;
                        var pageSize = options.pageSize;
                        return (pageNumber - 1) * pageSize + index + 1;
                         }
                        </script>
                        










































































                        

                        












@endsection

@section('customJs')
@endsection
