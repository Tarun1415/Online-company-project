@extends('admin.layouts.app')
@section('content')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet" href="/assets/css/custom.css">
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

<div class="wrapper d-flex align-items-stretch section-bg">

  

<div id="content" class="mx-1 mt-3">

{{-- <div class="col-12 d-flex justify-content-center px-0">
<div class="section-title col-auto">
<h1>Add Categories</h1></div>
</div> --}}
<section class="content-header">					
    <div class="container-fluid my-2">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 style="color: blue">Add Sub Services</h1>
            </div>
            <div class="col-sm-6 text-right">
                
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</section>

<section class="content" style="background-color: azure">
    <!-- Default box -->
    <div class="container-fluid">
        <form method="post" id="register-form" enctype="multipart/form-data" onsubmit="saveRegister(event)">
            @csrf
            <div class="card">
                <div class="card-body">								
                    <div class="row">

                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="name">Services</label>
                                <select name="category" id="category" class="form-control">
                                    <option value="">Select Service</option>
                                    @if($categories->isNotEmpty())
                                    @foreach ($categories as $category)
                                    <option value="{{$category->id}}">{{$category->name}}</option>  
                                    @endforeach
                                  
                                    @endif
                                   
                                </select>
                                {{-- <input type="text" name="name" id="name" class="form-control" placeholder=" Category Name" required oninput="generateSlug()">	 --}}
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="name">Name</label>
                                <input type="text" name="name" id="name" class="form-control" placeholder=" sub service Name" required oninput="generateSlug()">	
                            </div>
                        </div>


                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="slug">Post Url</label>
                                <input type="text" readonly name="slug" id="slug" class="form-control" placeholder="Slug">		
                                {{-- readonly --}}
                            </div>
                            <p> </p>

                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="name">Title Name</label>
                                <input type="text" name="name" id="title" class="form-control" placeholder="name">	
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="description">Post Description</label>
                                <textarea name="description" id="description" class="form-control" rows="4" placeholder="Post Description"></textarea>
                            </div>
                        </div> 




                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title1">Title1</label>
                                <input type="text" name="title1" id="title1" class="form-control" placeholder="title1">
                            </div>

                          
                                <div class="form-group mb-3">
                                    <label for="exampleInputEmail1">Image1</label>
                                    <input type="file" class="form-control" name="input_image1" id="inputImage" aria-describedby="emailHelp">
                                </div>
                        

                            <label for="text1">Text1</label>
                            <textarea name="text1" id="text1" class="form-control" rows="4" placeholder="Post Description"></textarea>
                        </div>
                        
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title2">Title2</label>
                                <input type="text" name="title2" id="title2" class="form-control" placeholder="title2">
                            </div>

                            <div class="form-group mb-3">
                                <label for="exampleInputEmail1">Image2</label>
                                <input type="file" class="form-control" name="input_image2" id="inputImage" aria-describedby="emailHelp">
                            </div>

                            <label for="text2">Text2</label>
                            <textarea name="text2" id="text2" class="form-control" rows="4" placeholder="Post Description"></textarea>

                        </div> 

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title3">Title3</label>
                                <input type="text" name="title3" id="title3" class="form-control" placeholder="title3">
                            </div>

                            <div class="form-group mb-3">
                                <label for="exampleInputEmail1">Image3</label>
                                <input type="file" class="form-control" name="input_image3" id="inputImage" aria-describedby="emailHelp">
                            </div>

                            <label for="text3">Text3</label>
                            <textarea name="text3" id="text3" class="form-control" rows="4" placeholder="Post Description"></textarea>
                        </div> 

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title4">Title4</label>
                                <input type="text" name="title4" id="title4" class="form-control" placeholder="title4">
                            </div>
                            <div class="form-group mb-3">
                                <label for="exampleInputEmail1">Image4</label>
                                <input type="file" class="form-control" name="input_image4" id="inputImage" aria-describedby="emailHelp">
                            </div>
                            <label for="text1">Text4</label>
                            <textarea name="text4" id="text4" class="form-control" rows="4" placeholder="Post Description"></textarea>
                        </div> 

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title5">Title5</label>
                                <input type="text" name="title5" id="title5" class="form-control" placeholder="title5">
                            </div>
                            <div class="form-group mb-3">
                                <label for="exampleInputEmail1">Image5</label>
                                <input type="file" class="form-control" name="input_image5" id="inputImage" aria-describedby="emailHelp">
                            </div>
                            <label for="text1">Text5</label>
                            <textarea name="text5" id="text5" class="form-control" rows="4" placeholder="Post Description"></textarea>
                        </div> 

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="title6">Title6</label>
                                <input type="text" name="title6" id="title6" class="form-control" placeholder="title6">
                            </div>
                            <div class="form-group mb-3">
                                <label for="exampleInputEmail1">Image6</label>
                                <input type="file" class="form-control" name="input_image6" id="inputImage" aria-describedby="emailHelp">
                            </div>
                            <label for="text6">Text6</label>
                            <textarea name="text6" id="text6" class="form-control" rows="4" placeholder="Post Description"></textarea>
                        </div> 






                     
                    <div>

                    </div>

                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="seo_title">SEO Tittle</label>
                            <input type="text" name="seo_title" id="seo_title" class="form-control" placeholder="seo_title">
                        </div>
                        <label for="seo_description">SEO Description</label>
                        <textarea name="seo_description" id="seo_description" class="form-control" rows="4" placeholder="seo_description"></textarea>

                    </div> 

                    <div class="form-group row" id="seo-keywords-container">
                        <label for="exampleInputEmail1">SEO Keywords</label>
                        {{-- <label class="col-4">SEO Keywords</label> --}}
                        <div class="col-md-6">
                            <div class="mb-3">
                                <input type="text" name="seo_keywords[]" class="form-control" placeholder="Enter SEO Keyword">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-success add-keyword">+</button>
                        </div>
                    </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="status">status</label>
                               <select name="status" id="status" class="form-control">
                               <option value="1">Active</option>
                               <option value="0">Inactive</option>
                            </select>
                            </div>
                        </div>	

                    </div>
                </div>							
            </div>
            <div class="pb-5 pt-3">                
                <button type="submit" class="btn btn-primary">Add Sub Service</button>
                <a href="{{route('admin.showsubservice')}}" class="btn btn-outline-dark ml-3">Cancel</a>
            </div>
        </form>
    </div>
</section>
</div>
</div>

<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">

<script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>




<link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">

<script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.js"></script>






<script>
    document.addEventListener("DOMContentLoaded", function() {
        const keywordsContainer = document.getElementById("seo-keywords-container");
        const addButton = document.querySelector(".add-keyword");

        addButton.addEventListener("click", function() {
            const newKeywordField = document.createElement("div");
            newKeywordField.classList.add("col-md-6", "mb-3");
            newKeywordField.innerHTML = `
                <div class="input-group">
                    <input type="text" name="seo_keywords[]" class="form-control" placeholder="Enter SEO Keyword">
                    <div class="input-group-append">
                        <button type="button" class="btn btn-danger remove-keyword">-</button>
                    </div>
                </div>
            `;
            keywordsContainer.insertBefore(newKeywordField, addButton.parentNode);

            // Add event listener to remove keyword button
            const removeButton = newKeywordField.querySelector(".remove-keyword");
            removeButton.addEventListener("click", function() {
                newKeywordField.remove();
            });
        });
    });
</script>





<script>
    // function generateSlug() {
    //     var PostTitle = $('#name').val();
    //     var slug = PostTitle.toLowerCase().replace(/\s+/g, '-').replace(/[^\w\-]+/g, '');
    //     $('#slug').val(slug);
    // }
//     $(document).ready(function () {
// $('#description').summernote({
//         placeholder: 'Enter Eligibility Criteria Details',
//         tabsize: 2,
//         height: 150,
//         disableDragAndDrop: true

//       });})

      $(document).ready(function () {
$('#text1').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})

      $(document).ready(function () {
$('#text2').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text3').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text4').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text5').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
      
      $(document).ready(function () {
$('#text6').summernote({
        placeholder: 'Enter Eligibility Criteria Details',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true

      });})
</script>




<script>
    function generateSlug() {
        var PostTitle = $('#name').val();
        var slug = PostTitle.toLowerCase().replace(/\s+/g, '-').replace(/[^\w\-]+/g, '');
        $('#slug').val(slug);
    }

    function saveRegister(e) {
        e.preventDefault();
        console.log($('#register-form'));
        var registerData = $('#register-form')[0];
        var formData = new FormData(registerData);

        $.ajax({
            url: "{{route('admin.addsubservice')}}",
            method: "POST",
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                console.log(response);
                Swal.fire({
                    title: "Add successfully !",
                    text: "Teacher added successfully!",
                    icon: "success",
                    showConfirmButton: false,
                    timer: 1500
                    
                });
                window.location.href = "{{ route('admin.showsubservice') }}";
            }
        });
    }
</script>




@endsection

@section('customJs')

@endsection






