{{-- @extends('layouts.dashboard-layout-new', ['title' => "FINCRIF Attendance Log"])
@section('content') --}}

@extends('admin.layouts.app')

@section('content')

<div class="wrapper d-flex align-items-stretch section-bg">
  <?php if(session('partner_id')){ ?>

    @include('snippet.side-bar.left-sidebar-school-admin2')
<?php } 
?>


<div id="content" class="mx-1 mt-3">
    <?php if(session('cw_name')){?>
        <a href="/partner/blogs/dashboard"><i class="fas fa-database"></i>Dashboard</a>
      <?php } ?>
<div class="col-12 d-flex justify-content-center px-0">
<div class="section-title col-auto">
<h1>Update Post Details</h1></div>

</div>

<div class="row mt-4">
  <div class="col-12">
    <a class="btn btn-outline-primary col-2" href="/partner/blogs/update-post-data/{{$post_id}}">Post Basic Details</a>
    <a class="btn btn-outline-primary col-2" href="/partner/blogs/update-vacancy-data/{{$post_id}}">Post Content</a>
    {{-- <a class="btn btn-primary col-2" href="/partner/blogs/update-post-other-data/{{$post_id}}">Post Other Details</a> --}}
    <a class="btn btn-outline-primary col-2" href="/partner/blogs/update-post-date-data/{{$post_id}}">Post Important Dates</a>
    <a class="btn btn-outline-primary col-2" href="/partner/blogs/update-post-document-data/{{$post_id}}">Post Documents Links</a>
 
</div>
 
  <div class="col-12">
  <div class="card-body m-2" style="background-color: white;" >
    <form method="POST" action="/partner/blogs/update-post-other-data/{{$post_id}}">
        {{csrf_field()}}
    
            <div class="form-group row">         
                <div class="container-fluid mt-4">
               <h5>Update Post Other Data</h5>
    
    
          <div class="fr-view">
          <input id="id" name="id" class="d-none form-control" value="<?php if (isset($postOtherData) && !empty($postOtherData)) { ?> {{$postOtherData[0]['id']}} <?php } ?>">
          <div>
                            <select id='myColors' onChange="applicationFeestemplateChange(this);" class="form-control mb-3">
                                <option value="">Select Application Fees Template</option>
                                <option value="1">Category Wise Fees</option>
                       
                            </select>
                        </div>
    <textarea id="application_fees" name="application_fees"><?php if (isset($postOtherData) && !empty($postOtherData)) { ?> {{$postOtherData[0]['application_fees']}} <?php } ?></textarea>
          </div>
    
          <div class="fr-view mt-2">
    <textarea id="selection_process" name="selection_process"><?php if (isset($postOtherData) && !empty($postOtherData)) { ?> {{$postOtherData[0]['selection_process']}} <?php } ?></textarea>
          </div>
    
          <div class="fr-view mt-2">
    <textarea id="qualification_details" name="qualification_details"><?php if (isset($postOtherData) && !empty($postOtherData)) { ?> {{$postOtherData[0]['qualification_details']}} <?php } ?></textarea>
          </div>
    
          <div class="fr-view mt-2">
    <textarea id="how_to_apply" name="how_to_apply"><?php if (isset($postOtherData) && !empty($postOtherData)) { ?> {{$postOtherData[0]['how_to_apply']}} <?php } ?></textarea>
          </div>
    
          <div class="fr-view mt-2">
    <textarea id="other_data" name="other_data"><?php if (isset($postOtherData) && !empty($postOtherData)) { ?> {{$postOtherData[0]['other_data']}} <?php } ?></textarea>
          </div>
          </div>
          </div>
          </div>
              <div class="col-12">
                  <button id="action_button" class="btn btn-primary mt-2 ofset-6">Submit</button>
                </div>
    
            </div>
    
        </form>
  </div>


</div>
</div>

<!-- include summernote css/js -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-bs4.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-bs4.js"></script>




<script type="text/javascript">
    $(document).ready(function() {
        $('#application_fees').summernote({
            placeholder: 'Enter Application Fees Details....',
            tabsize: 2,
            height: 300
        });
    });

    function applicationFeestemplateChange(node) {

var arr1 = new Array();
arr1[1] = '<table class="table table-bordered m-0" style="font-size: 1rem;"><tbody><tr><th>General / EWS / OBC</th><td>Rs --</td></tr><tr><th>SC / ST / PWD / EXM<br></th><td>Rs --</td></tr></tbody></table>';

var templateVal = $(node).val();

codeV = arr1[templateVal];

$('#application_fees').summernote('code', codeV);

}

    $(document).ready(function() {
        $('#selection_process').summernote({
            placeholder: 'Enter selection process Details....',
            tabsize: 2,
            height: 300
        });
    });

    $(document).ready(function() {
        $('#qualification_details').summernote({
            placeholder: 'Enter qualification details Details....',
            tabsize: 2,
            height: 300
        });
    });

    $(document).ready(function() {
        $('#how_to_apply').summernote({
            placeholder: 'Enter How to Apply Details....',
            tabsize: 2,
            height: 300
        });
    });

    $(document).ready(function() {
        $('#other_data').summernote({
            placeholder: 'Enter Post other Details....',
            tabsize: 2,
            height: 300
        });
    });



</script>

@endsection

@section('customJs')

@endsection
