@extends('admin.layouts.app')

@section('content')

{{-- <link rel="stylesheet" href="/assets/css/custom.css"> --}}
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/admin-dashboard.css">
<link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

<!-- Preloader Start -->
<div id="preloader-active">
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="preloader-inner position-relative">
            <div class="preloader-circle"></div>
            <div class="preloader-img pere-text">
                <img src="{{ asset('assets/img/logo/logo-dog-NGO.png') }}" alt="">
            </div>
        </div>
    </div>
</div>
<!-- Preloader End -->

<main>
    <div class="wrapper d-flex align-items-stretch section-bg">           
        <div id="content" class="mx-1 mt-3">
            <div class="col-12 d-flex justify-content-center px-0">
                <div class="section-title col-auto">
                    <h1>Update Post Details</h1>
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-12">
                    {{-- <a class="btn btn-primary col-2" href="/admin/blogs/update-post-data/{{$jobBasicData[0]['post_id']}}">Post Basic Details</a> --}}
                </div>

                <div class="col-12">
                    <div class="card-body m-2" style="background-color: white;">
                        <form method="POST" action="/admin/blogs/post-update-data" enctype='multipart/form-data'>
                            {{ csrf_field() }}

                            <div class="form-group row">
                                <input id="post_id" name="post_id" class="form-control d-none" type="text" value="{{$jobBasicData[0]['post_id']}}" required>

                                <label class="col-4">Post Title</label>
                                <div class="col-6">
                                    <input id="post_display_name" name="post_display_name" class="form-control" onkeyup="slugAutoGenerate()" type="text" placeholder="Enter Post Title/Heading" value="{{$jobBasicData[0]['post_display_name']}}" required>
                                </div>

                                <label class="col-4 mt-2">Post Url</label>
                                <div class="col-6 mt-2">
                                    <input id="post_url" name="post_url" class="form-control" type="text" value="{{$jobBasicData[0]['post_url']}}">
                                </div>

                                <label class="col-4 mt-2">Post Information</label>
                                <div class="col-6 mt-2">
                                    <textarea id="short_info" name="short_info" class="form-control" type="text" placeholder="Enter Post Short Information">{{ $jobBasicData[0]['short_info'] ?? '' }}</textarea>
                                </div>

                                <label class="col-4 mt-2">Featured Image</label>
                                <div class="col-6 mt-2">
                                    <input id="featured_img" type="file" name="featured_img" accept="image/png, image/jpeg, application/pdf" style="display: none;">
                                    <img id="featuredImgView" width="150" class="featuredImgView" src="/upload/blogs/{{$jobBasicData[0]['featured_img']}}" alt="">
                                    <button type="button" class="btn btn-secondary mt-2" onclick="reuploadImage('featured_img')">Reupload</button>
                                </div>

                                <label class="col-4 mt-2">SEO title</label>
                                <div class="col-6 mt-2">
                                    <textarea id="seo_title" name="seo_title" class="form-control" type="text" placeholder="Enter Post Short Information">{{ $jobBasicData[0]['seo_title'] ?? '' }}</textarea>
                                </div>

                                <label class="col-4 mt-2">SEO Description</label>
                                <div class="col-6 mt-2">
                                    <textarea id="seo_description" name="seo_description" class="form-control" type="text" placeholder="Enter Post Short Information">{{ $jobBasicData[0]['seo_description'] ?? '' }}</textarea>
                                </div>

                                <label class="col-4 mt-2">SEO Image</label>
                                <div class="col-6 mt-2">
                                    <input id="seo_image" type="file" name="seo_image" accept="image/png, image/jpeg" style="display: none;">
                                    <img id="seoImgView" width="150" class="seoImgView" src="/upload/blogs/seo/{{$jobBasicData[0]['seo_image']}}" alt="">
                                    <button type="button" class="btn btn-secondary mt-2" onclick="reuploadImage('seo_image')">Reupload</button>
                                </div>

                                 <!-- Inside your form in Blade template -->
                                 {{-- <div class="form-group row"> --}}
                                    <label class="col-4">SEO Keywords</label>
                                    <div class="col-6 mt-2">
                                        @php
                                        // Retrieve existing keywords or initialize empty array
                                        $keywords = isset($jobBasicData[0]['seo_keywords']) ? explode(',', $jobBasicData[0]['seo_keywords']) : [];
                                        @endphp
                                        <div id="keyword_container">
                                            @foreach($keywords as $keyword)
                                            <div class="input-group mb-2 keyword_row">
                                                <input name="seo_keywords[]" class="form-control" type="text" value="{{ $keyword }}" placeholder="Enter SEO Keyword">
                                                <div class="input-group-append">
                                                    <button class="btn btn-outline-secondary btn-sm remove_keyword_btn" type="button">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            @endforeach
                                        </div>
                                        <button id="add_keyword_btn" class="btn btn-info btn-sm">Add Keyword</button>
                                    </div>
                                {{-- </div> --}}
                            </div>

                            <div class="col-12">
                                <button id="action_button" class="btn btn-primary mt-4 offset-6">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
    <script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
    <script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
    <script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>
    <link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

    <!-- Include necessary libraries -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.js"></script>

    <script>
    $(document).ready(function () {
        $('#short_info').summernote({
            placeholder: 'Enter Post Short Information',
            tabsize: 2,
            height: 150,
            disableDragAndDrop: true
        });
    });

    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('preloader-active').style.display = 'none';
    });

    function slugAutoGenerate() {
        let title = document.getElementById('post_display_name').value;
        let slug = title.toLowerCase()
            .replace(/[^\w\s-]/g, '') // Remove all non-word chars
            .replace(/\s+/g, '-') // Replace spaces with -
            .replace(/--+/g, '-') // Replace multiple - with single -
            .trim(); // Trim spaces at the start and end
        document.getElementById('post_url').value = slug;
    }

    function reuploadImage(imageType) {
        document.getElementById(imageType).click();
    }

    document.getElementById('featured_img').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('featuredImgView').src = e.target.result;
            }
            reader.readAsDataURL(file);
        }
    });

    document.getElementById('seo_image').addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('seoImgView').src = e.target.result;
            }
            reader.readAsDataURL(file);
        }
    });
    </script>

    <script>
        setTimeout(function () {
            document.getElementById('preloader-active').style.display = 'none';
        }, 3000);
    </script>




<script>
    document.addEventListener("DOMContentLoaded", function() {
        const addButton = document.getElementById("add_keyword_btn");
        const keywordsContainer = document.getElementById("keyword_container");

        addButton.addEventListener("click", function(event) {
            event.preventDefault(); // Prevent form submission

            const newKeywordField = document.createElement("div");
            newKeywordField.classList.add("input-group", "mb-2", "keyword_row");
            newKeywordField.innerHTML = `
                <input name="seo_keywords[]" class="form-control" type="text" placeholder="Enter SEO Keyword">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary btn-sm remove_keyword_btn" type="button">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            `;
            keywordsContainer.appendChild(newKeywordField);

            const removeButton = newKeywordField.querySelector(".remove_keyword_btn");
            removeButton.addEventListener("click", function() {
                newKeywordField.remove();
            });

            updateKeywordInput(); // Update hidden input with current keywords
        });

        document.querySelectorAll(".remove_keyword_btn").forEach(button => {
            button.addEventListener("click", function() {
                button.closest(".keyword_row").remove();
                updateKeywordInput(); // Update hidden input after removal
            });
        });

        // Function to update hidden input with current keywords
        function updateKeywordInput() {
            const keywordInputs = document.querySelectorAll('input[name="seo_keywords[]"]');
            const keywordValues = Array.from(keywordInputs).map(input => input.value.trim()).filter(Boolean);
            document.getElementById('seo_keywords').value = keywordValues.join(',');
        }
    });
</script>

@endsection

@section('customJs')

@endsection
