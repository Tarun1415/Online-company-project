{{-- @extends('layouts.admin-dashboard.admin-header-footer')
@section('content') --}}

@extends('admin.layouts.app')

@section('content')

<link rel="stylesheet" href="/assets/css/custom.css">
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

  <div class="wrapper d-flex align-items-stretch section-bg">


<div id="content" class="mx-1 mt-3">
<div class="col-12 d-flex justify-content-center px-0">
<div class="section-title col-auto">
<h1>Update Blog Content</h1></div>

</div>

<div class="row mt-4">
  <div class="col-12">
    <a class="btn btn-outline-primary col-2" href="/admin/blogs/update-post-data/{{$post_id}}">Post Basic Details</a>
    <a class="btn btn-primary col-2" href="/admin/blogs/update-vacancy-data/{{$post_id}}">Post Content</a>
    {{-- <a class="btn btn-outline-primary col-2" href="/admin/blogs/update-post-other-data/{{$post_id}}">Post Other Details</a> --}}
    <a class="btn btn-outline-primary col-2" href="/admin/blogs/update-post-date-data/{{$post_id}}">Post Important Dates</a>
    <a class="btn btn-outline-primary col-2" href="/admin/blogs/update-post-document-data/{{$post_id}}">Post Documents Links</a>
 
</div>
 
  <div class="col-12">
  <div class="card-body m-2" style="background-color: white;" >
    <form method="POST" action="/admin/blogs/update-vacancy-data/{{$post_id}}">
        {{csrf_field()}}
    
            <div class="form-group row">         
                <div class="container-fluid mt-4">
               <h5>Use Editor to write Blog Content</h5>
    
              
          <div class="fr-view">
          <input id="id" name="id" class="d-none form-control" value="<?php if (isset($vacancyData) && !empty($vacancyData)) { ?> {{$vacancyData[0]['id']}} <?php } ?>">
    
    <textarea id="summernote" name="vacancy_data"></textarea>
          </div>
          </div>
          </div>
          </div>
              <div class="col-12">
                  <button id="action_button" class="btn btn-primary mt-2 ofset-6">Submit</button>
                </div>
    
            </div>
    
        </form>
  </div>


</div>
</div>
<div>

<!-- include summernote css/js -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-bs4.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote-bs4.js"></script>



<script type="text/javascript">
    $(document).ready(function() {
        $('#summernote').summernote({
            placeholder: 'Enter Vacancy Details....',
            tabsize: 2,
            height: 300
        });


        <?php if (isset($vacancyData) && !empty($vacancyData)) { ?>

            $('#summernote').summernote('code', '<?php echo trim(preg_replace('/\s\s+/', ' ', html_entity_decode(htmlspecialchars_decode(str_replace('\'', '\\\'', $vacancyData[0]['vacancy_data']))))); ?>');

        <?php } else {
            ?>

            $('#summernote').summernote('code', '');


        <?php } ?>




    });


    function templateChange(node) {

        var arr1 = new Array();
        arr1[1] = '<table class="table table-bordered m-0" style="font-size: 1rem;"><tbody><tr><th>Post Name</th><th>Total Post</th></tr><tr><td><br></td><td><br></td></tr></tbody></table>';
        arr1[2] = '<table class="table table-bordered m-0" style="font-size: 1rem;"><tbody><tr><th>Post Name</th><th>Total Post</th><th>Age Limit</th></tr><tr><td><br></td><td><br></td><td><br></td></tr></tbody></table>';
        arr1[3] = '<table class="table table-bordered m-0"><tbody><tr><th>Post Name&nbsp;</th><th>General (UR)</th><th>OBC</th><th>EWS</th><th>SC</th><th>ST</th><th>Horizontal Reservation</th><th>Total</th></tr><tr><td><br></td><td><br></td><td><br></td><td><br></td><td><br></td><td><br></td><td><br></td><td><br></td></tr></tbody></table>';

        var templateVal = $(node).val();

        codeV = arr1[templateVal];

        $('#summernote').summernote('code', codeV);

    }

</script>
@endsection

@section('customJs')

@endsection