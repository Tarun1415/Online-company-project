@extends('admin.layouts.app')

@section('content')

<div id="preloader-active">
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="preloader-inner position-relative">
            <div class="preloader-circle"></div>
            <div class="preloader-img pere-text">
                <img src="{{ asset('assets/img/logo/logo-dog-NGO.png') }}" alt="">
            </div>
        </div>
    </div>
</div>

<main>
    <div class="container">
        <div class="sidebar">
            {{-- @include('include.admin-sidebar') --}}
        </div>

        <div id="content">
            <div class="section-title col-auto">
                <h1 id="heading">Add Post Details</h1>
            </div>

            <div class="row mt-4">
                <div class="col-12">
                    <div class="card-body m-2" style="background-color: white;">
                        <form method="POST" action="/admin/blogs/add-new-post-insert" enctype='multipart/form-data'>
                            {{ csrf_field() }}

                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td><label for="post_display_name">Post Title/Heading</label></td>
                                        <td>
                                            <input id="post_display_name" name="post_display_name" class="form-control" onkeyup="slugAutoGenerate()" type="text" required>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><label for="post_url">Post URL</label></td>
                                        <td>
                                            <input id="post_url" name="post_url" class="form-control" type="text" placeholder="Auto Generated and Editable">
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><label for="short_info">Post Information</label></td>
                                        <td>
                                            <textarea id="short_info" name="short_info" class="form-control"></textarea>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><label for="featured_img">Featured Image</label></td>
                                        <td>
                                            <input type="file" name="featured_img" accept="image/png, image/jpeg, application/pdf" required>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><label for="seo_title">SEO Title</label></td>
                                        <td>
                                            <input id="seo_title" name="seo_title" class="form-control" type="text">
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><label for="seo_description">SEO Description</label></td>
                                        <td>
                                            <textarea id="seo_description" name="seo_description" class="form-control"></textarea>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><label for="seo_image">SEO Image</label></td>
                                        <td>
                                            <input type="file" name="seo_image" accept="image/png, image/jpeg">
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><label for="seo_keywords">SEO Keywords</label></td>
                                        <td>
                                            <div id="seo-keywords-container">
                                                <div class="form-group row">
                                                    <div class="col-md-6">
                                                        <div class="mb-3">
                                                            <input type="text" name="seo_keywords[]" class="form-control" placeholder="Enter SEO Keyword">
                                                        </div>
                                                    </div>
                                                    <div class="col-md-2">
                                                        <button type="button" class="btn btn-success add-keyword">+</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td></td>
                                        <td>
                                            <button id="action_button" class="btn btn-primary">Submit</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Include necessary libraries -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.js"></script>

<script>
$(document).ready(function () {
    $('#short_info').summernote({
        placeholder: 'Enter Post Short Information',
        tabsize: 2,
        height: 150,
        disableDragAndDrop: true
    });

    // Hide preloader
    document.getElementById('preloader-active').style.display = 'none';
});

function slugAutoGenerate() {
    let title = document.getElementById('post_display_name').value;
    let slug = title.toLowerCase()
        .replace(/[^\w\s-]/g, '') // Remove all non-word chars
        .replace(/\s+/g, '-') // Replace spaces with -
        .replace(/--+/g, '-') // Replace multiple - with single -
        .trim(); // Trim spaces at the start and end
    document.getElementById('post_url').value = slug;
}

document.addEventListener("DOMContentLoaded", function() {
    const keywordsContainer = document.getElementById("seo-keywords-container");
    const addButton = document.querySelector(".add-keyword");

    addButton.addEventListener("click", function() {
        const newKeywordField = document.createElement("div");
        newKeywordField.classList.add("col-md-6", "mb-3");
        newKeywordField.innerHTML = `
            <div class="input-group">
                <input type="text" name="seo_keywords[]" class="form-control" placeholder="Enter SEO Keyword">
                <div class="input-group-append">
                    <button type="button" class="btn btn-danger remove-keyword">-</button>
                </div>
            </div>
        `;
        keywordsContainer.appendChild(newKeywordField);

        // Add event listener to remove keyword button
        const removeButton = newKeywordField.querySelector(".remove-keyword");
        removeButton.addEventListener("click", function() {
            newKeywordField.remove();
        });
    });
});
</script>

@endsection

@section('customJs')
@endsection
