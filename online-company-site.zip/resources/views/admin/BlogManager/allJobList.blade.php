@extends('admin.layouts.app')

@section('content')

    <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
    <link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
    <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">

    <div id="preloader-active">
        <div class="preloader d-flex align-items-center justify-content-center">
            <div class="preloader-inner position-relative">
                <div class="preloader-circle"></div>
                <div class="preloader-img pere-text">
                    <img src="{{ asset('assets/img/logo/logo-dog-NGO.png') }}" alt="">
                </div>
            </div>
        </div>
    </div>

    <main class="container-fluid">
        <div class="row">
            <div id="content" class="col-12">
                <div class="col-12 d-flex justify-content-center px-0">
                    <div class="section-title col-auto">
                        <h1 id="heading">All Blogs Manager</h1>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <table id="datatable" class="table table-responsive" data-search="true" data-pagination="true" style="display: inline-table">
                                <thead>
                                    <tr>
                                        <th>Post ID</th>
                                        <th>Post Title</th>
                                        @if (session('partner_id'))
                                            <th>Post Status</th>
                                        @endif
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($post_list as $job)
                                        <tr>
                                            <td>{{ $job['post_id'] }}</td>
                                            <td>{{ $job['post_display_name'] }}</td>
                                            @if (session('partner_id'))
                                                <td>
                                                    <select style="background-color: #0062cc; color: white;" onChange="statusChange(this, {{ $job['post_id'] }})">
                                                        @foreach (['live', 'in-process'] as $status)
                                                            <option value="{{ $status }}" {{ $job['post_status'] == $status ? 'selected' : '' }}>{{ $status }}</option>
                                                        @endforeach
                                                    </select>
                                                </td>
                                            @endif
                                            <td>
                                                <a class="btn btn-success text-white" href="/admin/blogs/update-post-data/{{ $job['post_id'] }}">Update</a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
    <script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
    <script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>
    <script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        $(document).ready(function () {
            $('#datatable').bootstrapTable();
            $('#datatable').dataTable();
        });

        function statusChange(node, post_id) {
            var changeStatus = $(node).val();

            Swal.fire({
                title: 'Are you sure?',
                text: 'You are about to change the post status.',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, change it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    var ajaxurl = '/partner/blogs/post-status-update/' + post_id + '/' + changeStatus;
                    $.ajax({
                        type: 'POST',
                        cache: false,
                        url: ajaxurl,
                        headers: { 'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content') },
                        success: function () {
                            Swal.fire('Success!', 'Status changed to ' + changeStatus, 'success');
                        },
                        error: function () {
                            Swal.fire('Error!', 'Status change failed.', 'error');
                        }
                    });
                }
            });
        }

        setTimeout(function () {
            document.getElementById('preloader-active').style.display = 'none';
        }, 3000);
    </script>
@endsection

@section('customJs')

@endsection


