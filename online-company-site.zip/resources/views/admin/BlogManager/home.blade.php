{{-- @extends('layouts.admin-dashboard.admin-header-footer')
@section('content') --}}


@extends('admin.layouts.app')

@section('content')

<link rel="stylesheet" href="/assets/css/custom.css">
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

  <div class="wrapper d-flex align-items-stretch section-bg">
  

 <div class="col-8">
 <div class="section-title col-auto">
 <h1>Blog Manager Dashboard</h1></div>
     <div class="card-body m-2" style="background-color: white;" >
     <table id="datatable" class="table table-bordered table-hover">
             <thead>
 
                 <tr>                   
                     <th>To Do</th>
                     <th>Action</th>                            
                 </tr>
 
            
             </thead>
             <tbody>
 
              
                     <tr>
                        <td>Add New Post</td>
                        <td><a class="btn btn-outline-success" href="/admin/blogs/add-new-post">Click ME</a></td>
                     </tr>
 
                     <tr>
                        <td>Update Existing Post</td>
                        <td><a class="btn btn-outline-primary" href="/admin/blogs/all-post-list">Click ME</a></td>
                     </tr>
 
                     <tr>
                        <td>Add New Organisation</td>
                        <td><a class="btn btn-outline-danger" href="/admin/blogs/organisation">Click ME</a></td>
                     </tr>
                     
                     <tr>
                        <td>Add New Sector</td>
                        <td><a class="btn btn-outline-warning" href="/admin/blogs/sector">Click ME</a></td>
                     </tr>
 
                     <tr>
                        <td>Add New tag</td>
                        <td><a class="btn btn-outline-primary" href="/admin/blogs/tags">Click ME</a></td>
                     </tr>
 
                     
             </tbody>
         </table>
     </div>

 
 
 
</div>

</div>
        
          
@endsection

@section('customJs')

@endsection