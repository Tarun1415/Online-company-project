{{-- @extends('layouts.admin-dashboard.admin-header-footer')
@section('content') --}}
@extends('admin.layouts.app')

@section('content')
<link rel="stylesheet" href="/assets/css/custom.css">
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

  <div class="wrapper d-flex align-items-stretch section-bg">


<div id="content" class="mx-1 mt-3">
  
<div class="col-12 d-flex justify-content-center px-0">
<div class="section-title col-auto">
<h1>Update Post Details</h1></div>

</div>

<div class="row mt-4">
  <div class="col-12">
    <a class="btn btn-outline-primary col-2" href="/admin/blogs/update-post-data/{{$post_id}}">Post Basic Details</a>
    <a class="btn btn-outline-primary col-2" href="/admin/blogs/update-vacancy-data/{{$post_id}}">Post Content</a>
    {{-- <a class="btn btn-outline-primary col-2" href="/admin/blogs/update-post-other-data/{{$post_id}}">Post Other Details</a> --}}
    <a class="btn btn-primary col-2" href="/admin/blogs/update-post-date-data/{{$post_id}}">Post Important Dates</a>
    <a class="btn btn-outline-primary col-2" href="/admin/blogs/update-post-document-data/{{$post_id}}">Post Documents Links</a>
 
</div>
 
  <div class="col-12">
  <div class="card-body m-2" style="background-color: white;" >
    <form method="POST" action="/spreaderstogetherforever/naukarimela/auth/update-post-date-data/{{$post_id}}">
      {{csrf_field()}}
  
          <div class="form-group row">         
              <div class="container-fluid mt-4">
             <h5>Update Post Date Data</h5>
             <?php if (isset($default_keys_important_dates)) { ?>
                 <div class="row">
  <?php
              foreach ($default_keys_important_dates as $defK => $defD) {
                if (isset($important_dates_array1[$defK])) { ?>
                    <div class="col-3 nopadding">
                      <div class="form-group">
                        <input type="text" class="form-control" name="{{$defK}}" value="{{$important_dates_array1[$defK]['value_display_name']}}" placeholder="{{$defD}}">
                      </div>
                    </div>
                    <div class="col-3 nopadding">
                      <div class="form-group">
                        <input type="text" class="form-control" name="{{$defK}}_value" value="{{$important_dates_array1[$defK]['date']}}" placeholder="Date">
                      </div>
                    </div>
  
                   
                <?php } else { ?>
  
                    <div class="col-3 nopadding">
                      <div class="form-group">
                        <input type="text" class="form-control" name="{{$defK}}" value="{{$defD}}" placeholder="{{$defD}}">
                      </div>
                    </div>
                    <div class="col-3 nopadding">
                      <div class="form-group">
                        <input type="text" class="form-control" name="{{$defK}}_value" value="" placeholder="Date">
                      </div>
                    </div>
  
                <?php } } ?> </div> <?php } ?> 
                     
  
       
        </div>
        </div>
        </div>
            <div class="col-12">
                <button id="action_button" class="btn btn-primary mt-4 ofset-6">Submit</button>
              </div>
  
          </div>
  
      </form>
  </div>


</div>
</div>
                </div>


                @endsection

                @section('customJs')
                
                @endsection