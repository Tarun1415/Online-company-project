{{-- @extends('layouts.admin-dashboard.admin-header-footer')
@section('content') --}}

@extends('admin.layouts.app')

@section('content')
<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
<link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="/assets/css/custom.css">
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/admin-dashboard.css">
<link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

<div class="wrapper d-flex align-items-stretch section-bg">


  <div id="content" class="mx-1 mt-3">

    <div class="col-12 d-flex justify-content-center px-0">
      <div class="section-title col-auto">
        <h1>Add Sector Details</h1>
      </div>

    </div>


    <div class="row mt-4">
      <div class="col-12">
        <div class="card-body m-2">
          <form method="POST" id="sector_form" data-parsley-validate="">
            {{csrf_field()}}

            <div class="form-group row">

              <input id="sector_id" name="sector_id" class="d-none form-control">

              <div class="col-5">
                <input id="sector_show_name" name="sector_show_name" class="form-control" onkeyup="slugAutoGenerate()" type="text" placeholder="Sector Show Name" required>
              </div>

              <div class="col-5">
                <input id="sector_url" name="sector_url" class="form-control" type="text" placeholder="Sector Url Auto Generated and editable">
              </div>

              <div class="col-2">
                <button id="action_button" class="btn btn-primary">Submit</button>
              </div>

            </div>

          </form>
        </div>
        <hr>
        <div class="container">
          <div class="col-12">
            <table id="datatable" class="table table-bordered">
              <thead>

                <tr>
                  <th>Sector Name</th>
                  <th>Update</th>
                </tr>


              </thead>
              <tbody>


                <?php foreach ($sectorList as $sector) { ?>
                  <tr>
                    <td id="{{$sector['sector_id']}}_row">{{$sector['sector_show_name']}}</td>
                    <td><button class="btn btn-success text-white" onClick="sectorUpdate(<?php echo $sector['sector_id']; ?> ,'<?php echo $sector['sector_url']; ?>', '<?php echo $sector['sector_show_name']; ?>');">Update</button></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>


  </div>
</div>
</div>
</div>
</div>
 



<link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">

<script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>



<!-- Include the plugin's CSS and JS: -->

<script type="text/javascript">
  $(document).ready(function() {

    $('#datatable').dataTable();



  });
</script>

<!-- For Slud Generation Start-->
<script>
  function slugAutoGenerate() {
    var x = document.getElementById("sector_show_name");
    x.value = x.value;
    slug = slugify(x.value);
    document.getElementById('sector_url').value = slug;
  }

  function slugify(string) {
    const a = 'àáâäæãåāăąçćčđďèéêëēėęěğǵḧîïíīįìłḿñńǹňôöòóœøōõőṕŕřßśšşșťțûüùúūǘůűųẃẍÿýžźż·/_,:;'
    const b = 'aaaaaaaaaacccddeeeeeeeegghiiiiiilmnnnnoooooooooprrsssssttuuuuuuuuuwxyyzzz------'
    const p = new RegExp(a.split('').join('|'), 'g')

    return string.toString().toLowerCase()
      .replace(/\s+/g, '-') // Replace spaces with -
      .replace(p, c => b.charAt(a.indexOf(c))) // Replace special characters
      .replace(/&/g, '-and-') // Replace & with 'and'
      .replace(/[^\w\-]+/g, '') // Remove all non-word characters
      .replace(/\-\-+/g, '-') // Replace multiple - with single -
      .replace(/^-+/, '') // Trim - from start of text
      .replace(/-+$/, '') // Trim - from end of text
  }
</script>
<!-- For Slug Generation End -->

<!-- Validation JS  -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.9.2/parsley.min.js"></script>

<script type="text/javascript">
  $(function() {
    $('#sector_form').parsley({
        errorClass: 'is-invalid',
        successClass: 'is-valid',
        trigger: 'change',
        classHandler: function(ParsleyField) {
          return ParsleyField.$element.closest('.form-group-parsley');
        },
        errorsContainer: function(ParsleyField) {
          return ParsleyField.$element.closest('.form-group-parsley');
        },
        errorsWrapper: '<span class="form-text text-danger"></span>',
        errorTemplate: '<span></span>'

      }).on('field:validated', function() {
        var ok = $('.is-invalid').length === 0;
        $('.bs-callout-info').toggleClass('hidden', !ok);
        $('.bs-callout-warning').toggleClass('hidden', ok);
      })
      .on('form:submit', function() {

        addSector();
        return false;


      });
  });


  function addSector() {

    let formData = $('#sector_form').serialize();



    $.ajax({
      url: "/admin/blogs/organisation/add-sector",
      method: "post",
      data: formData,
      success: function(data) {
        dataArray = JSON.parse(data);
        if (dataArray.status == 'success') {
          console.log('success', dataArray.id);
          swal(dataArray.message);
          $('#sector_form')[0].reset();
          if (dataArray.message == "Successfully Added") {
            $('#datatable').append("<td>" + dataArray.data + "</td><td><a class='btn btn-outline-success text-white' href='#'>Update</a></td>");
          } else {
            $('#' + dataArray.id + '_row').html(dataArray.data);
          }


        } else {
          swal("Oops! Something Went Wrong");
        }
      },
      error: function(xhr) {
        console.log('error', xhr);
      }
    });



  }

  function sectorUpdate(id, url, name) {
    $('#sector_id').val(id);
    $('#sector_show_name').val(name);
    $('#sector_url').val(url);
    $('#action_heding').html("Update Sector");
    $('#action_button').text("Update");
    $('#action_button').removeClass("btn btn-primary");
    $('#action_button').addClass("btn btn-success");

  }
</script>
@endsection

@section('customJs')

@endsection