@extends('admin.layouts.app')
@section('content')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet" href="/assets/css/custom.css">
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet"> 
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

<div class="wrapper d-flex align-items-stretch section-bg">
  

<div id="content" class="mx-1 mt-3">

{{-- <div class="col-12 d-flex justify-content-center px-0">
<div class="section-title col-auto">
<h1>Add Categories</h1></div>
</div> --}}
<section class="content-header">					
    <div class="container-fluid my-2">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 style="color: blue">Update Asked Questions</h1>
            </div>
            <div class="col-sm-6 text-right">
                
            </div>
        </div>
    </div>
    <!-- /.container-fluid -->
</section>

<section class="content" style="background-color: azure">
    <!-- Default box -->
    <div class="container-fluid">
        <form method="post" id="register-form" enctype="multipart/form-data" onsubmit="saveRegister(event)">
            @csrf
            <div class="card">
                <div class="card-body">								
                    <div class="row">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label for="name">All subServices</label>
                                <select name="subpart_id" id="subpart_id" class="form-control">
                                    <option value="">Select Service</option>
                                    @foreach ($services as $service)
                                    <option value="{{ $service->id }}" {{ $categories->subpart_id == $service->id ? 'selected' : '' }}>
                                        {{ $service->name }}
                                    </option>
                                @endforeach
                                </select>
                            </div>
                        </div> 
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="name">Question</label>
                                <input type="text" name="name" id="name" class="form-control" placeholder=" Category Name" required oninput="generateSlug()"  value="{{$categories->name}}">	
                            </div>
                        </div>


                        {{-- <div class="col-md-6">
                            <div class="mb-3">
                                <label for="slug">Post Url</label>
                                <input type="text" readonly name="slug" id="slug" class="form-control" placeholder="Slug" value="{{$categories->slug}}">		
                                {{-- readonly --}}
                            {{-- </div>
                            <p> </p>

                        </div> --}} 

                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="description">Answers</label>
                                <textarea name="description" id="description" class="form-control" rows="4" placeholder="Post Description">{{$categories->description}}</textarea>
                            </div>
                        </div> 

                        {{-- <div class="col-md-6">
                            <div class="form-group mb-3">
                                <label for="exampleInputEmail1">Image</label>
                                <input type="file" class="form-control" name="input_image" id="inputImage" aria-describedby="emailHelp">
                                @if(!empty($categories->image))
                                <div>
                                
                                    <img src="{{asset('uploads/'.$categories->image)}}" class="img-thumbnail" width="50" >
                                </div>
                                @endif
                            </div>
                        </div> --}}
                        
                       
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label for="status">status</label>
                                <select name="status" id="status" class="form-control">
                                    <option {{($categories->status==1) ? 'selected':''}} value=1>Active</option>
                                    <option {{($categories->status==0) ? 'selected':''}} value=0>InActive</option>
                                </select>
                            </div>
                        </div>		

                    </div>
                </div>							
            </div>
            <div class="pb-5 pt-3">                
                <button type="submit" class="btn btn-primary">Update</button>
                <a href="{{route('admin.home_question')}}" class="btn btn-outline-dark ml-3">Cancel</a>
            </div>
        </form>
    </div>
</section>
</div>
</div>
        
<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">

<script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>




<link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">

<script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>



<script>
    function generateSlug() {
        var PostTitle = $('#name').val();
        var slug = PostTitle.toLowerCase().replace(/\s+/g, '-').replace(/[^\w\-]+/g, '');
        $('#slug').val(slug);
    }
    function saveRegister(e) {
    e.preventDefault();
    var formData = new FormData($('#register-form')[0]);
    formData.append('_method', 'POST'); // Assuming you're using POST for updating
    formData.append('_token', $('meta[name="csrf-token"]').attr('content')); // Add CSRF token

    Swal.fire({
        title: "Do you want to save the changes?",
        showDenyButton: true,
        showCancelButton: true,
        confirmButtonText: "Update",
        denyButtonText: `Don't Update`
    }).then((result) => {
        if (result.isConfirmed) {
            // If the user confirms the update, proceed with the AJAX request
            $.ajax({
                url: "{{ route('admin.question_update',$categories->id) }}",
                method: "POST",
                data: formData,
                contentType: false,
                processData: false,
                success: function(response) {
                    console.log(response);
                    // Show success message
                    Swal.fire("Update!", "", "success");
                    // Redirect to the home page after successful update
                    window.location.href = "{{ route('admin.home_question') }}";
                },
                error: function(xhr, status, error) {
                    // Show error message if the AJAX request fails
                    Swal.fire("Error!", "An error occurred while updating the question post.", "error");
                }
            });
        } else if (result.isDenied) {
            
        }
    });
}
    // function saveRegister(e) {
    //     e.preventDefault();
    //     console.log($('#register-form'));
    //     var registerData = $('#register-form')[0];
    //     var formData = new FormData(registerData);

    //     $.ajax({
    //         url: "{{route('admin.question_update',$categories->id)}}",
    //         method: "POST",
    //         data: formData,
    //         contentType: false,
    //         processData: false,
    //         success: function(response) {
    //             console.log(response);
    //             Swal.fire({
    //                 title: "Add successfully !",
    //                 text: "Teacher added successfully!",
    //                 icon: "success",
    //                 showConfirmButton: false,
    //                 timer: 1500
                    
    //             });
    //             window.location.href = "{{ route('admin.home_question') }}";
    //         }
    //     });
    // }
</script>



@endsection

@section('customJs')

@endsection






