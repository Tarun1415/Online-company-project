@extends('admin.layouts.app')

@section('content')


<div id="content" class="mx-1 mt-3">

<div class="col-12 d-flex justify-content-center px-0">
<div class="section-title col-auto">
<h1>Dashboard
   
</h1></div>

</div>

<div class="row mx-0">



<div class="col-12 d-none1 px-0" id="table-div">
<div class="card p-3">
  
    <button class="btn btn-success col-2 d-none" id="multipleAroUpdate" onClick="updateMultipleTags()" style="height:40px;">Update  <span class="badge badge-light" id="selectedAros">0</span></button>

    <table class="table-responsive-sm"
    id="table"
    data-show-refresh="true"
    data-pagination="true"
    data-show-export="true"
    data-search="true"
    data-search-on-enter-key="true"
    data-show-search-button="true"
    data-url="{{url('')}}/admin/dashboard/Ajax"
    data-side-pagination="server"
    data-locale="en-us"
    data-show-columns="true"
    data-buttons-class="primary-bg"
    data-header-style="headerStyle"
    data-toolbar="#toolbar"
    data-reorderable-columns="false">
    <thead>
        <tr class="button-style">
          <th data-field="serial" data-formatter="serialNumberFormatter">SN.</th>
            <th data-field="user_name" data-sortable="false">Customer Name</th>
            <th data-field="user_email" data-sortable="false">Customer Email</th>
            <th data-field="action" data-sortable="false">Action</th> 
        </tr>
    </thead>
</table>



</div>
</div>





<!-- </div> -->
<!-- </div> -->



</div>
</div>
</div>











  <!-- Button trigger modal -->

  <!--Add New Lead Modal -->

<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">

<script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>

<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.js"></script>


<script>



</script>


<script>
  function statusChange(node, aro_id) {
      var changeStatus = $(node).val();

      ajaxurl = '/partner/statusupdate/' + aro_id + '/' + changeStatus,

      swal({
              title: "Do you want to change status to " + changeStatus + "?",
              // text: "Are you sure to proceed?",   
              type: "warning",
              showCancelButton: true,
              // customClass: 'sweetalert-lg',
              confirmButtonColor: "#DD6B55",
              confirmButtonText: "Yes!",
              cancelButtonText: "No!",
              closeOnConfirm: false,
              closeOnCancel: true
          },
          function(isConfirm) {
              if (isConfirm) {

                  $.ajax({
                      type: 'POST',
                      cache: false,
                      url: ajaxurl,

                      success: function(response) {
                          responseArr = JSON.parse(response);

                      }
                  });
                  $('#table').bootstrapTable('refresh');
                  swal.close()
              }
          });
  }


  function availabilityChange(node, aro_id) {
      var changeStatus = $(node).val();

      ajaxurl = '/partner/availabilityupdate/' + aro_id + '/' + changeStatus,

      swal({
              title: "Do you want to change Availability to " + changeStatus + "?",
              // text: "Are you sure to proceed?",   
              type: "warning",
              showCancelButton: true,
              // customClass: 'sweetalert-lg',
              confirmButtonColor: "#DD6B55",
              confirmButtonText: "Yes!",
              cancelButtonText: "No!",
              closeOnConfirm: false,
              closeOnCancel: true
          },
          function(isConfirm) {
              if (isConfirm) {

                  $.ajax({
                      type: 'POST',
                      cache: false,
                      url: ajaxurl,

                      success: function(response) {
                          responseArr = JSON.parse(response);

                      }
                  });



                  $('#table').bootstrapTable('refresh');

              }

              swal.close()

          });
  }

</script>



        <script>
        $(function() {
        // $('#table tbody tr').addClass("button-style");

        $('#table').bootstrapTable(
        {
          exportDataType: 'all',
          exportTypes : ['csv'],
          rowStyle :  function(row, index) {
          return {
          classes: 'button-style',           
      }
    },
        queryParams: function (p) {
        return {         
          limit: p.limit,
          offset: p.offset,
          search : p.search,
          order : p.order,      

          user_verification_status : $('#user_verification_status').val()  


    };
        },
        onLoadSuccess: function (data) {
        $('#table-div').removeClass('d-none');
      }
    }

  )


        $('#searchBtn').on('click', function() {
        $('#table').bootstrapTable('destroy'); //Destroy bootstrap table
        $('#table').bootstrapTable(
        {
          exportDataType: 'all',
          exportTypes : ['csv'],
          rowStyle :  function(row, index) {
          return {
          classes: 'button-style',           
    }
        },
        queryParams: function (p) {
        return {

          limit: p.limit,
          offset: p.offset,
          search : p.search,
          order : p.order,

        user_verification_status : $('#user_verification_status').val() 

        };
      }
   }
 )
//You can do it in one line
//$('#table').bootstrapTable('destroy').bootstrapTable(); 
});



})

function addKeywordInput(event) {
  event.preventDefault(); // Prevent default form submission
  const container = document.getElementById("seo_keywords_container");
  const newKeywordInput = `
    <div class="input-group mb-2">
      <input name="bank_seo_keyword[]" class="form-control" type="text" placeholder="Enter SEO Keyword">
      <div class="input-group-append">
        <button class="btn btn-outline-secondary btn-sm remove_keyword_btn" type="button">
          <i class="fas fa-trash-alt"></i> <!-- Font Awesome delete icon -->
        </button>
      </div>
    </div>
  `;
  container.insertAdjacentHTML("beforeend", newKeywordInput);
}

// Function to remove a keyword input field
function removeKeywordInput(event) {
  const keywordInput = event.target.closest(".input-group");
  if (keywordInput) {
    keywordInput.remove();
  }
}

// Event listener for adding more keywords
document.getElementById("add_keyword_btn").addEventListener("click", addKeywordInput);

// Event listener for removing a keyword
document.addEventListener("click", function(event) {
  if (event.target && event.target.classList.contains("remove_keyword_btn")) {
    removeKeywordInput(event);
  }
});

function serialNumberFormatter(value, row, index) {
    var options = $('#table').bootstrapTable('getOptions');
    var pageNumber = options.pageNumber;
    var pageSize = options.pageSize;
    return (pageNumber - 1) * pageSize + index + 1;
}

</script>




@stop