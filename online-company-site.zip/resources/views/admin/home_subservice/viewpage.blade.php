@extends('layouts.admin-dashboard.admin-header-footer')

@section('content')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function(){
    $('.dropdown-toggle').dropdown();
});

</script>
<link rel="stylesheet" href="/assets/css/custom.css">
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

<div class="wrapper d-flex align-items-stretch section-bg">

  

<div id="content" class="mx-1 mt-3">


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


    <section class="content">
        <!-- Default box -->
        <div class="container-fluid">
            <div class="card">


    <section class="content-header">					
        <div class="container-fluid my-2">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 style="color:blue">All Home View Page</h1>
                    <!-- First Dropdown menu for adding GST registration -->
                
                    

                    {{-- Fillter --}}
                
                    <!-- Second Dropdown menu -->

                    
                                             
                </div>
                <div class="col-sm-6 text-right">
                   
                </div>
            </div>
        </div>
 
        <!-- /.card -->
    </section>
</div></div></section>
    <div class="dropdown" style="display: inline-block;">
        <button class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            {{-- Add sub Service Home page --}}
            View all GST Page
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <!-- Dropdown items -->
            <a class="dropdown-item" href="{{route('admin.gstshowpage')}}">GST Registration</a>
            <a class="dropdown-item" href="{{route('admin.gst_filling')}}">GST Filing</a>
            <a class="dropdown-item" href="{{route('admin.gst_advisory')}}">GST Advisory</a>
            <a class="dropdown-item" href="{{route('admin.tds_return')}}">TDS Return Filing</a>
            <a class="dropdown-item" href="{{route('admin.ind_income')}}">Individual Income Tax Filing</a>
            <a class="dropdown-item" href="{{route('admin.tax_return')}}">Proprietorship Tax Return Filing</a>
        </div>
    </div>

    <div class="dropdown" style="display: inline-block;">
        <button class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            {{-- Add sub Service Home page --}}
       Company Registration
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <!-- Dropdown items -->
            <a class="dropdown-item" href="{{route('admin.partnership_firm')}}">Partnership Firm</a>
            <a class="dropdown-item" href="{{route('admin.producer')}}">Producer Company</a>
            <a class="dropdown-item" href="{{route('admin.nidhi_comp')}}">Nidhi Company</a>
            <a class="dropdown-item" href="{{route('admin.sole_proprietorship')}}">Sole proprietorship</a>
            <a class="dropdown-item" href="{{route('admin.one_person')}}">One person Company</a>
            <a class="dropdown-item" href="{{route('admin.ltd_partnership')}}">Limited Liability Partnership</a>
            <a class="dropdown-item" href="{{route('admin.pvtltd_comp')}}">Private Limited Company</a>
        </div>
    </div>
    <div class="dropdown" style="display: inline-block;">
        <button class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            {{-- Add sub Service Home page --}}
           	
Convert Business
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <!-- Dropdown items -->
            <a class="dropdown-item" href="#">Private Limited to One Person Company</a>
            <a class="dropdown-item" href="#">Private to Public Limited Company</a>
            <a class="dropdown-item" href="#">Partnership to LLP</a>
            <a class="dropdown-item" href="{{route('admin.proprietorship_comp')}}">Proprietorship to PVT LTD Company</a>
        
        </div>
    </div>
    <div class="dropdown" style="display: inline-block;">
        <button class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            {{-- Add sub Service Home page --}}
            	
Corporate Compliance
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <!-- Dropdown items -->
            <a class="dropdown-item" href="{{route('admin.balance_sheet')}}">Balance Sheet Preparation and Matching</a>
            <a class="dropdown-item" href="{{route('admin.rbi_compliance')}}">RBI Compliance</a>
            <a class="dropdown-item" href="{{route('admin.annual_reciept')}}">Annual Auditing With Proper Reciept</a>
      
        </div>
    </div>
    <div class="dropdown" style="display: inline-block;">
        <button class="btn btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            {{-- Add sub Service Home page --}}
            Labour Compliance
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <!-- Dropdown items -->
            <a class="dropdown-item" href="#">POSH Compliance</a>
            <a class="dropdown-item" href="#">Employee Stock Option Plan</a>
            <a class="dropdown-item" href="#">Shops and Establishments License</a>
            <a class="dropdown-item" href="#">Professional Tax Registration</a>
            <a class="dropdown-item" href="#">Provident Fund Registration</a>
            <a class="dropdown-item" href="#">ESI Registration</a>
        </div>
    </div>
</div>
</div>
<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
<script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>
<link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

@endsection