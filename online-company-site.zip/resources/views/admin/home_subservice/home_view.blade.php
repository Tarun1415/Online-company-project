@extends('layouts.default-new')


@if (!empty($page->detail))
    @section('title', $page->detail->seo_title ?? '')
    @section('seo_description', $page->detail->seo_description ?? '')
    @section('seo_keywords', $page->detail->seo_keywords ?? '')
    @section('seo_img', $page->detail->seo_img ? asset('uploads/seo/' . $page->detail->seo_img) : asset('uploads/seo/default.jpg')) <!-- Ensure seo_img is set here -->

@endif
{{-- @section('content') --}}

@section('content')



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet">

<div class="bg-img">
    <div class="container-fluid">
        <div class="row">
            <div class="first-section">
                <div class="col-8 containerLeft mt-5">
                    @if (!empty($page->detail))
                        <h2>{{ $page->detail->title ?? '' }}</h2>
                        <p>{{ $page->detail->description ?? '' }}</p>
                        <a href="/signup">
                            <button class="button btn-sm bg-white p-1">Get Started</button>
                        </a>
                    @endif
                    
                </div>
            </div>
        </div>
        @include('snippet.register-company')

    </div>
</div>

<section id="features" class="features">
    <div class="container" data-aos="fade-up">
        <ul class="nav nav-tabs row gy-4 d-flex" role="tablist">
            @if (!empty($page->detail))
                @foreach (['title1', 'title2', 'title3', 'title4', 'title5', 'title6'] as $index => $title)
                    @if (!empty($page->detail->$title))
                        <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                            <a class="nav-link {{ $index == 0 ? 'active' : '' }}" data-bs-toggle="tab" data-bs-target="#tab-{{ $index + 1 }}" role="tab">
                                <i class="bi {{ ['bi-binoculars', 'bi-box-seam', 'bi-brightness-high', 'bi-command', 'bi-easel', 'bi-map'][$index] }}"></i>
                                <h4>{{ $page->detail->$title }}</h4>
                            </a>
                        </li>
                    @endif
                @endforeach
            @endif
        </ul>

        <div class="tab-content">
            @if (!empty($page->detail))
                @foreach (range(1, 6) as $index)
                    @if (!empty($page->detail->{'text' . $index}))
                        <div class="tab-pane {{ $index == 1 ? 'active show' : '' }}" id="tab-{{ $index }}" role="tabpanel">
                            <div class="row gy-4">
                                <div class="col-lg-8 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="100">
                                    <div>{!! $page->detail->{'text' . $index} !!}</div>
                                </div>
                                <div class="col-lg-4 order-1 order-lg-2 text-center">
                                    @if (!empty($page->detail->{'image' . $index}))
                                        <img src="{{ asset('uploads/' . $page->detail->{'image' . $index}) }}" alt="course instructor picture">
                                    @endif
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            @endif
        </div>
    </div>
</section>

<section id="faq" class="faq">
    <div class="container-fluid" data-aos="fade-up">
        <div class="row gy-4">
            <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch order-2 order-lg-1">
                <div class="content px-xl-5">
                    <h3>Frequently Asked <strong>Questions</strong></h3>                
                    <div class="accordion accordion-flush px-xl-5" id="faqlist">
                        <!-- Static FAQ items -->
                        <div class="accordion-item" data-aos="fade-up" data-aos-delay="200">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                                    <i class="bi bi-question-circle question-icon"></i>
                                    Does this process require my physical presence?
                                </button>
                            </h3>
                            <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                                <div class="accordion-body">
                                    No, the procedure of forming a company in India is entirely online. You do not need to be physically there at all because you can complete all documents electronically. All the necessary forms and documentation must be digitised and sent to us.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item" data-aos="fade-up" data-aos-delay="300">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                                    <i class="bi bi-question-circle question-icon"></i>
                                    Is an audit of a company's books required?
                                </button>
                            </h3>
                            <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                                <div class="accordion-body">
                                    Yes, regardless of its revenue, a private limited firm is required to employ an auditor. In fact, within 30 days of formation, an auditor must be engaged. Given that penalties for non-compliance can reach millions of rupees and possibly result in the blacklisting of directors, compliance is crucial for a private limited business.
                                </div>
                            </div>
                        </div>

                        <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                            <h3 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                                    <i class="bi bi-question-circle question-icon"></i>
                                    Who issues the corporation a certificate of registration?
                                </button>
                            </h3>
                            <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                                <div class="accordion-body">
                                    The Ministry of Corporate Affairs makes available the company's registration certificate online.
                                </div>
                            </div>
                        </div>

                        <!-- Dynamic FAQ items -->
                        @forelse ($page->questions as $index => $question)
                            <div class="accordion-item" data-aos="fade-up" data-aos-delay="{{ 500 + ($index * 100) }}">
                                <h3 class="accordion-header" id="heading-{{ $index }}">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-{{ $index }}" aria-expanded="false" aria-controls="collapse-{{ $index }}">
                                        <i class="bi bi-question-circle question-icon"></i>
                                        {{ $question->name }}
                                    </button>
                                </h3>
                                <div id="collapse-{{ $index }}" class="accordion-collapse collapse" aria-labelledby="heading-{{ $index }}" data-bs-parent="#faqlist">
                                    <div class="accordion-body">
                                        {!! $question->description !!}
                                    </div>
                                </div>
                            </div>
                        @empty
                            <!-- Optional: Display a message if there are no dynamic FAQs -->
                            <div class="accordion-item">
                                <div class="accordion-body">
                                   
                                </div>
                            </div>
                        @endforelse
                    </div>
                </div>
            </div>
            <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img" style='background-image: url("assets/img/faq.png");'>&nbsp;</div>
        </div>
    </div>
</section>



{{-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> --}}
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        AOS.init();
    });
</script>

{{-- @include('home-sections.recent-video-posts') --}}

@stop


