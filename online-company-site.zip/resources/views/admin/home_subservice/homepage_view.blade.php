@extends('admin.layouts.app')
@section('content')


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.0/js/bootstrap.bundle.min.js"></script>
<script>
    $(document).ready(function(){
    $('.dropdown-toggle').dropdown();
});

</script>

<link rel="stylesheet" href="/assets/css/custom.css">
<link href="/assets/home-theme/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/home-theme/vendor/icofont/icofont.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/admin-dashboard.css">
  <link href="/assets/home-theme/css/style-dashboard.css" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
  <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.16/dist/summernote-bs4.min.css" rel="stylesheet">

<div class="wrapper d-flex align-items-stretch section-bg">

  

<div id="content" class="mx-1 mt-3">


    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <div class="container-fluid">
        <div class="card">
    <section class="content-header">					
        <div class="container-fluid my-2">
            <div class="row mb-2">
                <div class="col-sm-6">
                   
                    

                    {{-- Fillter --}}
                
                    <!-- Second Dropdown menu -->

                    
                    <div class="dropdown" style="display: inline-block; margin-left: 10px;">
                        <form action="{{ route('admin.homeview') }}" method="GET">
                            <div class="row mb-2">
                                <div class="col-md-6">
                                    <select name="service_name" class="form-control">
                                        <option value="">All Product</option>
                                        @foreach($services as $service)
                                            <option value="{{ $service->name }}" {{ $selectedService == $service->name ? 'selected' : '' }}>
                                                {{ $service->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                 </div>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-primary">Filter</button>
                                </div>
                            </div>
                        </form>
                    </div>                                          
                </div>
                <div class="col-sm-6 text-right">
                    <a href="{{route('admin.showsubservice')}}" class="btn btn-dark">Back</a>
                    <a href="{{route('admin.addview')}}" class="btn btn-dark">Add product view</a>
                
                    
                </div>
            </div>
        </div>

     
                <div class="card-header">
                    <div class="card-tools">
                    </div>
                </div>
                <div class="card-body table-responsive p-0">								
                    <table class="table table-hover text-nowrap">
                        <thead style="background-color:azure">
                            <tr >
                                <th width="60">id</th>
                                <th width="80"></th>
                                <th>SubSevice Name</th>
                                <th>Page Name</th>
                                {{-- <th><h1>description</h1></th> --}}
                                <th>Tittle1</th>
                                <th>Tittle2</th>
                                <th>Tittle3</th>
                                <th>Tittle4</th>
                               
                                
                                
                                {{-- <th><h1>Post Description</h1></th> --}}
                                
                                <th width="100">Status</th>
                                <th width="100">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                                                       
                            @if($categories->isNotEmpty())
    
                            @foreach ($categories as $index => $category)    
                            <tr>
                                <td>{{ $category->id}}</td>
                                {{-- <td>{{ $index + 1 }}</td> --}}
                                
                                <td>    
                                    <img src="{{asset('uploads/'.$category->image)}}" class="img-thumbnail" width="50" >
                                    
                                </td>
                                <td>{{ $category->serviceName}}</td>
                                <td>{{ $category->name}}</td>
                                <td>{{ $category->title1}}</td>
                                <td>{{ $category->title2}}</td>
                                <td>{{ $category->title3}}</td>
                                <td>{{ $category->title4}}</td>
                               
                                
                                {{-- <td><h1>{{ $category->description}}</h1></td> --}}
                               
                                {{-- <td><h1>{{ $category->description}}</h1></td> --}}
                               
                                <td>
                                    @if($category->status == 1)
                                    <svg class="text-success-500 h-6 w-6 text-success" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
        
                                    @else
                                    <svg class="text-danger h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" aria-hidden="true">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                    </svg>
                                    @endif
                                </td>                                                           
                                    <td>
                                        <a href="{{route('admin.product_edit', $category->id)}}" class="btn btn-outline-warning">Update</a>
                                       
                                  
                                <a href="{{route('admin.product_delete', $category->id)}}" class="btn btn-primary delete-btn">Delete</a>
                                    <script>
                                        $(document).ready(function() {
                                            // Add click event listener to delete buttons with class 'delete-btn'
                                            $('.delete-btn').on('click', function(e) {
                                                e.preventDefault(); //Prevent default link behavior
    
                                                //Store the href attribute value (delete route) in a variable
                                                var deleteRoute = $(this).attr('href');
    
                                                // Show SweetAlert confirmation dialog
                                                Swal.fire({
                                                    title: "Are you sure?",
                                                    text: "",
                                                    icon: "warning",
                                                    showCancelButton: true,
                                                    confirmButtonColor: "#3085d6",
                                                    cancelButtonColor: "#d33",
                                                    confirmButtonText: "Yes, delete it!"
                                                }).then((result) => {
                                                    // If user confirms deletion
                                                    if (result.isConfirmed) {
                                                        // Perform AJAX request to delete the item
                                                        $.ajax({
                                                            url: deleteRoute,
                                                            method: "POST",
                                                            data: {
                                                                _method: 'DELETE', // Use POST method with _method=DELETE for Laravel
                                                                _token: '{{ csrf_token() }}' // Add CSRF token for security
                                                            },
                                                            success: function(response) {
                                                                // Show success message
                                                                Swal.fire({
                                                                    title: "Deleted!",
                                                                    text: "Your file has been deleted.",
                                                                    icon: "success"
                                                                }).then(() => {
                                                                    // Reload the page after successful deletion
                                                                    location.reload();
                                                                });
                                                            },
                                                            error: function(xhr, status, error) {
                                                                // Show error message
                                                                Swal.fire({
                                                                    title: "Error!",
                                                                    text: "An error occurred while deleting the file.",
                                                                    icon: "error"
                                                                });
                                                            }
                                                        });
                                                    }
                                                });
                                            });
                                        });
                                    </script>                                   
                                </td>
                            </tr>    
                            @endforeach   
                            @else
                            <tr>
                                <td colspan="5">records not found</td>
                            </tr>
                            @endif                            
                        </tbody>
                    </table>										
                </div>
                
                <div class="card-footer clearfix">
                    {{-- <ul class="pagination pagination m-0 float-right">
                      <li class="page-item"><a class="page-link" href="#">«</a></li>
                      <li class="page-item"><a class="page-link" href="#">1</a></li>
                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                      <li class="page-item"><a class="page-link" href="#">»</a></li>
                    </ul> --}}
                </div>
            </div>
        </div>
        <!-- /.card -->
    </section>
</div>
</div>
<link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.css">
<script src="https://unpkg.com/tableexport.jquery.plugin@1.10.1/tableExport.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/bootstrap-table.min.js"></script>
<script src="https://unpkg.com/bootstrap-table@1.13.5/dist/extensions/export/bootstrap-table-export.min.js"></script>
<link rel="stylesheet" href="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
<script src="/assets/bootstrap-admin-new/plugins/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="/assets/bootstrap-admin-new/plugins/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>

@endsection

@section('customJs')

@endsection
