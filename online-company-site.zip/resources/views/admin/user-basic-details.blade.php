<section class="" id="section1">

  <form method="post" enctype='multipart/form-data'>
    @csrf
    <h1>User Basic Details</h1>
    @foreach($userBasicDetails as $user_details)
    <div class="nice-form-group">
      <input type="hidden" id="" value="{{$user_details['lead_id']}}" name="lead_id" value="" required>
      <label>Name</label>
      <input type="text" value="{{$user_details['user_name']}}" id="user_name" name="user_name" placeholder="Your name" />
      @error('user_name')
      <div class="text-danger">{{$message}}</div>
      @enderror
      @if(session()->get('error'))
      <div class="text-danger">{{ session()->get('error')}}</div>
      @endif
    </div>
    <div class="nice-form-group">
      <label>Phone No.</label>
      <input type="text" id="" name="" value="{{$user_details['user_contact_number']}}" placeholder="" disabled />
    </div>

    <div class="nice-form-group">
      <label>Email</label>
      <input type="email" value="{{$user_details['user_email']}}" id="user_email" name="user_email" placeholder="joe@example.com" />
      @error('user_email')
      <div class="text-danger">{{$message}}</div>
      @enderror
      @if(session()->get('error'))
      <div class="text-danger">{{ session()->get('error')}}</div>
      @endif
    </div>
   
    <div class="nice-form-group " id="mcqForm">
      <h1>What Sevices are you Looking for ?</h1>
      @foreach ($allservices as $service)
        <div>
            <input type="checkbox" name="services[]" value="{{ $service['service_id'] }}"
                {{ in_array($service['service_id'], $userBasicDetails[0]['service_ids']) ? 'checked' : '' }}>
            <label>{{ $service['service_name'] }}</label>
        </div>
    @endforeach
      <!-- @foreach($allservices as $key => $service)

      <label>
        <input type="checkbox" name="service_required[]" value="{{$service['service_id']}}" >{{$service['service_name']}}
      </label>

      @endforeach -->
      
    </div>
    @endforeach

    {{-- <button type="submit" class="offset-5 btn btn">Submit</button> --}}


  </form>
</section>