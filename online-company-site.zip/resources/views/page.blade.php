<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Post Details</title>
    <style>
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-control,
        .form-control-file,
        .form-control:focus {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            outline: none;
        }

        .form-control-file {
            padding: 5px;
        }

        .btn {
            display: block;
            width: 10%;
            padding: 10px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #007bff;
            margin-bottom: 10px;
        }

        .btn-primary:hover,
        .btn-success:hover {
            background-color: #0056b3;
        }

        .btn-success {
            margin-top: 20px;
        }

        #keywordsList {
            margin-top: 10px;
        }

        #keywordsList div {
            display: flex;
            align-items: center;
            margin-bottom: 5px;
        }

        #keywordsList input {
            flex: 1;
            margin-right: 10px;
        }

        #keywordsList button {
            padding: 5px 10px;
            background-color: #dc3545;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        #keywordsList button:hover {
            background-color: #c82333;
        }

        .form-inline {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .form-inline .form-group {
            width: 48%;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Add Post Details</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="form-inline">
            <div class="form-group">
                <label for="title">Post Title/Heading</label>
                <input type="text" class="form-control" id="title" name="title" placeholder="Enter Post Title/Heading" required>
            </div>
            <div class="form-group">
                <label for="url">Post URL (Auto Generated and Editable)</label>
                <input type="text" class="form-control" id="url" name="url" placeholder="Post URL Auto Generated and Editable">
            </div>
        </div>

        <div class="form-group">
            <label for="short_info">Post Short Information</label>
            <textarea type="text" class="form-control" id="short_info" name="short_info" placeholder="Enter Post Short Information" required></textarea>
        </div>

        <div class="form-inline">
            <div class="form-group">
                <label for="post_type">Post Type</label>
                <select class="form-control" id="post_type" name="post_type">
                    <option value="blog">Blog</option>
                    <option value="news">News</option>
                    <option value="article">Article</option>
                </select>
            </div>
            <div class="form-group">
                <label for="seo_title">Post SEO Title</label>
                <input type="text" class="form-control" id="seo_title" name="seo_title" placeholder="Enter Post SEO Title">
            </div>
        </div>

        <div class="form-inline">
            <div class="form-group">
                <label for="seo_description">Post SEO Description</label>
                <input type="text" class="form-control" id="seo_description" name="seo_description" placeholder="Enter Post SEO Description">
            </div>
            <div class="form-group">
                <label for="seo_image">Post SEO Image</label>
                <input type="file" class="form-control-file" id="seo_image" name="seo_image">
            </div>
        </div>

        <div class="form-inline">
            {{-- <td><label for="seo_keywords">SEO Keywords</label></td> --}}
            <td>
                <div id="seo-keywords-container">
                    <div class="form-group row">
                        <div class="col-md-">
                            <div class="mb-3">
                                <label for="seo_keywords">SEO Keywords</label>
                                <input type="text" name="seo_keywords[]" class="form-control" placeholder="Enter SEO Keyword">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button type="button" class="btn btn-success add-keyword">+</button>
                        </div>
                    </div>
                </div>
            </td>
      

        <div id="keywordsList"></div>

        <div class="form-group">
            <label for="featured_image">Featured Image</label>
            <input type="file" class="form-control-file" id="featured_image" name="featured_image">
        </div>
        </div>

        <button type="submit" class="btn btn-success">ADD Post</button>
    </form>
</div>
<script>
    document.getElementById('title').addEventListener('input', function() {
        let title = this.value.trim().toLowerCase();
        let urlField = document.getElementById('url');
        // Replace spaces with dashes
        let slug = title.replace(/\s+/g, '-');
        urlField.value = slug;
    });
    </script>
    
<script>
document.addEventListener("DOMContentLoaded", function() {
    const keywordsContainer = document.getElementById("seo-keywords-container");
    const addButton = document.querySelector(".add-keyword");

    addButton.addEventListener("click", function() {
        const newKeywordField = document.createElement("div");
        newKeywordField.classList.add("col-md-6", "mb-3");
        newKeywordField.innerHTML = `
            <div class="input-group">
                <input type="text" name="seo_keywords[]" class="form-control" placeholder="Enter SEO Keyword">
                <div class="input-group-append">
                    <button type="button" class="btn btn-danger remove-keyword">-</button>
                </div>
            </div>
        `;
        keywordsContainer.appendChild(newKeywordField);

        // Add event listener to remove keyword button
        const removeButton = newKeywordField.querySelector(".remove-keyword");
        removeButton.addEventListener("click", function() {
            newKeywordField.remove();
        });
    });
});
</script>
</body>
</html>
