<!DOCTYPE html>


<html lang="en" class="light-style layout-menu-fixed" dir="ltr" data-theme="theme-default"
    data-assets-path="/theme/assets/" data-template="vertical-menu-template-free">

<head>
    <meta charset="utf-8" />
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>FinCrif: Instant personal loan Approval & disbursal in 1 hrs.</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/theme/assets/img/favicon/favicon.jpeg" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet" />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="/theme/assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="/theme/assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="/theme/assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="/theme/assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="/theme/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <link rel="stylesheet" href="/theme/assets/vendor/libs/apex-charts/apex-charts.css" />

    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="/theme/assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="/theme/assets/js/config.js"></script>

    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-NM2GJPPB18"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-NM2GJPPB18');
</script>
</head>

<body>
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->

            <?php if(session('user_id')) { ?>

              @include('snippet.side-bar.user')
          <?php } else {?>
            @include('snippet.side-bar.freshuser')
    
            <?php } ?>
    
          
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->



                






                <!-- / Navbar -->

                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->

                    <div class="container-xxl flex-grow-1 container-p-y">

                        <div class="mt-4" role="alert">
                            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Apply Online For Personal
                                    Loan</span>
                                Get Disbursal in 24 Hrs*</h4>
                           
                        </div>

                        <!-- Basic Layout & Basic with Icons -->
                        <div class="row">
                            <!-- Registration Form -->
                            <div class="col-xxl">
                                <div class="card mb-4">
                                    <div class="card-header d-flex align-items-center justify-content-between">
                                        <h5 class="mb-0">Sign Up</h5>
                                        <small class="text-muted float-end">SignUp for Process the Loan</small>
                                    </div>

                                    <div class="card-body">
                                        <form method="post" action="/register" id="registerForm">
                                            @csrf
                                            <input type="hidden" value="login" name="action">                                           
                                            <div class="row mb-3">
                                                <label class="col-sm-3 col-form-label" for="basic-default-phone">Phone
                                                    No</label>
                                                <div class="col-7">
                                                    <input title="verify contact number before submit" type="text"
                                                        id="basic-default-phone" name="user_contact_number"
                                                        pattern="[6-9]{1}[0-9]{9}" class="form-control phone-mask"
                                                        placeholder="658 799 8941" aria-label="658 799 8941"
                                                        aria-describedby="basic-default-phone" required />
                                                    <small class="text-warning" id="verifyDone">OTP Verification required</small>
                                                </div>
                                                <div class="col-2"><button class="btn btn-primary btn-sm mt-1"
                                                        onClick="verifyContactNo()" type="button"
                                                        id="verifyButton">Verify</button></div>

                                            </div>
                                            <input type="hidden" id="otp_verify_flag" name="otp_verify_flag" value="N">
                                            
                                           
                                            
                                            
                                            
                                            <div class="row justify-content-end">
                                                <div class="col-sm-7" id="submit-space">
                                                   
                                                </div>
                                            </div>
                                            <p id="register-message"></p>

                                            <div id="confirmMessage" class="mt-4">

                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- Basic with Icons -->
                            <div class="col-xxl">
                                
                                <div class=" flex-wrap" id="icons-container">
                                    <div class="card icon-card cursor-pointer text-center mb-2 mx-1">
                                        <div class="card-body">
                                            <p class="icon-name text-capitalize text-truncate mb-0">Lower Interest Rate
                                            </p>
                                        </div>
                                    </div>
                                    <div class="card icon-card cursor-pointer text-center mb-2 mx-1">
                                        <div class="card-body">

                                            <p class="icon-name text-capitalize text-truncate mb-0">100% Online Process
                                            </p>
                                        </div>
                                    </div>
                                    <div class="card icon-card cursor-pointer text-center mb-2 mx-1">
                                        <div class="card-body">

                                            <p class="icon-name text-capitalize text-truncate mb-0">Flexible EMI </p>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- / Content -->

                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div
                            class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
                            <div class="mb-2 mb-md-0">
                                ©
                                <script>
                                    document.write(new Date().getFullYear());
                                </script>
                                , made with ❤️ by
                                <a href="www.fincrif.com" target="_blank"
                                    class="footer-link fw-bolder">www.fincrif.com</a>
                            </div>
                            <div>
                                <a href="https://www.fincrif.com" class="footer-link me-4" target="_blank">T&C</a>
                                <a href="https://www.fincrif.com" target="_blank" class="footer-link me-4">Offers
                                    Available here</a>

                                <a href="https://www.fincrif.com " target="_blank" class="footer-link me-4">Other
                                    Loans</a>

                                <a href="https://www.fincrif.com " target="_blank"
                                    class="footer-link me-4">Support</a>
                            </div>
                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->


    {{-- Alert --}}

    <div class="col-lg-3 col-md-6">
        <small class="text-light fw-semibold mb-3">Bottom</small>
        <div class="mt-3">

            <div class="offcanvas offcanvas-bottom" tabindex="-1" id="offcanvasBottom"
                aria-labelledby="offcanvasBottomLabel">
                <div class="offcanvas-header">
                    <h5 id="offcanvasBottomLabel" class="offcanvas-title">Access Denied</h5>
                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"
                        aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <p>
                        Please Login/Register to complete loan process and make status active to view.
                    </p>
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="offcanvas">
                        Cancel
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Default Modal -->
    <div class="col-lg-4 col-md-6">
      <div class="mt-3">
          <!-- Button trigger modal -->


          <!-- Modal -->
          <div class="modal fade" id="resetPasswordModal"
              tabindex="-1" aria-hidden="true">
              <div class="modal-dialog" role="document">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h5 class="modal-title"
                              id="exampleModalLabel1">Reset Password
                          </h5>
                          <button type="button" class="btn-close"
                              data-bs-dismiss="modal"
                              aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                          <div class="row">
                              <div class="col mb-3">
                                  <label for="nameBasic"
                                      class="form-label">Contact
                                      Number</label>
                                  <input
                                      title="verify contact number before submit"
                                      type="text"
                                      id="password-reset-phone"
                                      name="user_contact_number"
                                      pattern="[6-9]{1}[0-9]{9}"
                                      class="form-control phone-mask"
                                      placeholder="658 799 8941"
                                      aria-label="658 799 8941"
                                      aria-describedby="password-reset-phone"
                                      required />
                              </div>
                          </div>

                      </div>
                      <div class="modal-footer">
                          <button type="button"
                              class="btn btn-outline-secondary"
                              data-bs-dismiss="modal">
                              Cancel
                          </button>
                          <button class="btn btn-primary mt-1"
                              onClick="resetPassVerifyContactNo()"
                              type="button"
                              id="resetPasswordButton">GET
                              OTP</button>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>

  <!-- Input Password Modal -->
  <div class="col-lg-4 col-md-6">
      <div class="mt-3">
          <!-- Button trigger modal -->


          <!-- Modal -->
          <div class="modal fade" id="updatePasswordModal"
              tabindex="-1" aria-hidden="true">
              <div class="modal-dialog" role="document">
                  <div class="modal-content">
                      <div class="modal-header">
                          <h5 class="modal-title"
                              id="exampleModalLabel1">Reset Password
                          </h5>
                          <button type="button" class="btn-close"
                              data-bs-dismiss="modal"
                              aria-label="Close"></button>
                      </div>
                      <div class="modal-body">
                          <div class="row">
                              <div class="col mb-3">
                                  <label for="nameBasic"
                                      class="form-label">Enter New
                                      Password</label>
                                  <input type="password"
                                      name="user_password"
                                      class="form-control"
                                      id="user_password_reset"
                                      placeholder="**********"
                                      required />
                              </div>
                          </div>

                      </div>
                      <div class="modal-footer">
                          <button type="button"
                              class="btn btn-outline-secondary"
                              data-bs-dismiss="modal">
                              Cancel
                          </button>
                          <button class="btn btn-primary mt-1"
                              onClick="updatePassword()"
                              type="button"
                              id="updateButton">Submit</button>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>


    {{--  --}}
    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="/theme/assets/vendor/libs/jquery/jquery.js"></script>
    <script src="/theme/assets/vendor/libs/popper/popper.js"></script>
    <script src="/theme/assets/vendor/js/bootstrap.js"></script>
    <script src="/theme/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="/theme/assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="/theme/assets/js/main.js"></script>

    <!-- Page JS -->


    <!-- Sweetalert links -->
    <script src="{{ url('') }}/assets/production/library/sweetalert/dist/sweetalert.js" async></script>
    <link rel="stylesheet" href="{{ url('') }}/assets/production/library/sweetalert/dist/sweetalert.css">

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>


    <script type="text/javascript">
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>

    <script>
        function checkPass() {


            var pass1 = document.getElementById('user_password');
            var pass2 = document.getElementById('user_password_cnf');
            var message = document.getElementById('confirmMessage');
            var goodColor = "#66cc66";
            var badColor = "#ff6666";

            if (pass1.value == pass2.value) {


                message.style.color = goodColor;
                message.innerHTML = "Passwords Match!"
                $('#signUpMainBtn').removeClass('disabled');
            } else {

                message.style.color = badColor;
                message.innerHTML = "Passwords Do Not Match!"
                $('#signUpMainBtn').addClass('disabled');

            }
        }


        function globalLogout() {

            $(document).click();

            // Get the page name where user logout
            swal({
                    title: "Log Out",
                    text: "Are you sure want to log-off?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonClass: "btn-danger",
                    confirmButtonText: "Log Out",
                    closeOnConfirm: false
                },
                function() {
                    window.location = "{{ url('') }}/user-logout";
                });



        }

        function resetPassVerifyContactNo() {

            contactNo = $('#password-reset-phone').val();

            if (contactNo == '') {
                return false;

            }

            $.ajax({
                    url: '/otp-verify',
                    type: "post",
                    cache: false,

                    data: {
                        contactNo: contactNo,
                        action: 'generate-otp'
                    }

                })
                .done(function(e) {

                    responseData = JSON.parse(e);
                    if (responseData.status == 'success') {

                        $('#resetPasswordModal').modal('toggle')

                        swal({
                            title: "Phone OTP",
                            text: "Check your phone for OTP",
                            type: "input",
                            showCancelButton: true,
                            closeOnConfirm: false,
                            inputPlaceholder: "OTP",
                            confirmButtonText: "Submit"
                        }, function(inputValue) {
                            if (inputValue === false) return false;
                            if (inputValue === "") {
                                swal.showInputError("Enter OTP");
                                return false
                            }

                            // verify ajax
                            $.ajax({
                                url: "/otp-verify",
                                method: "post",
                                data: {
                                    contactNo: contactNo,
                                    action: 'otp-verify',
                                    otp: inputValue
                                },
                                success: function(data) {
                                    dataArray = JSON.parse(data);
                                    console.log(dataArray.status);
                                    if (dataArray.status == 'success') {

                                        $('#updatePasswordModal').modal('show')


                                        swal.close();

                                    } else {

                                        alert('wrong otp');
                                    }
                                },
                                error: function(xhr) {
                                    console.log('error in verify');
                                    return false;
                                }
                            });


                        });


                    } else {


                        alert(dataArray.message);

                    }


                });

        }


        function verifyContactNo() {

            contactNo = $('#basic-default-phone').val();

            if (contactNo == '') {
                return false;

            }

            $.ajax({
                    url: '/otp-verify',
                    type: "post",
                    cache: false,

                    data: {
                        contactNo: contactNo,
                        action: 'generate-otp'
                    }

                })
                .done(function(e) {

                    responseData = JSON.parse(e);
                    if (responseData.status == 'success') {



                        swal({
                            title: "Phone OTP",
                            text: "Check your phone for OTP",
                            type: "input",
                            showCancelButton: true,
                            closeOnConfirm: false,
                            inputPlaceholder: "OTP",
                            confirmButtonText: "Submit"
                        }, function(inputValue) {
                            if (inputValue === false) return false;
                            if (inputValue === "") {
                                swal.showInputError("Enter OTP");
                                return false
                            }

                            // verify ajax
                            $.ajax({
                                url: "/otp-verify",
                                method: "post",
                                data: {
                                    contactNo: contactNo,
                                    action: 'otp-verify',
                                    otp: inputValue
                                },
                                success: function(data) {
                                    dataArray = JSON.parse(data);
                                    console.log(dataArray.status);
                                    if (dataArray.status == 'success') {

                                        $('#basic-default-phone').prop('readonly', true);
                                        $('#verifyButton').attr('disabled', true);
                                        $('#signUpMainBtn').removeClass('disabled');
                                        $('#verifyDone').removeClass('text-warning');
                                        $('#verifyDone').addClass('text-success');
                                        $('#verifyDone').text('verified');
                                        $('#otp_verify_flag').val('Y');
                                        $('#submit-space').html("<button type='submit' id='signUpMainBtn' class='d-none btn btn-primary disabled'>SUBMIT</button>");
                                        $('#signUpMainBtn').click();
                                        swal.close();

                                    } else {
                                        $('#basic-default-phone').prop('readonly', false);
                                        $('#verifyButton').attr('disabled', false);
                                        $('#signUpMainBtn').addClass('disabled');
                                        alert('wrong otp');
                                    }
                                },
                                error: function(xhr) {
                                    console.log('error in verify');
                                    return false;
                                }
                            });


                        });


                    } else {


                        alert(dataArray.message);

                    }


                });



        }



        function updatePassword() {
          newPass = $('#user_password_reset').val();

if (newPass == '') {
    return false;

}

$.ajax({
                    url: '/reset-password',
                    type: "post",
                    cache: false,

                    data: {
                        contactNo: contactNo,
                        action: 'update_password',
                        newPass: newPass
                    }

                })
                .done(function(e) {

                    responseData = JSON.parse(e);
                    if (responseData.status == 'success') {

                      $('#updatePasswordModal').modal('toggle')
                        

                      swal("Successfully Updated");


                    } else {


                        alert(dataArray.message);

                    }


                });



        }
    </script>
</body>
</body>

</html>
