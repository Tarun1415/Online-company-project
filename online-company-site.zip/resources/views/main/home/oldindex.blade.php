{{-- 
@extends('layouts.default-new')
@section('content')


@include('includes.header-new')


@include('home-sections.banner')

<main id="main">
 
  @include('home-sections.featured-services')

  <!-- ======= About Section ======= -->
 
  @include('home-sections.features')

  @include('home-sections.clients-logo-slider')

  @include('home-sections.cta')

  @include('home-sections.onfocus')

  @include('home-sections.services')

  @include('home-sections.faq')

  @include('home-sections.recent-blog-posts')

  @include('home-sections.contact-modal')


  </main><!-- End #main -->


  @stop --}}

 