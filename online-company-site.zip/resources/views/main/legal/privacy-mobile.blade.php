@extends('layouts.default-new')
@section('content')

    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">

            <?php if(session('user_id')) { ?>

            @include('snippet.side-bar.user')
            <?php } else {?>
            @include('snippet.side-bar.freshuser')

            <?php } ?>

            <div class="layout-page">
                <!-- Navbar -->

                {{-- <nav
              class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
              id="layout-navbar"
              style="z-index:0;"
             >
              <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
                <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                  <i class="bx bx-menu bx-sm"></i>
                </a>
              </div>
  
              <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                <!-- Search -->
                
  
                <!-- /Search -->
  
               
             </div>
          </nav> --}}
                <!-- / Navbar -->
                <!-- body carausel-->
                <div class="container">
                    <a href="/" class="small">Home</a>
                    <center>
                        <h1 class="h4 title mt-2">Privacy Policy</h1>
                    </center>
                    <p class="text">
                        FinCrif India Limited Liability Company. (hereinafter “fincrif.com or we/our, including
                        www.fincrif.com and the fincrif mobile application”) recognizes the importance of privacy.This
                        privacy policy (hereinafter referred to as the “Policy”) therefore explains how we protect the
                        personal data provided to us on our website www.fincrif.com (hereinafter referred to as the “Site”)
                        or via the mobile application and how this information is part of a service offered through the
                        Website (hereinafter referred to as the "Service").fincrif is committed to maintaining the
                        confidentiality, integrity and security of all information from our users.

                    </p>

                    <p class="text">
                        fincrif is an independent professional services provider and is in no way affiliated with any
                        government or governmental agency, regulator or credit reporting agency. The information contained
                        on this website does not guarantee the correctness of the content, details and calculations.
                        Information is subject to change without notice.


                    </p>

                    <p class="text">
                        This notice has been issued and is to be construed in accordance with the provisions of the
                        Information Technology Principles (Reasonable Security Practices and Procedures and Sensitive
                        Personal Information) 2011 under the Information Technology Act 2000 and other applicable laws and
                        regulations requiring disclosure of privacy practices in the collection, use, retention, disclosure
                        and transmission of sensitive personal data or information.

                    </p>

                    <p class="text">
                        This policy does not apply to the practices of companies that fincrif.com does not own or control or
                        to people that fincrif.com does not employ or manage.

                    </p>


                    <p class="text">
                        Please see below for details on what type of information we may collect from you, how that
                        information is used in connection with the Services offered through our Site and other shared with
                        our business partners. This Privacy Policy applies to current and former visitors to our Site and to
                        our online customers.By visiting and/or using our website, you agree to this privacy policy, to
                        allow our partner banks/NBFCs and advertisers to call/text/email you, offer you their services in
                        the area of ​​the product you have chosen, provide information about products, offer promotions on
                        Offers & related offers from third parties; when you subscribe to the DND (Do Not Disturb) or DNC
                        (Do Not Call ) service, You authorize us to receive your call/text/email on fincrif.com & Partnering
                        with banks/NBFCs and advertisers for the above purposes even if you have selected the DND or DNC
                        option. Persons who store personal data: Your personal data is stored and collected by fincrif.com
                        or via mobile application with parent company fincrif India Private Limited which owns fincrif.com.
                        Some features of this website or our services require the provision of personal information, which
                        is provided in the "Your Account" section of our website.

                    </p>

                    <h2 class="h6">
                        Use of Information

                    </h2>

                    <p class="text">
                        fincrif collects your information when you register for an account, when you use its products or
                        services, visit its Website’s pages. When you register with the Website and sign in you are not
                        anonymous to us. Also, you are asked for your contact number and other details during registration
                        and may be sent SMS, electronic mails (“e-mails”) , notifications, Whatsapp messages about our
                        services to your wireless device.

                    </p>

                    <p class="text">
                        To establish identity and assess applications; Monitor, improve and administer our Website; Design
                        and offer customized products and services offered by our third party partners, manage our risks
                        including the risk of fraud that may be committed against Us or our partners; Analyze how the
                        Website is used, diagnose service or technical problems and maintain security; Send communications
                        notifications, information regarding the products or services requested by You or process queries
                        and applications that You have made on the Website; Manage Our relationship with You and provide You
                        with or inform You about other products or services We think you might find of some use; Conduct
                        data analysis in order to improve the Services provided to the User; Use the User information in
                        order to comply with country laws and regulations; To conduct KYC for our third party partners based
                        on the information shared by the User for the provision of Services. This would include conducting
                        analysis of Your bank statements and eKYC.fincrif can perform KYC directly or through third parties
                        with its customers. In the event that the KYC as described in this clause is performed by third
                        parties, fincrif will share your relevant information with those third parties in order to use those
                        services; We may also use other technologies to track how you interact with the Site and engage
                        certain third party agencies to use the data on our behalf to analyze data to determine how you use
                        the site.
                    </p>

                    <h2 class="h6">
                        Collection of Information
                    </h2>

                    <h6>
                        Personal Information

                    </h6>

                    <p class="text">
                        When you use the Website or Mobile App to apply for a loan, we collect information about you that
                        can be used to uniquely identify or contact you, such as: B. But not limited to: Name, City,
                        Address, Date, Birth Certificate, Aadhar Information (optional), Contact Information, Billing
                        Information, Marital Status, PAN Number, Name of Bank where you have your main account, Bank
                        Statements, Payslips, Income information and expenses obtained through bank SMS scraping and
                        integration with our service provider, other KYC documents, etc.; Your employment details, including
                        years of experience, income details, name of your current employer, office address, details of the
                        years/months you worked at your current employer; Information about your tax return; Credit
                        information collected from other sources such as the Equifax credit reporting agency; transaction
                        history information, such as B. Expense data, call history, contact list and other related
                        information through our mobile application; Your unique identifiers such as username and password,
                        preference information and transaction history; personal identification numbers, passcode numbers,
                        bank account numbers, time zone, zip code, country, state, city, email address, date of birth and
                        gender, and other similar electronic data.

                    </p>


                    <h6>Non Personal Information
                    </h6>
                    <p class="text">
                        We collect information such as internet domain and host names, internet protocol (IP) addresses,
                        browser software, operating system types, click patterns, and the date and time you access the
                        website. (Uses – marketing, remarketing, web analytics to improve customer experience, as well as
                        advertising
                        social media data
                        information collected via Facebook, Twitter, Linkedin or other social accounts from users who have
                        logged into the account on the website and/ or in the App We may receive your Personal Information
                        from those social media sites/apps in accordance with the privacy policies of those sites/apps App
                        to your username,
                        profile picture, email address associated with that particular website/app Address, any information
                        you have published in connection with this website/application and/or any information or content
                        that is the social media website/application may be restricted by accessing or connecting to the
                        website via a Social media website/application, you authorize us to collect, store, use and archive
                        such information and content in accordance with this policy.

                    </p>


                    <h6>RETENTION OF YOUR DATA:
                    </h6>
                    <p class="text">
                        fincrif.com will retain your information for as long as necessary to provide the services available
                        through the website/mobile application or your request to delete your fincrif.com account, whichever
                        is later. After closing your account, fincrif.com may continue to use your anonymized data in
                        aggregate form or in combination with other users' anonymized data.We use this aggregated anonymous
                        data for data analysis, profiling and research purposes, for example to better understand our users
                        and their profiles. We may store your contact details and complaints details (if applicable) for the
                        purpose of fraud prevention and to exercise/defend legal claims or to provide evidence in connection
                        with a legal proceeding.

                    </p>


                    <h2 class="h6">
                        Compensation Officer
                    </h2>
                    <h6>
                        Updates to this Policy

                    </h6>

                    <p class="text">
                        This Privacy Policy was last updated on 4/14/2023.We may change our privacy practices from time to
                        time. We will notify you of any material changes to this policy as required by law. We will also
                        post an updated copy on our website. Please check our website regularly for updates.

                    </p>


                </div>


            </div>


        </div>

    </div>

    @include('snippet.loginmodal')

@stop
