<div class="demo-page-navigation" id="nav-page">

  <nav>

    <ul>
      <div class="photo-upload-section">
        <div class="photo-upload">
          <!-- <label for=""> -->
            <?php if ('lead_id') { ?>

              <img src="{{ $profileImgUrl }}" onerror="this.onerror=null;this.src='/assets/img/avatars/default-user.png';" class="image-profile" />
            <?php
            } ?>
          <!-- </label> -->

          <div class="photo-preview"></div>
        </div>
      </div>

      <li>

        <a href="/admin/user/{{$lead_id}}" class="basic-detail" data-section="1">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layers">
            <polygon points="12 2 2 7 12 12 22 7 12 2" />
            <polyline points="2 17 12 22 22 17" />
            <polyline points="2 12 12 17 22 12" />
          </svg>
          Basic Details
        </a>
      </li>
      <li>
        <a href="/admin/user-document/{{$lead_id}}" class="basic-detail" data-section="2">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-feather">
            <path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z" />
            <line x1="16" y1="8" x2="2" y2="22" />
            <line x1="17.5" y1="15" x2="9" y2="15" />
          </svg>
          Document Upload
        </a>
      </li>

    </ul>
  </nav>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>