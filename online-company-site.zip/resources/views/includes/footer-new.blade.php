@include('home-sections.contact-modal')
<!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> -->
<!-- ======= Footer ======= -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<footer id="footer" class="footer">
  <div class="footer-content">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-6">
          <div class="footer-info">
            <h3>Online Company</h3>
            <p>
              279-280 First Floor, <br>
              Block-40, Sky Tower, <br>
              Sanjay Place, Agra-282002<br><br>
              <strong>Phone:</strong> +91 9557 758 422<br>
              <strong>Email:</strong> info@onlinecompany.co.in<br>
            </p>
          </div>
        </div>
        <div class="col-lg-2 col-md-6 footer-links">
          <h4>Useful Links</h4>
          <ul>
            <li><i class="bi bi-chevron-right"></i> <a href="/">Home</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="/about">About us</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="/contact">Contact</a></li>
            <li><i class="bi bi-chevron-right"></i> <a href="/privacy-policy">Privacy policy</a></li>
          </ul>
        </div>
        <div class="col-lg-3 col-md-6 footer-links">
          <h4>Our Services</h4>
          <ul>
            <div id="faqlist1">
              @if (getservice()->isNotEmpty())
                @foreach (getservice() as $category)
                  <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
                    <h2 class="accordion-header">
                      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-{{ $category->id }}">
                        <i class="bi bi-chevron-right"></i>
                        {{ $category->name }}
                      </button>
                    </h2>
                    <div id="faq-content-{{ $category->id }}" class="accordion-collapse collapse" data-bs-parent="#faqlist1">
                      <div class="accordion-body">
                        @if ($category->sub_service->isNotEmpty())
                          @foreach ($category->sub_service as $subcategory)
                            <a href="{{ route('front.user', [$subcategory->slug]) }}" class="link_text">{{ $subcategory->name }}</a><br>
                          @endforeach
                        @endif
                      </div>
                    </div>
                  </div>
                @endforeach
              @endif
            </div>
          </ul>
        </div>
        <div class="col-lg-4 col-md-6 footer-newsletter">
          <h4>Our Newsletter</h4>
          <p>Subscribe to get notification</p>
          <form method="post" action="/subscriber" enctype='multipart/form-data'>
            @csrf
            <input type="email" name="email">
            <input type="submit" value="Subscribe">
          </form>
        </div>
      </div>
    </div>
  </div>
  <div class="footer-legal text-center">
    <div class="container d-flex flex-column flex-lg-row justify-content-center justify-content-lg-between align-items-center">
      <div class="d-flex flex-column align-items-center align-items-lg-start">
        <div class="copyright">
          &copy; Copyright <strong><span>Online Company</span></strong>. All Rights Reserved
        </div>
      </div>
      <div class="social-links order-first order-lg-last mb-3 mb-lg-0">
        <a href="https://twitter.com/OnlineCompany07" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="https://www.facebook.com/OnlineCompany.co.in" class="facebook"><i class="bi bi-facebook"></i></a>
        <a class="" href="https://wa.me/7060055045"><i class="bi bi-whatsapp"></i></a>
        <a href="https://in.linkedin.com/in/online-company-704875111" class="linkedin"><i class="bi bi-linkedin"></i></a>
      </div>
    </div>
  </div>
</footer><!-- End Footer -->
<a href="#" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
<div id="preloader"></div>

<!-- Vendor JS Files -->
<script src="/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="/assets/vendor/aos/aos.js"></script>
<script src="/assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="/assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="/assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="/assets/js/main.js"></script>

<script>
  function globalLogout() {
    $(document).click();
    // Get the page name where user logout
    swal({
        title: "Log Out",
        text: "Are you sure want to log-off?",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Log Out",
        closeOnConfirm: false
      },
      function() {
        window.location = "{{url('')}}/user-logout";
      });
  }
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl)
  });
</script>
