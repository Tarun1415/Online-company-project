
   <!-- ======= Header ======= -->
   <header id="header" class="header relative-top" data-scrollto-offset="0">
    <div class="container-fluid d-flex align-items-center justify-content-between">

      <a href="/" class="logo d-flex align-items-center scrollto me-auto me-lg-0">
        <!-- Uncomment the line below if you also wish to use an image logo -->
        <img src="/assets/img/logOCfinal1.svg" alt="">
        <!--<h1>Online<span>.</span></h1>-->
      </a>

      <!-- <nav id="navbar" class="navbar">
        <ul>
          <li class="nav-link"><a href="#"><span>Home</span></a>
            <li class="nav-link"><a href="#"><span>About Us</span></a>

            <li class="dropdown megamenu"><a href="#"><span>Our Services</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
              <ul>
                
                <li>
                  <a href="#"  data-bs-toggle="modal" data-bs-target="#exampleModalCenter">GST</a>
                  <a href="#"  data-bs-toggle="modal" data-bs-target="#exampleModalCenter">Trademark</a>
                  <a href="#"  data-bs-toggle="modal" data-bs-target="#exampleModalCenter">Compliance</a>
                  
                </li>
                <li>
                  <a href="#"  data-bs-toggle="modal" data-bs-target="#exampleModalCenter">ESI-PF REGISTRATION</a>
                  <a href="#"  data-bs-toggle="modal" data-bs-target="#exampleModalCenter">Public Limited Company</a>
                  <a href="#"  data-bs-toggle="modal" data-bs-target="#exampleModalCenter">Registaration Services</a>
                </li>
              </ul>
            </li>
            <li><a class="" href="#">Blog</a></li>
            <li><a class="" href="#">Shop</a></li>

            <li><a class="nav-link scrollto" href="/#">Contact Us</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle d-none"></i>
      </nav>.navbar -->

      
    </div>
  </header><!-- End Header -->




