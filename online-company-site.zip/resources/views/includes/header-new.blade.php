<!-- ======= Header ======= -->
<header id="header" class="header sticky-top relative-top" data-scrollto-offset="0">
  <style>
    /* Custom CSS for dropdown alignment and styling */
.navbar .dropdown .megamenu {
  position: absolute;
  left: 0;
  right: 0;
  width: 100%;
  padding: 15px 0;
  background: #fff;
  border-top: 3px solid #5cb874;
  display: none;
  z-index: 99;
  max-height: 400px; /* Adjust the max-height as needed */
  overflow-y: auto; /* Enable vertical scrolling if content exceeds max-height */
}

.navbar .dropdown:hover .megamenu {
  display: block;
}

.navbar .megamenu ul {
  display: flex;
  flex-wrap: wrap;
  padding: 0;              
  margin: 0;
}
                                                           
.navbar .megamenu ul li {
  list-style: none;
  padding: 10px 0;
  width: 50%; /* Adjust width to ensure proper alignment */
}

.navbar .megamenu ul li a.head_color {
  font-weight: bold;
  color:  #d1b30b;
  display: block;
  padding: 5px 10px;
}
   
.navbar .megamenu ul li a.link_text {
  color: #eb1515;
  display: block;
  padding: 8px 10px;
}

.navbar .megamenu ul li a.link_text:hover {
  text-decoration: underline;
}

.navbar .dropdown .dropdown-indicator {
  margin-left: 5px;
}

/* Additional media query for smaller screens */
@media (max-width: 768px) {
  .navbar .megamenu ul li {
    width: 50%; /* Adjust width for smaller screens */
  }
}
                                                                                    
  </style>                                                                         
  <div class="container-fluid d-flex align-items-center justify-content-between">

    <a href="/" class="logo d-flex align-items-center scrollto me-auto me-lg-0">
      <!-- Uncomment the line below if you also wish to use an image logo -->
      <img src="/assets/img/logOCfinal1.svg" alt="">
      <!--<h1>Online<span>.</span></h1>-->
    </a>
    
    <nav id="navbar" class="navbar">
      <ul>
        <li class="nav-link"><a href="/"><span>Home</span></a>
        <li class="nav-link"><a href="/about"><span>About Us</span></a>
        <li class="dropdown megamenu"><a href="#"><span>Our Services</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
          <ul>
            @if (getservice()->isNotEmpty())
              @foreach (getservice() as $category)
              <li>
                <a class="head_color" href="#">{{ $category->name }}</a>
                @if ($category->sub_service->isNotEmpty())
                  @foreach ($category->sub_service as $subcategory)
                    <a href="{{ route('front.user', [$subcategory->slug]) }}" class="link_text">{{ $subcategory->name }}</a>
                  @endforeach
                @endif
              </li>
              @endforeach                                                                                                                                          
            @endif                                                                     
          </ul>                                         
        </li>
                                                                     
       <li><a class="nav-link" href="/contact">Contact Us</a></li>
       </ul> 
      <i class="bi bi-list d-none mobile-nav-toggle "></i>
    </nav>

    {{-- @if(!session()->has('user_id'))
    <!-- .navbar -->
    <a class="nav-link" href="/signup">
        <div class="btn-getstarted d-sm-inline">
            Sign up
        </div>
    </a> 
@else
    <div class="btn-group dropstart">
        <button type="button" class="bi bi-person btn btn-secondary btn-getstarted" data-bs-toggle="dropdown" aria-expanded="false">
            
        </button>
        <ul class="dropdown-menu">
            <li>
                <a href="/user/basic-details" class="dropdown-item">Profile</a>
            </li>
            <li>
                <form action="{{ route('user.logout') }}" method="POST" id="formlogout" class="m-0 p-0">
                    @csrf
                    <button type="submit" class="btn btn-link dropdown-item m-0 p-0">
                      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout
                    </button>
                </form>
            </li>
        </ul>
    </div>
@endif
<!-- Bootstrap CSS -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap JS and dependencies -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> --}}




    @if(!session()->has('user_id'))
    <!-- .navbar -->
    <a class="nav-link" href="/signup">
        <div class="btn-getstarted d-sm-inline">
            Sign up
        </div>
    </a> 
    @else
    <div class="btn-group dropstart">
      <button type="button" class="bi bi-person btn btn-secondary btn-getstarted" data-bs-toggle="dropdown" aria-expanded="false">
          
      </button>
      <ul class="dropdown-menu">
          <li>
              <a href="/user/basic-details" class="dropdown-item">Profile</a>
          </li>
          <li>
        <form action="{{ route('user.logout') }}" method="post" id="formlogout">
        @csrf
        <button type="submit" class="btn btn-link dropdown-item m-0 p-0">
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Logout
        </button>
    </form>
  </li>
      </ul>
    </div>
    @endif 
    
    
    <!-- .navbar -->
    {{-- <a class="nav-link" href="/signup"><div class="btn-getstarted  d-sm-inline">
      Sign up
    </div></a>  --}}



    
    {{-- @if((session()->has('user_id'))==false)
    <!-- .navbar -->
    <a class="nav-link" href="/signup"><div class="btn-getstarted  d-sm-inline">
      Sign up
    </div></a> 
    @else

    <form action="{{route('user.logout')}}" method="post" id="formlogout">
      @csrf
    <a class="nav-link" onclick="document.getElementById('formlogout').submit()"><div class="btn-getstarted  d-sm-inline">
      Logout
    </div></a> 
    </form>
    @endif --}}





  </div>
</header>
<!-- End Header --> 

































































































































































{{-- <!-- ======= Header ======= -->
<header id="header" class="header sticky-top relative-top" data-scrollto-offset="0">
  <div class="container-fluid d-flex align-items-center justify-content-between">

    <a href="/" class="logo d-flex align-items-center scrollto me-auto me-lg-0">
      <!-- Uncomment the line below if you also wish to use an image logo -->
      <img src="/assets/img/logOCfinal1.svg" alt="">
      <!--<h1>Online<span>.</span></h1>-->
    </a>
    
    <nav id="navbar" class="navbar">
      <ul>
        <li class="nav-link"><a href="/"><span>Home</span></a>
        <li class="nav-link"><a href="/about"><span>About Us</span></a>

        <li class="dropdown megamenu"><a href="#"><span>Our Services</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
          <ul>
 
            <li>
              <a class="head_color" href="gst-taxs">GST</a>
              <a href="/gst-registration" class="link_text">GST Registration</a>
              <a href="/gst-filing" class="link_text">GST Filing</a>
              <a href="/gst-advisory" class="link_text">GST Advisory</a>
              <a href="/tds-return-filing" class="link_text">TDS Return Filing</a>
              <a href="/individual-income-tax-filing" class="link_text">Individual Income Tax Filing </a>
              <a href="/proprietorship-tax-return-filing" class="link_text">Proprietorship Tax Return Filing </a>

              <a class="head_color" href="labour-compliance">Labour Compliance</a>
              <a href="/esi-registration" class="link_text">ESI Registration</a>
              <a href="/provident-fund-registration" class="link_text"> Provident Fund (PF) Registration</a>
              <a href="/professional-tax-registration" class="link_text">Professional Tax Registration</a>
              <a href="/shops-and-establishments-license" class="link_text"> Shops and Establishments License</a>
              <a href="/employees-stock-option-plan" class="link_text">Employee Stock Option Plan [ESOP]  </a>
              <a href="/posh-compliance" class="link_text">POSH Compliance </a>

              
            </li>
 
            <li >
            {{-- <a class="head_color" href="licenses">Licenses & Registrations</a>
              <a href="/digital-signature-certificate" class="link_text">Digital Signature Certificate</a>
              <a href="/msme-ssi-registration" class="link_text"> MSME/SSI Registration</a>
              <a href="/iso-certification" class="link_text">ISO Certification</a>
              <a href="/fssai-registration-online" class="link_text"> FSSAI Registration Online</a>
              <a href="/iec-import-export-code" class="link_text">IEC [Import/Export Code]  </a>
              <a href="/bis-registration" class="link_text"> BIS Registration</a> --}}

              

              {{-- <a class="head_color" href="corporate-compliance">Corporate Compliance</a>
              <a href="/annual-auditing-with-proper-reciept" class="link_text">Annual Auditing - with proper reciept</a>
              <a href="/rbi-compliance" class="link_text">  RBI Compliance</a>
              <a href="/balance-sheet-preparation-and-matching" class="link_text"> Balance Sheet Preparation and matching</a><br><br><br><br>

              
            </li> --}}
{{-- 
            <li >
              <a class="head_color" href="convert-business">Convert Business</a>
              <a href="/proprietorship-to-pvt-ltd-company" class="link_text">Proprietorship to Pvt Ltd Company</a>
              {{-- <a href="/compliance-check-secretarial-audit" class="link_text"> Compliance Check - Secretarial Audit</a> --}}
              {{-- <a href="/partnership-to-llp" class="link_text">Partnership to LLP</a>
              <a href="/private-to-public-limited-company" class="link_text"> Private to Public Limited Company</a>
              <a href="/private-limited-to-one-person-company" class="link_text">Private Limited to One Person Company  </a>

              
              <a class="head_color" href="company-registration">Company Registration</a>
              <a href="/private-limited-company" class="link_text">Private Limited Company</a>
              <a href="/limited-liability-partnership" class="link_text"> Limited Liability Partnership</a>
              <a href="/one-person-company" class="link_text"> One Person Company</a>
              <a href="/sole-proprietorship" class="link_text"> Sole Proprietorship</a>
              <a href="/nidhi-company" class="link_text">Nidhi Company  </a>
              <a href="/producer-company" class="link_text"> Producer Company</a>
              <a href="/partnership-firm" class="link_text"> Partnership Firm</a>
             
            </li> --}} 

            
          {{-- </ul>
        </li>
         --}}


















        {{-- <li class="dropdown megamenu"><a href="#"><span>Our Services2</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
          <ul>
            @if (getservice()->isNotEmpty())
                @foreach (getservice() as $category)
 
            <li>
              <a class="head_color" href="#">{{$category->name}}</a>
              
              @if ($category->sub_service->isNotEmpty())
              @foreach ($category->sub_service as $subcategory)
           

              {{-- <a href="{{url('gstregister',$subcategory->id)}}" class="link_text">{{$subcategory->name}}</a> --}}
              {{-- <a href="{{route('front.user',[$subcategory->slug])}}" class="link_text">{{$subcategory->name}}</a>

              @endforeach      
              @endif

              
            </li>


            @endforeach
            @endif
            
          </ul>
        </li> --}}































       

        {{-- <li><a class="nav-link" href="/contact">Contact Us</a></li>
        {{-- <li><a class="nav-link" href="/contact">Tarun Us</a></li> --}}



      {{-- </ul> --}}

      {{-- <i class="bi bi-list d-none mobile-nav-toggle "></i>
    </nav><!-- .navbar -->
 
    <!-- <a href="/signup" ><span class="p-2 -1 badge badge-pill badge-warning d-md-none" id="singup_btn_m">Sign up</span></a> -->
    <a href="signup"><div class="btn-getstarted d-none d-sm-inline">
      Sign up
    </div></a> --}}

    <!-- <div class="btn-getstarted d-none d-sm-inline" data-bs-toggle="modal" data-bs-target="#exampleModalCenter">
      Sign up
    </div> -->

  {{-- </div>
</header><!-- End Header --> --}} 