<div class="demo-page-navigation">

  <nav>


    <ul>
      <!-- <form id="uploadForm" method="post" enctype="multipart/form-data">
                  @csrf -->
      <div class="photo-upload-section">
        <div class="photo-upload">
          <?php if (session('user_id')) { ?>

            <img src="{{ $profileImgUrl }}" onerror="this.onerror=null;this.src='/assets/img/avatars/default-user.png';" class="image-profile" />
          <?php
          } ?>

          
        </div>
      </div>
      <!-- <button type="submit" class="photo-upload-section offset-5 btn btn">Profile Update</button> -->
      <!-- </form> -->
      <li>

        <a href="basic-details" class="basic-detail" data-section="1">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layers">
            <polygon points="12 2 2 7 12 12 22 7 12 2" />
            <polyline points="2 17 12 22 22 17" />
            <polyline points="2 12 12 17 22 12" />
          </svg>
          Basic Details
        </a>
      </li>
      <li>
      <?php if (!empty($data['service_required'])) { ?>
        <a href="/user/document" class="basic-detail" data-section="2" disabled>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-feather">
            <path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z" />
            <line x1="16" y1="8" x2="2" y2="22" />
            <line x1="17.5" y1="15" x2="9" y2="15" />
          </svg>
          Document Upload 
        </a>
        <?php } elseif (empty($data['service_required'])) {?>
          <a href="" class="basic-detail" data-section="2" disabled>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-feather">
            <path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z" />
            <line x1="16" y1="8" x2="2" y2="22" />
            <line x1="17.5" y1="15" x2="9" y2="15" />
          </svg>
          Document Upload
        </a>
        <?php } ?>
      </li>
      <li>
 

         <a href="/user/user-status" class="basic-detail" data-section="3" disabled>
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-feather">
            <path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z" />
            <line x1="16" y1="8" x2="2" y2="22" />
            <line x1="17.5" y1="15" x2="9" y2="15" />
          </svg>
          Status
        </a> 
        
      </li>
    </ul>
  </nav>
</div>

 

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>


<!-- Add this script after jQuery -->







<script>
document.getElementById("submitButton").addEventListener("click", function() {
    var url = "/user/document";
    window.open(url, "_blank");
});
</script>

