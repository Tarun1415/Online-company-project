
   <!-- ======= Header ======= -->
<header id="header" class="header sticky-top relative-top" data-scrollto-offset="0">
  <style>
    /* Custom CSS for dropdown alignment and styling */
.navbar .dropdown .megamenu {
  position: absolute;
  left: 0;
  right: 0;
  width: 100%;
  padding: 15px 0;
  background: #fff;
  border-top: 3px solid #5cb874;
  display: none;
  z-index: 99;
  max-height: 400px; /* Adjust the max-height as needed */
  overflow-y: auto; /* Enable vertical scrolling if content exceeds max-height */
}

.navbar .dropdown:hover .megamenu {
  display: block;
}

.navbar .megamenu ul {
  display: flex;
  flex-wrap: wrap;
  padding: 0;
  margin: 0;
}

.navbar .megamenu ul li {
  list-style: none;
  padding: 10px 0;
  width: 50%; /* Adjust width to ensure proper alignment */
}

.navbar .megamenu ul li a.head_color {
  font-weight: bold;
  color:  #d1b30b;
  display: block;
  padding: 5px 10px;
}

.navbar .megamenu ul li a.link_text {
  color: #eb1515;
  display: block;
  padding: px 10px;
}

.navbar .megamenu ul li a.link_text:hover {
  text-decoration: underline;
}

.navbar .dropdown .dropdown-indicator {
  margin-left: 5px;
}

/* Additional media query for smaller screens */
@media (max-width: 768px) {
  .navbar .megamenu ul li {
    width: 50%; /* Adjust width for smaller screens */
  }
}

  </style>
  <div class="container-fluid d-flex align-items-center justify-content-between">

    <a href="/" class="logo d-flex align-items-center scrollto me-auto me-lg-0">
      <!-- Uncomment the line below if you also wish to use an image logo -->
      <img src="/assets/img/logOCfinal1.svg" alt="">
      <!--<h1>Online<span>.</span></h1>-->
    </a>
    
    <nav id="navbar" class="navbar">
      <ul>
        <li class="nav-link"><a href="/"><span>Home</span></a>
        <li class="nav-link"><a href="/about"><span>About Us</span></a>
        <li class="dropdown megamenu"><a href="#"><span>Our Services</span> <i class="bi bi-chevron-down dropdown-indicator"></i></a>
          <ul>
            @if (getservice()->isNotEmpty())
              @foreach (getservice() as $category)
              <li>
                <a class="head_color" href="#">{{ $category->name }}</a>
                @if ($category->sub_service->isNotEmpty())
                  @foreach ($category->sub_service as $subcategory)
                    <a href="{{ route('front.user', [$subcategory->slug]) }}" class="link_text">{{ $subcategory->name }}</a>
                  @endforeach
                @endif
              </li>
              @endforeach                                                                                                                                          
            @endif                                                                     
          </ul>                                         
        </li>
                                                                     
       <li><a class="nav-link" href="/contact">Contact Us</a></li>
       </ul> 
      <i class="bi bi-list d-none mobile-nav-toggle "></i>
    </nav>
   
        
    

<div class="btn-group dropstart ">
  <i class="bi bi-person btn btn-secondary btn-getstarted" type="button" data-bs-toggle="dropdown" aria-expanded="false"></i>
  <ul class="dropdown-menu btn-getstarted">
    <a class="dropdown-item" data-bs-toggle="modal" data-bs-target="#exampleModalCenter" >Profile Pic</a>
    <form action="{{ route('user.logout') }}" method="POST" id="formlogout" class="m-0 p-0">
      @csrf
      <button type="submit" class="btn btn-link dropdown-item m-0 p-0">
        &nbsp;&nbsp;&nbsp;  Logout
      </button>
  </form>
    {{-- <a href="/" class="dropdown-item">Log Out</a> --}}
  {{-- <a class="dropdown-item" onClick="globalLogout()">Log Out</a> --}}
  </ul>
</div>

    </div>
  </header><!-- End Header -->


  
<!-- Modal for Edit Profile -->
  <div class="modal fade modal-lg" id="exampleModalCenter">
    <div class="modal-dialog" id="loginform">
        <div class="modal-content">
            <div class="modalwrapper rounded d-flex align-items-stretch">
                

                <?php if (session('user_id')) { ?>
                    <div class="contact-form">
                        <form method="post" action="/upload-profile" enctype='multipart/form-data' id="cform">
                            @csrf
                            
                            <h2 class="h3 mb-2">Update profile <i class="text-primary fas fa-user p-2"></i></h2>
                            <div class="">
                               
                            <div class="form-group pt-lg-2 pt-3">
                            <input type="file" placeholder="Enter Name*" id="nameID" class="form-control phone-mask" name="user_profile" >
                            @error('user_profile')
                                            <div class="text-danger">{{$message}}</div>
                                        @enderror
                                        @if(session()->get('error'))
                                            <div class="text-danger">{{ session()->get('error')}}</div>
                                        @endif
                            </div>
            
                            <div class="form-group pt-lg-2 pt-3" id="btn-cen">
                            <button type="submit" class="btn btn-submit btn-warning">SUBMIT</button>
                            </div> 
                            </div>
                        </form>
                    </div>
                <?php } ?>

            </div>
        </div>
    </div>
</div>



<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  
  <script>
function globalLogout()
{

  $(document).click();

// Get the page name where user logout
swal({
  title: "Log Out",
  text: "Are you sure want to log-off?",
  type: "warning",
  showCancelButton: true,
  confirmButtonClass: "btn-danger",
  confirmButtonText: "Log Out",
  closeOnConfirm: false
},
function(){
  window.location="{{url('')}}/user-logout";
});



}

</script>