<section class="" id="section1">
  <form method="post" id="myForm" enctype='multipart/form-data'>
    @csrf
    <h1>Basic Details</h1>
    <div class="nice-form-group">
      <input type="hidden" id="" value="{{$data['lead_id']}}" name="lead_id" value="" required>
      <input type="hidden" id="" value="{{$data['lead_id']}}" name="user_id" value="" required>
      <label>Name</label>
      <input type="text" value="{{$data['user_name']}}" id="user_name" name="user_name" placeholder="Your name" required />
    </div>
    <div class="nice-form-group">
      <label>Phone No.</label>
      <input type="text" id="" name="" value="{{$data['user_contact_number']}}" placeholder="" disabled />
    </div>


    <div class="nice-form-group">
      <label>Email</label>
      <input type="email" value="{{$data['user_email']}}" id="user_email" name="user_email" placeholder="joe@example.com" required />
    </div>
    <div class="nice-form-group " id="mcqForm">
      <h1>What Sevices are you Looking for ?</h1>
     
      @if(empty($userselectedservices[0]['service_ids']))
      <ul>
        <h1 style="color:red;"><i class="bi bi-x-octagon-fill"></i> Please Select Services</h1>
      </ul>
      @endif
     

<!-- 
      @foreach($services as $key2 => $service)

      <label>

        <input type="checkbox" name="service_required[]" value="{{$service['service_id']}}">
        {{$service['service_name']}}


      </label>

      @endforeach -->


      @foreach ($services as $service)
        <div>
            <input type="checkbox" name="services[]" value="{{ $service['service_id'] }}"
                {{ in_array($service['service_id'], $userselectedservices[0]['service_ids']) ? 'checked' : '' }}>
            <label>{{ $service['service_name'] }}</label>
        </div>
    @endforeach


    </div>
    <div class="nice-form-group">
      <input type="hidden" value="0" id="document_required" name="document_required" />


      <button type="submit" id="submitButton" class="offset-5 btn btn">Submit</button>


  </form>
</section>