@extends('layouts.user-dashboard.user-header-footer')

@section('content')
{{-- @extends('layouts.default-new')
@section('content') --}}

<link rel="stylesheet" href="../assets/css/custom.css">


<div class="demo-page">

@include('includes.user-sidebar')

            
            <main class="demo-page-content">
              <div class="progress-bar">
                <div class="progress" id="progress"></div>
              </div>
              <section id="section3">
                <h1>Status</h1>
    Congratulation you are done with procedure we 'll update you soon 🎉🎉🎉
              </section>
            </main>
                </div>
          </div>


          


          <script>document.addEventListener("DOMContentLoaded", function() {
            // Show the first section by default
            toggleSection(3);
          
            // Set the initial progress bar width
            var progress = document.getElementById('progress');
            var progressBarWidth = '77.33%';
            progress.style.width = progressBarWidth;
          });
          
          function toggleSection(sectionNumber) {
            var sections = document.querySelectorAll('.demo-page-content section');
            sections.forEach(function(section) {
              section.style.display = 'none';
            });
            var selectedSection = document.getElementById('section' + sectionNumber);
            selectedSection.style.display = 'block';
          
            var progress = document.getElementById('progress');
            var progressBarWidth = (sectionNumber === 2) ? '66.66%' : (sectionNumber === 3) ? '100%' : '33.33%';
            progress.style.width = progressBarWidth;
          
            var navLinks = document.querySelectorAll('.demo-page-navigation a');
            navLinks.forEach(function(link) {
              link.removeAttribute('disabled');
            });
          
            var currentLink = document.querySelector('.demo-page-navigation a[data-section="' + sectionNumber + '"]');
            currentLink.setAttribute('disabled', 'disabled');
          
            var menuItems = document.querySelectorAll('.demo-page-navigation li');
            menuItems.forEach(function(item) {
              item.classList.remove('active');
            });
          
            var currentMenuItem = currentLink.parentNode;
            currentMenuItem.classList.add('active');
          }
          

  function nextSection(sectionNumber) {
    toggleSection(sectionNumber);
  }
            



            const form = document.getElementById('mcqForm');
            form.addEventListener('submit', function(event) {
              event.preventDefault(); // Prevent form submission
          
              const selectedOptions = [];
              const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
          
              checkboxes.forEach(function(checkbox) {
                selectedOptions.push(checkbox.value);
              });
          
              // Validate the answers or perform other actions
              if (selectedOptions.length > 0) {
                console.log('Selected options:', selectedOptions);
                // Perform further actions like checking the correct answers, displaying results, etc.
              } else {
                console.log('Please select at least one option.');
              }
            });
          
            function handlePhotoUpload() {
              const photoInput = document.getElementById('photoUpload');
              const photoPreview = document.querySelector('.photo-upload .photo-preview');
          
              photoInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                const reader = new FileReader();
          
                reader.onload = function(e) {
                  const img = document.createElement('img');
                  img.src = e.target.result;
                  photoPreview.innerHTML = '';
                  photoPreview.appendChild(img);
                  photoPreview.parentElement.classList.add('show-preview');
                };
          
                reader.readAsDataURL(file);
              });
            }
          
            // Add the event listener when the DOM is loaded
            document.addEventListener('DOMContentLoaded', handlePhotoUpload);
          </script>






    @stop