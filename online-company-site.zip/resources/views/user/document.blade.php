@extends('layouts.user-dashboard.user-header-footer')

@section('content')
{{-- @extends('layouts.default-new')
@section('content') --}}

<link rel="stylesheet" href="../assets/css/custom.css">


<div class="demo-page">

  @include('includes.user-sidebar')


  <main class="demo-page-content">
    <div class="progress-bar">
      <div class="progress" id="progress"></div>
    </div>
    <section id="section2">

      <h1>Document Upload</h1>
      <div class="nice-form-group">

        @foreach($all_document['document_required'] as $all_documents)

        @if($all_documents == 0)
        <div class="blinking-container">
        <h1>Please Wait !!.</h1>
        <p id = "blinking-paragraph">While we are verifying your account</p>
    </div>
        @endif


        @if($all_documents == 1)
        <?php if (empty($all_documentuploaded['aadhar_card'])) { ?>
          <form method="post" onSubmit="uploadDocument(this);return false;" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="{{ csrf_token() }}" />
            <input type="hidden" name="user_id" value="{{$all_document['lead_id']}}">
            <input type="hidden" name="document" value="aadhar_card">
            <div class="itr" id="itr_part">
              <br>
              <h1>Aadhaar Card</h1>
              <div class="nice-form-group">
                <label>File upload</label>
                <input type="file" name="user_document">
              </div>
            </div>
            <div class="nice-form-group">
            <button type="submit" id="submitDocument" class="offset-5 btn btn">Upload</button>
            </div>
          </form>
          <div id="successMessage" style="display: none;">
    Success! Your form has been submitted.
</div>
        <?php } else { ?>

          <a class="btn btn-secondary  col-3" target="_blank"  style="font-size: small" href="/upload/user/{{$user_id}}/user-document/{{$all_documentuploaded['aadhar_card']}}">View adhar card File </a>
          <br>
          <br>
          <?php } ?>
        @endif

        @if($all_documents == 2)
        <?php if (empty($all_documentuploaded['pan_card'])) { ?>
          <form method="POST" onSubmit="uploadDocument(this);return false;" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="{{ csrf_token() }}" />
            <input type="hidden" name="user_id" value="{{$all_document['lead_id']}}">
            <input type="hidden" name="document" value="pan_card">
            <div class="companyreg" id="CompanyRegistration_part"><br>
              <h1>Pan Card</h1>
              <div class="nice-form-group">
                <label>File upload</label>
                <input type="file" name="user_document" />
              </div>
            </div>
            <div class="nice-form-group">
            <button type="submit" id="submitDocument" class="offset-5 btn btn">Upload</button>
            </div>
          </form>
          <div id="successMessage" style="display: none;">
    Success! Your form has been submitted.
</div>
        <?php } else { ?>


          <a class="btn btn-secondary btn-lg " style="font-size: small"  target="_blank" href="/upload/user/{{$user_id}}/user-document/{{$all_documentuploaded['pan_card']}}">View Pan Card File</a>
          <br>
          <br>
          <?php } ?>
        @endif
          


        @if($all_documents == 3)
        <?php if (empty($all_documentuploaded['credit_card'])) { ?>
          <form method="post" onSubmit="uploadDocument(this);return false;" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="{{ csrf_token() }}" />
            <input type="hidden" name="user_id" value="{{$all_document['lead_id']}}">
            <input type="hidden" name="document" value="credit_card">
            <div class="Coorporate" id="Coorporate_part"><br>
              <h1>Credit Card</h1>
              <div class="nice-form-group">
                <label>File upload</label>
                <input type="file" name="user_document">
              </div>
            </div>
            <div class="nice-form-group">
            <button type="submit" id="submitDocument" class="offset-5 btn btn">Upload</button>
            </div>
          </form>
          <div id="successMessage" style="display: none;">
    Success! Your form has been submitted.
</div>
        <?php }else { ?>

          <a class="btn btn-secondary btn-lg " style="font-size: small" target="_blank" href="/upload/user/{{$user_id}}/user-document/{{$all_documentuploaded['credit_card']}}">View credit Card File</a>
          <br>
          <br>
          <?php } ?> 
        @endif


        @if($all_documents == 4)
        <?php if (empty($all_documentuploaded['debit_card'])) { ?>
          <form method="post" onSubmit="uploadDocument(this);return false;" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="{{ csrf_token() }}" />
            <input type="hidden" name="user_id" value="{{$all_document['lead_id']}}">
            <input type="hidden" name="document" value="debit_card">
        <div class="Coorporate" id="Coorporate_part"><br>
          <h1>Debit Card</h1>
          <div class="nice-form-group">
            <label>File upload</label>
            <input type="file" name="user_document" />
          </div>
        </div>
        <div class="nice-form-group">
            <button type="submit" id="submitDocument" class="offset-5 btn btn">Upload</button>
            </div>
          </form>
          <div id="successMessage" style="display: none;">
    Success! Your form has been submitted.
</div>
        <?php }else { ?>


          <a class="btn btn-outline-secondary btn-lg" style="font-size: small" target="_blank" href="/upload/user/{{$user_id}}/user-document/{{$all_documentuploaded['debit_card']}}">View Debit Card File</a>
          <br>
          <br>
          <?php } ?>  
   
        @endif

        @if($all_documents == 5)
        <?php if (empty($all_documentuploaded['bank_proof'])) { ?>
          <form method="post" onSubmit="uploadDocument(this);return false;" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="{{ csrf_token() }}" />
            <input type="hidden" name="user_id" value="{{$all_document['lead_id']}}">
            <input type="hidden" name="document" value="bank_proof">
        <div class="Coorporate" id="Coorporate_part"><br>
          <h1>Bank Proof</h1>
          <div class="nice-form-group">
            <label>File upload</label>
            <input type="file" name="user_document" />
          </div>
        </div>
        <div class="nice-form-group">
            <button type="submit" id="submitDocument" class="offset-5 btn btn">Upload</button>
            </div>
          </form>
          <div id="successMessage" style="display: none;">
    Success! Your form has been submitted.
</div>
        <?php } else {?>

          <a class="btn btn-secondary btn-lg " style="font-size: small"  target="_blank" href="/upload/user/{{$user_id}}/user-document/{{$all_documentuploaded['bank_proof']}}">View Bank Uploaded File</a>
          <br>
          <br>
          <?php } ?>
        @endif
        @endforeach
      </div>
      <a class="btn btn-primary btn-lg mt-2 offset-5" href="/user/user-status">Submit documents</a>
      <br>
    </section>
  </main>
</div>
</div>















<script type="text/javascript" src="{!! asset('assets/izitoastr/iziToast.min.js') !!}"></script>



<script>
  function uploadDocument(node) {

    var formData = new FormData($(node)[0]);

    

    $.ajax({
      url: '{{url('')}}/user/document',
      type: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      success: function(data) {
        $('#successMessage').show();
        // window.location.replace('/user/user-status');
        location.reload();
        dataArr = JSON.parse(data);
 
        if (!dataArr.status) {

          iziToast.error({
            timeout: 3000,
            icon: 'fas fa-cross',
            title: 'File Upload',
            message: 'File upload Failed'
          });
          return true;

        }

        if (dataArr.status == 'success') {
          iziToast.success({
            timeout: 3000,
            icon: 'fas fa-thumbs-up',
            title: 'File Upload',
            message: 'File uploaded'
          });

          location.reload();

        } else {

        }

      },
      error: function(data) {

        iziToast.error({
          timeout: 3000,
          icon: 'fas fa-cross',
          title: 'File Upload',
          message: 'File upload Failed'
        });
        return true;

      }

    })


  }
</script>




<script>
  document.addEventListener("DOMContentLoaded", function() {
    // Show the first section by default
    toggleSection(2);

    // Set the initial progress bar width
    var progress = document.getElementById('progress');
    var progressBarWidth = '77.33%';
    progress.style.width = progressBarWidth;
  });

  function toggleSection(sectionNumber) {
    var sections = document.querySelectorAll('.demo-page-content section');
    sections.forEach(function(section) {
      section.style.display = 'none';
    });
    var selectedSection = document.getElementById('section' + sectionNumber);
    selectedSection.style.display = 'block';

    var progress = document.getElementById('progress');
    var progressBarWidth = (sectionNumber === 2) ? '66.66%' : (sectionNumber === 3) ? '100%' : '33.33%';
    progress.style.width = progressBarWidth;

    var navLinks = document.querySelectorAll('.demo-page-navigation a');
    navLinks.forEach(function(link) {
      link.removeAttribute('disabled');
    });

    var currentLink = document.querySelector('.demo-page-navigation a[data-section="' + sectionNumber + '"]');
    currentLink.setAttribute('disabled', 'disabled');

    var menuItems = document.querySelectorAll('.demo-page-navigation li');
    menuItems.forEach(function(item) {
      item.classList.remove('active');
    });

    var currentMenuItem = currentLink.parentNode;
    currentMenuItem.classList.add('active');
  }


  function nextSection(sectionNumber) {
    toggleSection(sectionNumber);
  }




  const form = document.getElementById('mcqForm');
  form.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const selectedOptions = [];
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');

    checkboxes.forEach(function(checkbox) {
      selectedOptions.push(checkbox.value);
    });

    // Validate the answers or perform other actions
    if (selectedOptions.length > 0) {
      console.log('Selected options:', selectedOptions);
      // Perform further actions like checking the correct answers, displaying results, etc.
    } else {
      console.log('Please select at least one option.');
    }
  });

  function handlePhotoUpload() {
    const photoInput = document.getElementById('photoUpload');
    const photoPreview = document.querySelector('.photo-upload .photo-preview');

    photoInput.addEventListener('change', function(event) {
      const file = event.target.files[0];
      const reader = new FileReader();

      reader.onload = function(e) {
        const img = document.createElement('img');
        img.src = e.target.result;
        photoPreview.innerHTML = '';
        photoPreview.appendChild(img);
        photoPreview.parentElement.classList.add('show-preview');
      };

      reader.readAsDataURL(file);
    });
  }

  // Add the event listener when the DOM is loaded
  document.addEventListener('DOMContentLoaded', handlePhotoUpload);
</script>


@stop