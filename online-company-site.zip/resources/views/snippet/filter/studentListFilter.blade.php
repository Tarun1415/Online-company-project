
<div class="modal fade" id="filterModal" tabindex="-1" role="dialog">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header row border-bottom bg-light m-0 p-0 pt-1">
      <div class="col section-title px-0 pb-0">
<h2 class="modal-title mb-0 pb-2 ml-5">Filter</h2>
</div>
<div class="col-auto">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
</div>
<div class="modal-body pricing">
    <?php $loanStatusArray = array(

  "pending"=>'Pending',
  "approved"=>'Approved',
  "reject"=>'Rejected',
  "ringing"=>'Ringing',
  "call back"=>'Call Back',
  "call not picked"=>'call not picked',
  "disbursed"=>'Disbursed',
  "send-to-bank"=>'Send To Bank',
  "not-intrested"=>'Not Intrested',
  "not-eligible"=>'Not Eligible'

 );
 ?>

<?php $priorityArray = array(

"low"=>'Low',
"medium"=>'Medium',
"high"=>'High',
"urgent"=>'Urgent',
"instantly_action"=>'Instant Action Required'

);
?>

<!-- filter -->
<form method="post" action="#" id="filterform">
<input type="hidden" name="_token"  value="{{ csrf_token() }}" />
<div class="row">




<div class="col-12 mb-2">
<select name="user_verification_status" id="user_verification_status" class="form-control " style="width:100%">
<option value="" selected>Select Status</option>
<option value="initial">Initial</option>
<option value="profile-details">Profile Details</option>
<option value="document-uploaded">Document Uploaded</option>
<option value="registration-done">Registration Done</option>
</select>


<?php if(isset($requestData['loan_final_status']) && !empty($requestData['loan_final_status'])) { ?>

<select name="loan_final_status" id="loan_final_status" class="form-control mt-2" style="width:100%">
      <option value="">Select Served Status</option>
     

      <?php 
        foreach($loanStatusArray as $backKey=>$value)
        {
        ?>

        <?php if(!empty($requestData['loan_final_status'] && $requestData['loan_final_status'] == $backKey )){?>
            <option value="{{ $backKey }}" selected>{{ $value }}</option>
        <?php } else {?>
        
        <option value="{{ $backKey }}">{{ $value }}</option>
      <?php  } } ?>
      </select>

      <?php } else {?>


<select name="loan_final_status" id="loan_final_status" class="form-control mt-2" style="width:100%">
    <option value="">Select Served Status</option>
   

    <?php 
      foreach($loanStatusArray as $backKey=>$value)
      {
      ?>
      <option value="{{ $backKey }}">{{ $value }}</option>
    <?php  }  ?>
    </select>

    <?php } ?>

    <select name="lead_priority" id="lead_priority" class="form-control mt-2" style="width:100%">
        <option value="">Select Priority Type</option>
       
  
        <?php 
          foreach($priorityArray as $backKey=>$value)
          {
          ?>
          <option value="{{ $backKey }}">{{ $value }}</option>
        <?php  }  ?>
        </select>

      <select name="lead_type" id="lead_type" class="form-control mt-2" style="width:100%">
            <option value="" selected>Select lead Type</option>
            <option value="hot">Hot</option>
            <option value="cold">Cold</option>
           
            </select>
</div>

<div class="col-12">
            <input type="text" id="reportrange" name="daterange" value="" class="form-control column_filter" placeholder="Add Date" data-column="0" style="width:100%">
</div>

</div>



<div class="row mt-3">
<div class="col text-center"> 
<button class="btn btn-customized-success btn-sm" id="searchBtn" type="button" onClick="submitFilter()">Search</button>
<button class="btn btn-customized-danger btn-sm ml-2" onClick="refreshPage();">Reset</button>
</div>
</div>




</form>

<!-- filter -->



</div>
</div>
</div>
</div>


<link href="../assets/vendors/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
<script src="../assets/vendors/moment/min/moment.min.js"></script>
<script src="../assets/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>




<script>

$(document).mouseup(function(e) {
        var container = $("#adv-search-wrap");
        var dateContainer = $('.daterangepicker');

        // if the target of the click isn't the container nor a descendant of the container
        if (!container.is(e.target) && container.has(e.target).length === 0) {

            if (e.target.closest(".daterangepicker")) {


            } else {

                container.hide();
            }

        }
    });
function refreshPage()
{
location.reload();
}


$(document).ready(function() {

init_daterangepicker();


});

function init_daterangepicker() {

if (typeof($.fn.daterangepicker) === 'undefined') {
    console.log('no instance for datepicker');
    return;
}
console.log('init_daterangepicker');

var cb = function(start, end, label) {
    //  console.log(start.toISOString(), end.toISOString(), label);
    $('#reportrange span').html(start.format('DD/MM/YYYY') + ' - ' + end.format('DD/MM/YYYY'));
};

var optionSet1 = {
    autoUpdateInput: false,
    minDate: '01/01/2018',
    maxDate: '01/01/2030',

    showDropdowns: true,
    showWeekNumbers: true,
    timePicker: false,
    timePickerIncrement: 1,
    timePicker12Hour: true,
    ranges: {
        'Today': [moment(), moment()],
        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment().add(1,'days')],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
    },
    opens: 'left',
    buttonClasses: ['btn btn-primary'],
    applyClass: 'btn-small btn-primary',
    cancelClass: 'btn-small',

    separator: ' to ',
    locale: {
        format: 'DD/MM/YYYY',
        applyLabel: 'Submit',
        cancelLabel: 'Clear',
        fromLabel: 'From',
        toLabel: 'To',
        customRangeLabel: 'Custom',
        daysOfWeek: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        firstDay: 1
    }
};

//$('#reportrange span').html(moment().subtract(29, 'days').format('MMMM D, YYYY') + ' - ' + moment().format('MMMM D, YYYY'));
$('#reportrange').daterangepicker(optionSet1);

$('#reportrange').on('apply.daterangepicker', function(ev, picker) {
    $(this).val(picker.startDate.format('DD/MM/YYYY') + ' - ' + picker.endDate.format('DD/MM/YYYY'));
});
$('#reportrange').on('cancel.daterangepicker', function(ev, picker) {
    console.log("cancel event fired");
    $(this).val('');
});


}

</script>

<!-- bootstrap-daterangepicker -->

