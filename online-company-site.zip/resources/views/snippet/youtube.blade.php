<div class="container" data-aos="fade-up">

  <div class="section-header">
    <h2>Videos</h2>
    <!-- <p>Recent posts form our Blog</p> -->
  </div>

  <div class="row">

    <div class="col-md-6 col-xl-4">
      <div class="card mb-3">
        <!-- <div class="card-shadow"> -->
        <div class="ratio ratio-16x9">
          <iframe width="560" height="315" src="https://www.youtube.com/embed/D34k6NTJypc?si=DywDua531R-ElNe2" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></a>
        </div>
        <!-- </div> -->
      </div>
    </div>


    <div class="col-md-6 col-xl-4">
      <div class="card mb-3">
        <!-- <div class="card-shadow"> -->
        <div class="ratio ratio-16x9">
          <iframe width="560" height="315" src="https://www.youtube.com/embed/H4xPiJzepoc?si=CZkAboai6mCtVqie" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <!-- </div> -->
      </div>
    </div>

    <div class="col-md-6 col-xl-4">
      <div class="card mb-3">
        <!-- <div class="card-shadow"> -->
        <div class="ratio ratio-16x9">
          <iframe width="560" height="315" src="https://www.youtube.com/embed/kqF4o_pINUQ?si=uIIG2SCaaFkqOeEp" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <!-- </div> -->
      </div>
    </div>


    {{-- row --}}

  </div>


  <div class="row">

    <div class="col-md-6 col-xl-4">
      <div class="card mb-3">
        <!-- <div class="card-shadow"> -->
        <div class="ratio ratio-16x9">
          <iframe width="560" height="315" src="https://www.youtube.com/embed/9khdJFcNHsU?si=f4Gey9tbs-8fpNwO" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <!-- </div> -->
      </div>
    </div>


  </div>






</div>






