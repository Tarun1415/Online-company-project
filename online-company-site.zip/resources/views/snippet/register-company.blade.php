@include('includes.head-new')

<div class="col-4">
     <form method="post" action="/registerOnline" class="container123">
          @csrf
          <center>
               <h3>Register your company today
               </h3>
          </center>
          <input type="text" placeholder="Enter Name*" id="nameID" name="user_name">
          @error('user_name')
          <div class="text-danger">{{$message}}</div>
          @enderror
          @if(session()->get('error'))
          <div class="text-danger">{{ session()->get('error')}}</div>
          @endif
          <input type="text" placeholder="Enter Email*" id="emailID" name="user_email">
          @error('user_email')
          <div class="text-danger">{{$message}}</div>
          @enderror
          @if(session()->get('error'))
          <div class="text-danger">{{ session()->get('error')}}</div>
          @endif
          <input type="text" placeholder="Enter Phone Number*" id="numberID" name="user_contact_number">
          @error('user_contact_number')
          <div class="text-danger">{{$message}}</div>
          @enderror
          @if(session()->get('error'))
          <div class="text-danger">{{ session()->get('error')}}</div>
          @endif
          <button type="submit" class="btn btn-warning btn-submit">SUBMIT</button>
     </form>
</div>




<!-- 
     <script src="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/js/iziToast.min.js" integrity="sha512-Zq9o+E00xhhR/7vJ49mxFNJ0KQw1E1TMWkPTxrWcnpfEFDEXgUiwJHIKit93EW/XxE31HSI5GEOW06G6BF1AtA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izitoast/1.4.0/css/iziToast.min.css" integrity="sha512-O03ntXoVqaGUTAeAmvQ2YSzkCvclZEcPQu1eqloPaHfJ5RuNGiS4l+3duaidD801P50J28EHyonCV06CUlTSag==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<script>


iziToast.error({timeout: 3000,  title: 'Error', message: 'Wrong Credentials!'});



</script> -->