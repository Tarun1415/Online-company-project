<!-- ======= Recent Video Posts Section ======= -->
<section id="recent-blog-posts" class="recent-blog-posts">
  <div class="container" data-aos="fade-up">
    <div class="section-header">
      <h1>Recent Videos</h1>
    </div>

    <div class="row">
      <?php
      foreach ($RecentVideos as $key => $post) {
        // Convert created_date to j M format
        $updateDate = new DateTime($post['created_date']);
        $RecentVideos[$key]['created_date'] = $updateDate->format('j M');

        // Convert updated_date to j M format
        $createDate = new DateTime($post['updated_date']);
        $RecentVideos[$key]['updated_date'] = $createDate->format('j M');

        // Normalize YouTube URL to embed format
        $url = $post['video_url'];
        $videoId = '';

        if (preg_match('/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|live\/|v\/))([^\?&]*)/', $url, $matches)) {
          $videoId = $matches[1];
        }

        if ($videoId) {
          $RecentVideos[$key]['video_url'] = 'https://www.youtube.com/embed/' . $videoId;
        }
      }
      ?>

      @foreach($RecentVideos as $video)
      <div class="col-md-6 col-xl-4">
        <div class="card mb-3">
          <div class="meta">
            <span class="post-date">{{ $video['created_date'] }}</span>
            <span class="post-author">{{ $video['video_title'] }}</span>
          </div>
          <div class="ratio ratio-16x9">
            <iframe width="560" height="315" src="{{ $video['video_url'] }}" frameborder="0" allowfullscreen></iframe>
          </div>
        </div>
      </div>
      @endforeach

    </div>
  </div>
</section>
<!-- End Recent Video Posts Section -->
