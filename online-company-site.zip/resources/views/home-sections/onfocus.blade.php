

  <!-- ======= On Focus Section ======= -->
  <section id="onfocus" class="onfocus">
    <div class="container-fluid p-0" data-aos="fade-up">

      <div class="row g-0">
        <div class="col-lg-6 video-play position-relative">
          <a href="https://www.youtube.com/watch?v=D34k6NTJypc" class="glightbox play-btn"></a>
        </div>
        <div class="col-lg-6"> 
          <div class="content d-flex flex-column justify-content-center h-100">
            <h3>Key feature Why Customers Love Us!</h3>
            <p class="fst-italic">
              100% on time project delivery, minimal charges, 100% online process, 24x7 open for cunsultant.
            </p>
            <ul>
              <li><i class="bi bi-check-circle"></i> Team of professionals and experts in services </li>
              <li><i class="bi bi-check-circle"></i> Easy and open to free cunsultant with Quick Services</li>
              <li><i class="bi bi-check-circle"></i> East to use portal and 100% Online Process via Email.</li>
            </ul>
            <a class="read-more text-white align-self-start" href="https://wa.me/7060055045"><i class="bi bi-whatsapp"></i> WhatsApp Now!</a>
          </div>
        </div>
      </div>

    </div>
  </section><!-- End On Focus Section -->
