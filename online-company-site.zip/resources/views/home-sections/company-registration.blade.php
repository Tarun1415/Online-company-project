@extends('layouts.default-new')

        @section('content')
      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    
    <link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet" />

  
    {{-- stariting wala yellow color start --}}
  </div>

    <div class="bg-img">
      <div class="container-fluid">
      <div class="row">
        <div class="first-section">
        <div class="col-8 containerLeft mt-5">
          
            <h2> Company Register In India</h2>
            <p >  Choosing the legal status of the company entity and obtaining the right registration are two of the many crucial components of establishing a business. Numerous advantages come with incorporating a firm as a company. Companies formed in accordance with the Companies Act of 2013 are distinct legal entities with perpetual existence, greater legitimacy, and limited responsibility for shareholders and directors. A corporation must be registered with the Registrar of Companies in accordance with the rules and regulations established by the Ministry of Corporate Affairs in order to be registered under the Companies Act of 2013. Businesses may qualify for a variety of exemptions and advantages from the government depending on their company strategy. Through the Ministry of Corporate Affairs website, one can register a company online.
            </p>
            <a href="signup"><button class="button btn-sm bg-white p-1" >
              Get Started
            </button></a>
          </div>
          </div>
        </div>

      

        @include('snippet.register-company')

      </div>
      </div>
    </div>
    </div> 
    {{-- staring wala yellow color and form end --}}
{{-- 
contant wala section chalu  --}}
    <section id="features" class="features">
        <div class="container aos-init aos-animate" data-aos="fade-up">

            <ul class="nav nav-tabs row gy-4 d-flex" role="tablist">

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-1" aria-selected="true"
                        role="tab" tabindex="-1">
                        <i class="bi bi-binoculars color-cyan"></i>
                        <h4>Company Registration In India </h4>
                    </a>
                </li><!-- End Tab 1 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-2" aria-selected="false"
                        role="tab">
                        <i class="bi bi-box-seam color-indigo"></i>
                        <h4>Benefit </h4>
                    </a>
                </li><!-- End Tab 2 Nav --> 

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-brightness-high color-teal"></i>
                        <h4>Criteria</h4>
                    </a>
                </li><!-- End Tab 3 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-command color-red"></i>
                        <h4>Process </h4>
                    </a>
                </li><!-- End Tab 4 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-easel color-blue"></i>
                        <h4>
                          Documents required
                        </h4>
                    </a>
                </li><!-- End Tab 5 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-map color-orange"></i>
                        <h4>Requirements of start a Company </h4>
                    </a>
                </li><!-- End Tab 6 Nav -->

            </ul>

            <div class="tab-content">

                <div class="tab-pane active show" id="tab-1" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1 aos-init aos-animate" data-aos="fade-up"
                            data-aos-delay="100">
                            <h3>Company Register In India</h3>
                            <p class="fst-italic">
                              Choosing the legal status of the company entity and obtaining the right registration are two of the many crucial components of establishing a business. Numerous advantages come with incorporating a firm as a company. Companies formed in accordance with the Companies Act of 2013 are distinct legal entities with perpetual existence, greater legitimacy, and limited responsibility for shareholders and directors. A corporation must be registered with the Registrar of Companies in accordance with the rules and regulations established by the Ministry of Corporate Affairs in order to be registered under the Companies Act of 2013. Businesses may qualify for a variety of exemptions and advantages from the government depending on their company strategy. Through the Ministry of Corporate Affairs website, one can register a company online.
                            </p>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 1 -->

                <div class="tab-pane " id="tab-2" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Benefit</h3>
                            
                            <p class="fst-italic">
                                
Private Limited Companies have a number of advantages over other business entity kinds. Incorporating a Private Limited Company is simple, inexpensive, and gives the company credibility because it is a legitimately formed entity. Additionally, they are free from a number of essential legal requirements under the 2013 Companies Act.

                            </p>
                            <ul>
                                <li><i class="bi bi-check-circle-fill"></i> Limited Liability</li>
                                <li><i class="bi bi-check-circle-fill"></i> Attractive to Investors.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Preferred by banks and Financial Institutions</li>
                                <li><i class="bi bi-check-circle-fill"></i> Income Tax</li>
                                <li><i class="bi bi-check-circle-fill"></i>Easy to incorporate</li>
                                
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 2 -->

                <div class="tab-pane" id="tab-3" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Criteria</h3>
                            <p class="fst-italic">
                              Before submitting an online application to register your company in India, keep the following things in mind. These are the essential conditions for setting up a business in India since they provide the regulatory framework required to win the MCA's approval.
                            </p>
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> At least two directors are required for the company:
                                   </li>
                                   <p>
                                    There should be at least two directors in your organisation if you wish to register a Private Limited firm rather than a One Person Company for your firm in India.
                                   </p>
                                <li><i class="bi bi-check-circle-fill"></i> An individual may serve as both a director and a shareholder:</li>
                                <p>
                                  When submitting a new company incorporation application online, the directors and shareholders/members may be treated as one and the same.
                                </p>
                                <li><i class="bi bi-check-circle-fill"></i> There are two different "Limited" qualities that a firm might have: </li>
                                <p>
                                  
                                </p>
                            </ul>
                            
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-3.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 3 -->

                <div class="tab-pane" id="tab-4" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Process of Company Registration </h3>
                           
                            <p class="fst-italic">
                            Following is the process of Pvt Ltd Company Registration 
                            </p>
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> Check for availability of Company Name: The initial step is to determine whether a Company Name is available in India. You must use either the official MCA portal or our platform to accomplish this.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Collecting the paperwork: Provide all the necessary documentation and get it certified by a company secretary or a chartered accountant.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Requesting and receiving a digital signature certificate:  You must submit your online application for company registration. Consequently, the DSC is required in order to authenticate the papers you upload to the MCA portal.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Getting a Director Identification Number by applying for one: To access the application for company registration, get your director identification number (DIN).</li>
                                <li><i class="bi bi-check-circle-fill"></i> Writing the MOA and AOA: Write the Memorandum of Association to emphasize the goals of your company. to describe the rules and regulations that your business follows.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Use the Spice form to register a business: The application for company registration in India is known as the Spice form. It offers sufficient information for a layperson to complete the application form and is thorough and easy to understand.</li>
                                <li><i class="bi bi-check-circle-fill"></i> The application form is processed: Your application form will be evaluated by the Registrar of Companies. If nothing went wrong, the certificate of incorporation will provide you with the company registration number.</li>
                               
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-4.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 4 -->

                <div class="tab-pane" id="tab-5" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Documents required for Company Registration</h3>
                         
                            <p class="fst-italic">
                            Here are the following documents which is required for the Pvt Ltd Company Registration
                            </p>
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> PAN Card of the Company: A vital document that the directors must supply in order to incorporate the company is the PAN card. The Income Tax Department of India issues this special identity, also referred to as the Permanent Account Number. Every situation involving the Company's finances requires the use of this document.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Company Director Address Proof : Aadhar cards, ration cards, driver's license, phone bills, bank statements, or other utility bills are acceptable forms of address verification for the company's directors.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Foreign nationals' passports: Any directors who are from another country are required to give a copy of their passport.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Proof of the registered office: Applicants must have a registered office in India in order to register a company online. There are two sorts of documentation that might serve as evidence of a registered office: Purchase or rental arrangement.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Digital Signature Certificate: A DSC is necessary to make the process of registering the Company online easier.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Identification Number Of Directors: Before submitting their applications, all prospective directors of a corporation are given a director identification number.</li>
                               
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-5.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 5 -->

                <div class="tab-pane" id="tab-6" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Documents required for Start Company</h3>
                          
                            <p class="fst-italic">
                            Here are the following documents which is required for the Pvt Ltd Company Registration
                            </p>
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> PAN Card of the Company: A vital document that the directors must supply in order to incorporate the company is the PAN card. The Income Tax Department of India issues this special identity, also referred to as the Permanent Account Number. Every situation involving the Company's finances requires the use of this document.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Company Director Address Proof : Aadhar cards, ration cards, driver's license, phone bills, bank statements, or other utility bills are acceptable forms of address verification for the company's directors.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Foreign nationals' passports: Any directors who are from another country are required to give a copy of their passport.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Proof of the registered office: Applicants must have a registered office in India in order to register a company online. There are two sorts of documentation that might serve as evidence of a registered office: Purchase or rental arrangement.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Digital Signature Certificate: A DSC is necessary to make the process of registering the Company online easier.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Identification Number Of Directors: Before submitting their applications, all prospective directors of a corporation are given a director identification number.</li>
                              
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-6.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 6 -->

            </div>

        </div>
    </section>



{{-- contant wala section end --}}

{{-- yellow wala whatsapp wala start --}}
{{-- <div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">
          <h4 class="ft-600 text-white ft-20">In case you have any query, please email us at <a class="text-white ft-700" href="mailto:info@hubco.in">info@hubco.in</a></h4>
        </div>
      </div>
    </div>
  </div>
</div> --}}
{{-- yellow wala whatsapp wala end --}}



{{-- our client start --}}
{{-- 
<div class="clients-slider swiper swiper-initialized swiper-horizontal swiper-pointer-events">
  <h1 style = "margin-left: 41%"> OUR CUSTOMER</h1>
  <div class="swiper-wrapper align-items-center" id="swiper-wrapper-146543cd5d3b2779" aria-live="off" style="transform: translate3d(-2472px, 0px, 0px); transition-duration: 0ms;"><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
  <div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div></div>
<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>

 --}}

{{-- our client end --}}

<!-- {{-- new feature start yellow wala  start--}}

<div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">


          <div class="p-l-5" >
    <P>Subscribe for free magazine and our startup network.</P>

        </div>
        <div class="d-flex flex-nowrap">
        <form class="form-inline">
         
          <div class="form-group order-3 p-2  ">
            <label for="inputPassword2" class="sr-only"></label>
            <input type="text" class="form-control" id="inputPassword2" placeholder="your.email@domain.com">
          </div>
          <div class = "order-3 p-2" >
          <button type="submit" class="btn btn-primary btn-sm">Confirm identit</button>
      </div>
    </div>  
        </form>

      
      </div>
      </div>
    </div>
  </div>
</div>

 {{-- new feature start yellow wala end --}} -->



{{-- Faq --}}
<section id="faq" class="faq">
  <div class="container-fluid aos-init aos-animate" data-aos="fade-up">

    <div class="row gy-4">

      <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

        <div class="content px-xl-5">
          <h3>Frequently Asked <strong>Questions</strong></h3>
          
        </div>

        <div class="accordion accordion-flush px-xl-5" id="faqlist">

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                <i class="bi bi-question-circle question-icon"></i>
                Does this process require my physical presence?
              </button>
            </h3>
            <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              No, the procedure of forming a company in India is entirely online. You do not need to be physically there at all because you can complete all documents electronically. All the necessary forms and documentation must be digitised and sent to us.
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="300">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                <i class="bi bi-question-circle question-icon"></i>
                Is an audit of a company's books required?
              </button>
            </h3>
            <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              Yes, regardless of its revenue, a private limited firm is required to employ an auditor. In fact, within 30 days of formation, an auditor must be engaged. Given that penalties for non-compliance can reach millions of rupees and possibly result in the blacklisting of directors, compliance is crucial for a private limited business.
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="400">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                <i class="bi bi-question-circle question-icon"></i>
                How can I determine whether or not my firm is registered?
              </button>
            </h3>
            <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              On the official MCA website, you may see the current status of the company registration.
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="500">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-4">
                <i class="bi bi-question-circle question-icon"></i>
                Who issues the corporation a certificate of registration?
              </button>
            </h3>
            <div id="faq-content-4" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
                <i class="bi bi-question-circle question-icon"></i>
                The Ministry of Corporate Affairs makes available the company's registration certificate online.
              </div>
            </div>
          </div><!-- # Faq item-->

          

        </div>

      </div>

      <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img" style="background-image: url(&quot;assets/img/faq.jpg&quot;);">&nbsp;</div>
    </div>

  </div>
</section>


    @include('home-sections.recent-blog-posts')

    


  {{-- cdn file bootstrap --}}
 
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script>

@stop
