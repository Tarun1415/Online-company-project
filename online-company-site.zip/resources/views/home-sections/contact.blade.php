@extends('layouts.default-new')
@section('content')

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

<link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet" />


{{-- stariting wala yellow color start --}}
</div>



<section id="recent-blog-posts" class="recent-blog-posts">

  <div class="container" data-aos="fade-up">

    <div class="section-header">
      <h2 id="head-para">Contact Us</h2>
    </div>

    <div class="row">
      <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
        <div class="post-box">
          <h3 class="post-title">Address
          </h3>
          <p>279-280 First Floor,</p>
          <p id="head-para" class="fst-italic">279-280 First Floor,</p>
          <p id="head-para" class="fst-italic">Block-40, Sky Tower,</p>
          <p id="head-para" class="fst-italic">Sanjay Place, Agra-282002</p>
        </div>
      </div>


      <div class="col-lg-6" data-aos="fade-up" data-aos-delay="600">
          <div class="post-box">
            <h3 class="post-title">Contact Details
            </h3>
            <p id="head-para" class="fst-italic">Phone: +91 9557 758 422</p>
            <p id="head-para" class="fst-italic">Email: info@onlinecompany.co.in</p>

          </div>
        </div>


    </div>

</section>





@include('home-sections.features')
@include('home-sections.cta')
@include('home-sections.onfocus')
@include('home-sections.services')
@include('home-sections.faq')
@include('home-sections.recent-blog-posts')

{{-- cdn file bootstrap --}}

{{-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script> --}}

@stop