
        @extends('layouts.default-new')


      @section('content')
  
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

  <link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet" />


  {{-- stariting wala yellow color start --}}
</div>

<div class="bg-img">
  <div class="container-fluid">
    <div class="row">
    <div class="first-section">
      <div class="col-8 containerLeft mt-5">

        <h2> Shop Register In India</h2>
        <p >The shops and business establishments covered by the Act are required to voluntarily apply for registration under the applicable state Act. All businesses and establishments, including those operating and maintaining a business from home, are required by the Act to obtain a Shop and Establishment Registration Certificate or Shop Licence ("Certificate").
        </p>
        <a href="signup"><button class="button btn-sm bg-white p-1" >
              Get Started
            </button></a>
      </div>
</div>
    </div>

    @include('snippet.register-company')

  </div>
</div>
</div>
</div>
{{-- staring wala yellow color and form end --}}
{{--
contant wala section chalu  --}}
<section id="features" class="features">
  <div class="container aos-init aos-animate" data-aos="fade-up">

    <ul class="nav nav-tabs row gy-4 d-flex" role="tablist">

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-1" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-binoculars color-cyan"></i>
          <h4>Company Registration In India </h4>
        </a>
      </li><!-- End Tab 1 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-2" aria-selected="true" role="tab">
          <i class="bi bi-box-seam color-indigo"></i>
          <h4>Benefit </h4>
        </a>
      </li><!-- End Tab 2 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-brightness-high color-teal"></i>
          <h4>Criteria</h4>
        </a>
      </li><!-- End Tab 3 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-command color-red"></i>
          <h4>Process </h4>
        </a>
      </li><!-- End Tab 4 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-easel color-blue"></i>
          <h4>
            Documents required
          </h4>
        </a>
      </li><!-- End Tab 5 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-map color-orange"></i>
          <h4>Requirements of start a Company </h4>
        </a>
      </li><!-- End Tab 6 Nav -->

    </ul>

    <div class="tab-content">

      <div class="tab-pane active show" id="tab-1" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1 aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">
            <h3>Shop Register In India</h3>
            <p class="fst-italic">
              The shops and business establishments covered by the Act are required to voluntarily apply for registration under the applicable state Act. All businesses and establishments, including those operating and maintaining a business from home, are required by the Act to obtain a Shop and Establishment Registration Certificate or Shop Licence ("Certificate").
            </p>
            <p class="fst-italic">
              This Certificate is also necessary for business owners who operate out of their homes without a physical location to operate from. The owners of online stores, establishments, or e-commerce businesses are required to register under this Act and get a Certificate. Within 30 days of opening, every shop and business institution must register under the Act.
            </p>
            <p class="fst-italic">
              A fundamental registration or licence for the business is served by the Certificate or Shop Licence. For many other company licences and registrations, this Certificate is provided. It provides documentation for the establishment of a business or store. Additionally, it helps the business owner when they wish to open a current business bank account or apply for a loan. When opening a current account, the majority of banks will require this Certificate.
            </p>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 1 -->

      <div class="tab-pane" id="tab-2" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Benefit</h3>

            <p class="fst-italic">

              Each store or business must provide documentation of its legal entity, such as a proprietorship firm, partnership firm
            </p>
            <ul class="fst-italic">
              <li><i class="bi bi-check-circle-fill"></i> Legal Entity Proof </li>
              <li><i class="bi bi-check-circle-fill"></i>Business Bank Account .</li>
              <li><i class="bi bi-check-circle-fill"></i> Government Benefits</li>
              <li><i class="bi bi-check-circle-fill"></i> Reliable </li>
              <li><i class="bi bi-check-circle-fill"></i> Lifetime Certification </li>

            </ul>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 2 -->

      <div class="tab-pane" id="tab-3" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Criteria</h3>
            <p class="fst-italic">
              From state to state, there are variations in the requirements for getting the Shop and Establishment Registration Certificate. It may be purchased offline or online. </p>
            <ul class="fst-italic">
              <li><i class="bi bi-check-circle-fill"></i> The shop or establishment shouldn't be subject to any other laws, such the Factories Act of 1948.
              </li>
              
              <li><i class="bi bi-check-circle-fill"></i> The store or business should be situated within Tamil Nadu's boundaries.</li>
              
              <li><i class="bi bi-check-circle-fill"></i> The store or establishment must be in the business of trading, banking, insurance, or entertainment. </li>
              <li><i class="bi bi-check-circle-fill"></i> There should be at least one person working for the shop or establishment, excluding the owner.</li>

             
            </ul>
           
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-3.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 3 -->

      <div class="tab-pane" id="tab-4" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Process</h3>
            <p class="fst-italic">
              From state to state, there are variations in the requirements for getting the Shop and Establishment Registration Certificate. It may be purchased offline or online.
            </p>
            <p class="fst-italic">
              The shopkeeper or business owner must sign in to the website of the relevant State Labour Department in order to get the registration certificate online. The proprietor or owner must complete the Shop and Establishment Act registration application, upload the required supporting documentation, and pay the applicable registration fees. The required fees vary from one state to another. The registration certificate will be issued online to the business owner or proprietor as soon as the registration form is approved.

            </p>
            <p class="fst-italic">
            You must fill out and submit the registration application to the Chief Inspector of the relevant area along with the required fees in order to obtain the registration certificate offline. After concluding that the application was submitted correctly, the Chief Inspector will issue the registration certificate to the owner or proprietor. 

            </p>
            <p class="fst-italic">
            The registration application form includes information regarding the name of the employer and establishment, address, and type of establishment, as well as the number of employees and other necessary details. Prior to the end of the registration period, the registration application must be renewed. The Shop and Establishment Certificate's validity varies from state to state. While some states offer certificates with a lifelong validity, others only offer certificates with a one- to five-year validity.
            </p>
            
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-4.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 4 -->

      <div class="tab-pane" id="tab-5" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Employers Documents
            </h3>
            <p class="fst-italic">
              Identification Details of the Employer such as the Aadhaar, PAN Number, Passport Size Photographs

            </p>
            <p class="fst-italic">
              Copies of Utility Bills such as the water or electricity- This bill should not be older than two months

            </p>
            <ul class="fst-italic">
              <li><i class="bi bi-check-circle-fill"></i> In Case of Company, Certificate of Incorporation, MOA and AOA</li>
              <li><i class="bi bi-check-circle-fill"></i> In case of Partnership, then the copy of the Partnership Deed must be provided</li>
              <li><i class="bi bi-check-circle-fill"></i> In case of an LLP then the copy of the LLP agreement must be provided</li>
              <li><i class="bi bi-check-circle-fill"></i> Certificate of Incorporation Corresponding to the Companies Act, 2013</li>
              <li><i class="bi bi-check-circle-fill"></i> Co-operative Society – all the information pertaining the members of the society</li>
              <li><i class="bi bi-check-circle-fill"></i> RTO permit if required</li>
              <li><i class="bi bi-check-circle-fill"></i> Resolutions taken by the Directors</li>
              <li><i class="bi bi-check-circle-fill"></i> Licences- FSSAI , Drug License, Chemical License</li>
            </ul>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-5.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 5 -->

      <div class="tab-pane" id="tab-6" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Details about the Manager and Employer
            </h3>
            <p class="fst-italic">
              All information relevant to the manager and employer will be included in the information on the manager and employer. This will contain the names of the people.

            </p>
            
            <ul class="fst-italic">
              <li><i class="bi bi-check-circle-fill"></i>Postal Evidence for the Business: For the registration of shops and establishments, the business's registered business address must be given.</li>
              <li><i class="bi bi-check-circle-fill"></i> Information about the Business: It is necessary to submit all relevant information about the establishment. This will contain the place's name as well as any other necessary business details.
              </li>
              <li><i class="bi bi-check-circle-fill"></i>Establishment Class: The type of establishment must be specified by the applicant. For instance, the category of establishment will be "retail outlet and shop" if the applicant is opening a store. When applying for shop and establishment registration, the applicant must specify the establishment type.</li>
              <li><i class="bi bi-check-circle-fill"></i>Number of employees: In addition to the facts mentioned above, the applicant must disclose information regarding the number of employees at the firm. This would also entail giving specific information regarding whether the workers are full- or part-time employees of the business. </li>
              
            </ul>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-6.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 6 -->

    </div>

  </div>
</section>



{{-- contant wala section end --}}

{{-- yellow wala whatsapp wala start --}}
{{-- <div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">
          <h4 class="ft-600 text-white ft-20">In case you have any query, please email us at <a class="text-white ft-700" href="mailto:info@hubco.in">info@hubco.in</a></h4>
        </div>
      </div>
    </div>
  </div>
</div> --}}
{{-- yellow wala whatsapp wala end --}}



{{-- our client start --}}
{{--
<div class="clients-slider swiper swiper-initialized swiper-horizontal swiper-pointer-events">
  <h1 style = "margin-left: 41%"> OUR CUSTOMER</h1>
  <div class="swiper-wrapper align-items-center" id="swiper-wrapper-146543cd5d3b2779" aria-live="off" style="transform: translate3d(-2472px, 0px, 0px); transition-duration: 0ms;"><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
  <div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div></div>
<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>

 --}}

{{-- our client end --}}

<!-- {{-- new feature start yellow wala  start--}}

<div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">


          <div class="p-l-5">
            <P>Subscribe for free magazine and our startup network.</P>

          </div>
          <div class="d-flex flex-nowrap">
            <form class="form-inline">

              <div class="form-group order-3 p-2  ">
                <label for="inputPassword2" class="sr-only"></label>
                <input type="text" class="form-control" id="inputPassword2" placeholder="your.email@domain.com">
              </div>
              <div class="order-3 p-2">
                <button type="submit" class="btn btn-primary btn-sm">Confirm identit</button>
              </div>
          </div>
          </form>


        </div>
      </div>
    </div>
  </div>
</div>

{{-- new feature start yellow wala end --}} -->

{{-- Faq --}}
<section id="faq" class="faq">
  <div class="container-fluid aos-init aos-animate" data-aos="fade-up">

    <div class="row gy-4">

      <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

        <div class="content px-xl-5">
          <h3>Frequently Asked <strong>Questions</strong></h3>
         
        </div>

        <div class="accordion accordion-flush px-xl-5" id="faqlist">

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                <i class="bi bi-question-circle question-icon"></i>
                How long is a shop act licence valid?
              </button>
            </h3>
            <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
                Up to five years after the date of establishment, the validity is valid. </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="300">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                <i class="bi bi-question-circle question-icon"></i>
                Are both the federal government and state governments subject to the shop act registration requirements?
              </button>
            </h3>
            <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
                No! The Shop Act Licence does not apply to the offices of the federal and state governments. </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="400">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                <i class="bi bi-question-circle question-icon"></i>
                In all Indian states and union territories, is the shop act registration valid? </button>
            </h3>
            <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
                The license for the retail enterprise is good for the entire country. Each state, including UT, has its own laws that govern entities that are located within its borders. The general provisions of all state legislation, however, are comparable.
              </div>
            </div>
          </div><!-- # Faq item-->


        </div>

      </div>

      <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img" style="background-image: url(&quot;assets/img/faq.jpg&quot;);">&nbsp;</div>
    </div>

  </div>
</section>


@include('home-sections.recent-blog-posts')




{{-- cdn file bootstrap --}}

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script>

@stop