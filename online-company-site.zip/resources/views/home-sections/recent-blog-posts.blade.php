<!-- ======= Recent Blog Posts Section ======= -->
<section id="recent-blog-posts" class="recent-blog-posts">

  <style>
      .date-info p {
          display: none;
      }
      .blogs-cap .hidden-content {
          display: none;
      }
      .blogs-cap .visible-content {
          display: block;
      }
  </style>

  <div class="container" data-aos="fade-up">

      <div class="section-header">
          <h1>Recent Blogs</h1>
      </div>

      <div class="row">
          <?php
          
          foreach ($recentblogs as $key => $post) {
              // Convert post_update_date to j M format
              $updateDate = new DateTime($post['post_update_date']);
              $recentblogs[$key]['post_update_date'] = $updateDate->format('j M');

              // Convert post_create_date to j M format
              $createDate = new DateTime($post['post_create_date']);
              $recentblogs[$key]['post_create_date'] = $createDate->format('j M');
          }
          ?>

          @foreach($recentblogs as $blog)
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="600">
              <div class="post-box">
                  <div class="post-img">
                      <img src="{{ asset('upload/blogs/' . $blog['featured_img']) }}" class="img-fluid" alt="">
                  </div>
                  <div class="meta">
                      <span class="post-date">{{ $blog['post_update_date'] }}</span>
                      <span class="post-author"> / Online Company</span>
                  </div>
                  <h3 class="post-title text-muted">{{ $blog['post_display_name'] }}</h3>
                  <p>{{ Str::limit(strip_tags($blog['short_info']), 100, '...') }}</p>
                  <a href="{{ url('blogs/' . $blog['post_url']) }}" class="readmore stretched-link">
                      <span>Read More</span><i class="bi bi-arrow-right"></i>
                  </a>
              </div>
          </div>
          @endforeach
      </div>
  </div>
</section>
<!-- End Recent Blog Posts Section -->
