<link href="{{ asset('assets/css/main.css') }}" rel="stylesheet" />
  <!-- ======= Call To Action Section ======= -->
  <section id="cta" class="cta">
    <div class="container aos-init aos-animate" data-aos="zoom-out">
      <div class="row g-5">
        <div class="col-lg-8 col-md-6 content d-flex flex-column justify-content-center order-last order-md-first">
          <h3 >Get Query Resolve with 60+ Team of Experts </h3>
          <p> Do you have any queries regarding 
            <ul>
            <li> Online Company Registration </li>
            <li> Annual Company Audit and Compliance</li> 
            <li>Tax filling, GST Filing</li> 
            <li>ITR Filing, Licenses & Registrations</li> 
            <li>Labour Compliance, Convert Your Business.</li>
          </ul></p>
          <a class="btn btn-success text-white align-self-start" href="https://wa.me/7060055045"><i class="bi bi-whatsapp"></i> WhatsApp Now!</a>
        </div>

        <div class="col-lg-4">
          <div class="img">
            <img src="assets/img/cta.png" alt="" class="img">
          </div>
        </div>

      </div>

    </div>
  </section><!-- End Call To Action Section -->