
          @extends('layouts.default-new')
         

        @section('content')
      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    
    <link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet" />

  
    {{-- stariting wala yellow color start --}}
    </div>

    <div class="bg-img">
      <div class="container-fluid">
      <div class="row">
      <div class="first-section">
        <div class="col-8 containerLeft mt-5">
          
            <h2> Labour Compliance In India</h2>
            <p>It is difficult to comply with labour laws in India. In a single month, a multi-locational company handles several hundred labour compliances, including licences, registrations, consent orders, permissions, and renewals, among others.
            </p>
            <a href="signup"><button class="button btn-sm bg-white p-1" >
              Get Started
            </button></a>
          </div>
        </div>
        </div>
        
        @include('snippet.register-company')

      </div>
      </div>
    </div>
    </div> 
    {{-- staring wala yellow color and form end --}}
{{-- 
contant wala section chalu  --}}
    <section id="features" class="features">
        <div class="container aos-init aos-animate" data-aos="fade-up">

            <ul class="nav nav-tabs row gy-4 d-flex" role="tablist">

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-1" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-binoculars color-cyan"></i>
                        <h4>Labour Law Registration </h4>
                    </a>
                </li><!-- End Tab 1 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link " data-bs-toggle="tab" data-bs-target="#tab-2" aria-selected="true"
                        role="tab">
                        <i class="bi bi-box-seam color-indigo"></i>
                        <h4>Benefit </h4>
                    </a>
                </li><!-- End Tab 2 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-brightness-high color-teal"></i>
                        <h4>Criteria</h4>
                    </a>
                </li><!-- End Tab 3 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-command color-red"></i>
                        <h4>Process </h4>
                    </a>
                </li><!-- End Tab 4 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-easel color-blue"></i>
                        <h4>
                          Documents required
                        </h4>
                    </a>
                </li><!-- End Tab 5 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-map color-orange"></i>
                        <h4>Requirements of start a Company </h4>
                    </a>
                </li><!-- End Tab 6 Nav -->

            </ul>

            <div class="tab-content">

                <div class="tab-pane active show" id="tab-1" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1 aos-init aos-animate" data-aos="fade-up"
                            data-aos-delay="100">
                            <h3>Labour Compliance  </h3>
                            <p class="fst-italic">
                            It is difficult to comply with labour laws in India. In a single month, a multi-locational company handles several hundred labour compliances, including licences, registrations, consent orders, permissions, and renewals, among others.
                            </p> 
                            <p class="fst-italic">
                            Governments at the federal and state levels also pass laws governing all labor-related issues. There are variations in formats, forms, and due dates, among other things, as a result of how various governments have applied the regulations.
                            </p>
                            <p class="fst-italic">
                            It takes resources from across your organisation and extensive legal experience to manage labour compliances.
                            </p>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 1 -->

                <div class="tab-pane" id="tab-2" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Why labour law compliance is important and essential :</h3>
                            
                            
                            <p class="fst-italic"> Enhances workplace relations, or relations between employees and employers, and reduces 
 workplace conflicts.</p>
                                <p class="fst-italic"> Protects potential employees from exploitation by management or employers 
 Aids in securing equitable pay for employees ADVERTISEMENT Ads by 
Reduces labour discontent to a minimum 
Lessens tiffs, strikes, etc.</p>
                                <p class="fst-italic"> Ensures workers have a secure employment 
Encourages welcoming work environments in the industrial system 
Corrects rest breaks, work hours, etc. </p>
                                <p class="fst-italic"> Offers accident victims who are employees compensation.</p>
                                <p class="fst-italic">Employers in India are required to do the following to adhere to statutory requirements in addition to acquiring licences and registrations, maintaining registers, filing periodic returns, etc. under the relevant labour and employment legislations.</p>
                                
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 2 -->

                <div class="tab-pane" id="tab-3" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Criteria</h3>
                            <p class="fst-italic">
                              Before submitting an online application to register your company in India, keep the following things in mind. These are the essential conditions for setting up a business in India since they provide the regulatory framework required to win the MCA's approval.
                            </p>
                           
                                <p class="fst-italic"> At least two directors are required for the company:
                                   </p>
                                   <p>
                                    There should be at least two directors in your organisation if you wish to register a Private Limited firm rather than a One Person Company for your firm in India.
                                   </p>
                                <p class="fst-italic"> An individual may serve as both a director and a shareholder:</p>
                                <p>
                                  When submitting a new company incorporation application online, the directors and shareholders/members may be treated as one and the same.
                                </p>
                                <p class="fst-italic"> There are two different "Limited" qualities that a firm might have: </p>
                               
                      
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-3.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 3 -->

                <div class="tab-pane" id="tab-4" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Process of applying for Labor Compliance</h3>
                            <p class="fst-italic">
                            Depending on your area, industry, and the specific rules that apply to your firm, there may be variations in the application process for labour compliance. Here is a rough breakdown of the procedures you may take to guarantee labour compliance for your company, though:
                            </p>
                            
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> Do some investigation and find the relevant regulations: Find out the labour laws, guidelines, and standards that are relevant to your field and region by doing some study. These could cover things like anti-discrimination legislation, minimum wage regulations, laws governing the number of hours that an employee can work, laws governing employee rights, and more.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Engage Legal and Regulatory Professionals: It is crucial to seek legal advice from professionals who are aware about the labour regulations in your region, such as labour lawyers or HR consultants. On the particular compliance regulations that apply to your company, they can offer advice.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Create policies and procedures: Create and record firm policies and procedures that adhere to labour laws. These may cover rules regarding employment contracts, working conditions, overtime, breaks, anti-discrimination, anti-harassment, health and safety, employee perks, and more.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Documentation and Employee Contracts: Create formal offer letters or employment contracts for your staff. Make sure that these contracts contain all pertinent terms and conditions needed by labour regulations, such as pay, benefits, working hours, and job obligations.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Maintaining Employee Records: Create a system for keeping up-to-date, accurate employee records, including personnel files, payroll records, tax records, and any other pertinent documentation.</li>
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-4.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 4 -->

                <div class="tab-pane" id="tab-5" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Documents Required for Labor Compliance</h3>
                            <p class="fst-italic">
                            Depending on your region, industry, and the particular rules that apply to your firm, the requirements for complying with the law on labour can vary greatly. I can, however, give you a broad list of typical paperwork that is frequently needed for labour compliance requirements. Please be aware that this list might not contain all conceivable requirements, and you should always seek the advice of legal and regulatory specialists to guarantee complete compliance in your particular circumstance.
                            </p>
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i>  Letters of Offer and Employment Contracts: Employment agreements or offers of employment specifying the terms and circumstances of employment, including job duties, responsibilities, pay, benefits, working hours, and other pertinent information.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Records of Employees: Personnel files for every employee, including records of any disciplinary actions taken, as well as information such as resumes, applications, job histories, and performance reviews.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Pay and Hour Records: Records of the time put in by employees, including overtime, breaks, and pay rates. Payroll data, attendance logs, and time cards may be included.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Registers of Payroll: Documentation of all employee remuneration, including earnings, salaries, bonuses, and deductions. Also included in this could be details on tax withholding.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Financial Records: Tax documents, including the W-4 (Employee's Withholding Certificate) or analogous forms, are used to calculate tax withholding and the W-2 (Wage and Tax Statement) or equivalent forms are used to report earnings and taxes to both employees and tax authorities.</li>
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-5.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 5 -->

                <div class="tab-pane" id="tab-6" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Documents Required for Start Company
                            </h3>
                            
                            
                            <ul>
                                <li><i class="bi bi-check-circle-fill"></i> Records of Employees</li>
                                <li><i class="bi bi-check-circle-fill"></i> Registers of Payroll</li>
                                <li><i class="bi bi-check-circle-fill"></i> Financial Records</li>
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-6.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 6 -->

            </div>

        </div>
    </section>



{{-- contant wala section end --}}

{{-- yellow wala whatsapp wala start --}}
{{-- <div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">
          <h4 class="ft-600 text-white ft-20">In case you have any query, please email us at <a class="text-white ft-700" href="mailto:info@hubco.in">info@hubco.in</a></h4>
        </div>
      </div>
    </div>
  </div>
</div> --}}
{{-- yellow wala whatsapp wala end --}}



{{-- our client start --}}
{{-- 
<div class="clients-slider swiper swiper-initialized swiper-horizontal swiper-pointer-events">
  <h1 style = "margin-left: 41%"> OUR CUSTOMER</h1>
  <div class="swiper-wrapper align-items-center" id="swiper-wrapper-146543cd5d3b2779" aria-live="off" style="transform: translate3d(-2472px, 0px, 0px); transition-duration: 0ms;"><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
  <div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div></div>
<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>

 --}}

{{-- our client end --}}

<!-- {{-- new feature start yellow wala  start--}}

<div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">


          <div class="p-l-5">
    <P>Subscribe for free magazine and our startup network.</P>

        </div>
        <div class="d-flex flex-nowrap">
        <form class="form-inline">
         
          <div class="form-group order-3 p-2  ">
            <label for="inputPassword2" class="sr-only"></label>
            <input type="text" class="form-control" id="inputPassword2" placeholder="your.email@domain.com">
          </div>
          <div class = "order-3 p-2" >
          <button type="submit" class="btn btn-primary btn-sm">Confirm identit</button>
      </div>
    </div>  
        </form>

      
      </div>
      </div>
    </div>
  </div>
</div>

 {{-- new feature start yellow wala end --}} -->

{{-- Faq --}}
<section id="faq" class="faq">
  <div class="container-fluid aos-init aos-animate" data-aos="fade-up">

    <div class="row gy-4">

      <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

        <div class="content px-xl-5">
          <h3>Frequently Asked <strong>Questions</strong></h3>
          
        </div>

        <div class="accordion accordion-flush px-xl-5" id="faqlist">

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                <i class="bi bi-question-circle question-icon"></i>
                Does this process require my physical presence?
              </button>
            </h3>
            <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              No, the procedure of forming a company in India is entirely online. You do not need to be physically there at all because you can complete all documents electronically. All the necessary forms and documentation must be digitised and sent to us.
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="300">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                <i class="bi bi-question-circle question-icon"></i>
                Is an audit of a company's books required?
              </button>
            </h3>
            <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              Yes, regardless of its revenue, a private limited firm is required to employ an auditor. In fact, within 30 days of formation, an auditor must be engaged. Given that penalties for non-compliance can reach millions of rupees and possibly result in the blacklisting of directors, compliance is crucial for a private limited business.
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="400">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                <i class="bi bi-question-circle question-icon"></i>
                Who issues the corporation a certificate of registration?
              </button>
            </h3>
            <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              The Ministry of Corporate Affairs makes available the company's registration certificate online.
              </div>
            </div>
          </div><!-- # Faq item-->

        </div>

      </div>

      <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img" style="background-image: url(&quot;assets/img/faq.jpg&quot;);">&nbsp;</div>
    </div>

  </div>
</section>


    @include('home-sections.recent-blog-posts')




  {{-- cdn file bootstrap --}}
 
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script>

@stop
