
          @extends('layouts.default-new')
         

        @section('content')

    

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    
    <link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet" />

  
    {{-- stariting wala yellow color start --}}
    </div>

    <div class="bg-img">
      <div class="container-fluid">
      <div class="row">
      <div class="first-section">
        <div class="col-8 containerLeft mt-5">
          
            <h2> GST and All other Taxs</h2>
            <p>The Goods and Services Tax (GST) is a unified tax system in India that replaces several indirect taxes with a single levy. It reduces the complexity of taxes, prevents double taxation, and promotes economic expansion. It is broken up into CGST, SGST, and IGST components and is levied on both goods and services. In general, GST has improved the country's economy and made the Indian tax structure simpler to grasp.
            </p>
            <a href="signup"><button class="button btn-sm bg-white p-1" >
              Get Started
            </button></a>
          </div>
          </div>
        </div>

        @include('snippet.register-company')
        
      </div>
      </div>
    </div>
    </div> 
    {{-- staring wala yellow color and form end --}}
{{-- 
contant wala section chalu  --}}
    <section id="features" class="features">
        <div class="container aos-init aos-animate" data-aos="fade-up">

            <ul class="nav nav-tabs row gy-4 d-flex" role="tablist">

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-1" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-binoculars color-cyan"></i>
                        <h4>GST In India </h4>
                    </a>
                </li><!-- End Tab 1 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link " data-bs-toggle="tab" data-bs-target="#tab-2" aria-selected="true"
                        role="tab">
                        <i class="bi bi-box-seam color-indigo"></i>
                        <h4>Benefit </h4>
                    </a>
                </li><!-- End Tab 2 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-brightness-high color-teal"></i>
                        <h4>Criteria</h4>
                    </a>
                </li><!-- End Tab 3 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-command color-red"></i>
                        <h4>Process </h4>
                    </a>
                </li><!-- End Tab 4 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-easel color-blue"></i>
                        <h4>
                          Documents required
                        </h4>
                    </a>
                </li><!-- End Tab 5 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-map color-orange"></i>
                        <h4>Requirements of start a Company </h4>
                    </a>
                </li><!-- End Tab 6 Nav -->

            </ul>

            <div class="tab-content">

                <div class="tab-pane active show" id="tab-1" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1 aos-init aos-animate" data-aos="fade-up"
                            data-aos-delay="100">
                            <h3>What is GST ? </h3>
                            <p class="fst-italic">
                            The Goods and Services Tax (GST) is a unified tax system in India that replaces several indirect taxes with a single levy. It reduces the complexity of taxes, prevents double taxation, and promotes economic expansion. It is broken up into CGST, SGST, and IGST components and is levied on both goods and services. In general, GST has improved the country's economy and made the Indian tax structure simpler to grasp.
                            </p>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 1 -->

                <div class="tab-pane" id="tab-2" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Benefits of GST </h3>
                            
                          
                            
                                <p class="fst-italic"> Lessening of the total tax burden: This is anticipated to lead to a rise in consumption and a drop in the cost of goods and services as well as a lighter tax burden on businesses and trades. This adjustment is anticipated to have the long-term effects of raising output levels and advancing industries.</p>
                                <p class="fst-italic">There are no hidden taxes: Since the GST replaces all indirect taxes with a single tax, there is no possibility of a tax being included in a good or service's invoice. For instance, if a product costs Rs.500, it indicates that the total cost of the commodity, including all taxes and fees, is Rs. 500. </p>
                                <p class="fst-italic"> Having more disposable income on hand: After paying for all necessary expenses, a consumer's remaining cash is referred to as disposable income. The GST will boost the taxpayers' discretionary income by lowering their tax burden. </p>
                                <p class="fst-italic"> The customer base has more options: Previously, because of the cascading impact, the client had less available disposable income to spend on goods and services. The lower cost of products and services, however, as well as the increasing tax burden, have boosted customers' disposable money and given them a greater range of options when making purchases.</p>
                                <p class="fst-italic">Increased Economic Activity : There is a rise in economic activity as a result of lower prices for goods and services, higher consumer disposable income, and lower prices for products and services. </p>
                                <p class="fst-italic">More job opportunities: Since the GST was implemented, there are now more manufacturers and industries since the making of items has been made simpler. For the benefit of India's inhabitants, more industries will increase employment prospects in the nation. </p>
                                
                                
                            
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 2 -->

                <div class="tab-pane" id="tab-3" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Eligibility Criteria for Gst </h3>
                           
                            <ul class="fst-italic">
                                <li ><i class="bi bi-check-circle-fill"></i> A person who is registered under one of the laws that were in place before the establishment of the GST, such as excise, VAT, service tax, etc.
                                   </li>
                                   
                                <li><i class="bi bi-check-circle-fill"></i> A company having a turnover greater than the 20 lakh rupee benchmark. In India, the cap is 10 lakh rupees for states like Jammu and Kashmir, Himachal Pradesh, Uttarakhand, and the North Eastern provinces.
Either a non-resident Indian or a casual taxpayer.</li>
                                
                                <li><i class="bi bi-check-circle-fill"></i> Agents of a supplier, input service distributors, and operators or aggregators of online commerce.
Individuals who pay taxes via the GST Registration Reverse Charge Mechanism.</li>
<li><i class="bi bi-check-circle-fill"></i> Any individual who provides online information and database access or retrieval services to a person in India who is not a registered taxable person.</li>
<li><i class="bi bi-check-circle-fill"></i> Any company engaged in the supply of commodities with annual sales of more than Rs. 20 lakhs for states in the Special Category and Rs. 40 lakhs for states in the Normal Category.</li>
<li><i class="bi bi-check-circle-fill"></i> Any company that provides services and has an annual revenue of at least Rs. 10 lakhs for states in the Special Category and Rs. 20 lakhs for states in the Normal Category.</li>
<li><i class="bi bi-check-circle-fill"></i> When a registered company is sold to another party or dissolves, the transferee must reapply for registration as of the date of the sale.</li>
<li><i class="bi bi-check-circle-fill"></i> A person who is not a registered taxable person and who provides online information and database access or retrieval (OIDAR) services from outside of India to a resident of India.</li>
                               
                            </ul>

                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-3.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 3 -->

                <div class="tab-pane" id="tab-4" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Process for applying GST</h3>
                           
                            
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> Step 1: Go back to the GST portal and select the "Register" option from the "Services" menu.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Step 2: Is to choose "Temporary Reference Number (TRN)". Enter the captcha information and the TRN number now. Select "Proceed" from the menu.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Step 3: An OTP will be sent to the email address and registered mobile number you provided. Click "Proceed" after entering the OTP.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Step 4: The following page will provide information on the status of your application. There will be an Edit icon on the right; click it.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Step 5: The following step contains 10 components that must be completed and the necessary supporting documentation submitted. The following documents need to be uploaded: Photographs
Proof of a company address
Information about the bank, including the account number, the name of the bank, the branch location, and the IFSC code.
Form of Authorization
The taxpayer's legal structure.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Step 6: Visit the 'Verification' page, review the declaration, and then submit the application using one of the options listed below:</li>
                                <li><i class="bi bi-check-circle-fill"></i> Utilising an Electronic Verification Code (EVC). The registered cellphone number will receive a code.
If a company is registering, the application must be filed using a Digital Signature Certificate (DSC).
By e-Sign. The mobile number associated with the Aadhaar card will receive an OTP.

Once finished, a success message will appear on the screen. The registered email and mobile phone will receive the Application Reference phone (ARN).</li>
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-4.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 4 -->

                <div class="tab-pane" id="tab-5" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Documents Required for GST </h3>
                            <p>
                            For GST Registration, the following documents are necessary:
                            </p>
                           
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> Passport-sized pictures</li>
                                <li><i class="bi bi-check-circle-fill"></i> Identity documentation (Aadhar card, driver's licence, passport)</li>
                                <li><i class="bi bi-check-circle-fill"></i> Office address documentation</li>
                                <li><i class="bi bi-check-circle-fill"></i> Statements, canceled checks, and passbooks from the bank</li>
                                <li><i class="bi bi-check-circle-fill"></i> Partnership agreement for partnerships</li>
                                <li><i class="bi bi-check-circle-fill"></i> Private Limited Liability Company, LLP, or OPC Certificate of Incorporation</li>
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-5.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 5 -->

                <div class="tab-pane" id="tab-6" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Documents Required for Start Company</h3>
                           
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> Passport-sized pictures</li>
                                <li><i class="bi bi-check-circle-fill"></i> Office address documentation</li>
                                <li><i class="bi bi-check-circle-fill"></i> Office address documentation</li>
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-6.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 6 -->

            </div>

        </div>
    </section>



{{-- contant wala section end --}}

{{-- yellow wala whatsapp wala start --}}
{{-- <div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">
          <h4 class="ft-600 text-white ft-20">In case you have any query, please email us at <a class="text-white ft-700" href="mailto:info@hubco.in">info@hubco.in</a></h4>
        </div>
      </div>
    </div>
  </div>
</div> --}}
{{-- yellow wala whatsapp wala end --}}



{{-- our client start --}}
{{-- 
<div class="clients-slider swiper swiper-initialized swiper-horizontal swiper-pointer-events">
  <h1 style = "margin-left: 41%"> OUR CUSTOMER</h1>
  <div class="swiper-wrapper align-items-center" id="swiper-wrapper-146543cd5d3b2779" aria-live="off" style="transform: translate3d(-2472px, 0px, 0px); transition-duration: 0ms;"><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
  <div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div></div>
<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>

 --}}

{{-- our client end --}}

<!-- {{-- new feature start yellow wala  start--}}

<div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">


          <div class="p-l-5" >
    <P>Subscribe for free magazine and our startup network.</P>

        </div>
        <div class="d-flex flex-nowrap">
        <form class="form-inline">
         
          <div class="form-group order-3 p-2  ">
            <label for="inputPassword2" class="sr-only"></label>
            <input type="text" class="form-control" id="inputPassword2" placeholder="your.email@domain.com">
          </div>
          <div class = "order-3 p-2" >
          <button type="submit" class="btn btn-primary btn-sm">Confirm identit</button>
      </div>
    </div>  
        </form>

      
      </div>
      </div>
    </div>
  </div>
</div>

 {{-- new feature start yellow wala end --}} -->


{{-- Faq --}}
<section id="faq" class="faq">
  <div class="container-fluid aos-init aos-animate" data-aos="fade-up">

    <div class="row gy-4">

      <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

        <div class="content px-xl-5">
          <h3>Frequently Asked <strong>Questions</strong></h3>
          
        </div>

        <div class="accordion accordion-flush px-xl-5" id="faqlist">

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                <i class="bi bi-question-circle question-icon"></i>
                Does this process require my physical presence?
              </button>
            </h3>
            <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              No, the procedure of forming a company in India is entirely online. You do not need to be physically there at all because you can complete all documents electronically. All the necessary forms and documentation must be digitised and sent to us.
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="300">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                <i class="bi bi-question-circle question-icon"></i>
                Is an audit of a company's books required?
              </button>
            </h3>
            <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              Yes, regardless of its revenue, a private limited firm is required to employ an auditor. In fact, within 30 days of formation, an auditor must be engaged. Given that penalties for non-compliance can reach millions of rupees and possibly result in the blacklisting of directors, compliance is crucial for a private limited business.
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="400">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                <i class="bi bi-question-circle question-icon"></i>
                Who issues the corporation a certificate of registration?
              </button>
            </h3>
            <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              The Ministry of Corporate Affairs makes available the company's registration certificate online.
              </div>
            </div>
          </div><!-- # Faq item-->

        </div>

      </div>

      <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img" style="background-image: url(&quot;assets/img/faq.jpg&quot;);">&nbsp;</div>
    </div>

  </div>
</section>


    @include('home-sections.recent-blog-posts')




  {{-- cdn file bootstrap --}}
 
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script>

@stop

