 <!-- ======= Featured Services Section ======= -->
 <section id="featured-services" class="featured-services">
    <div class="container">

      <div class="row gy-4">

        <div class="col-xl-3 col-md-6 d-flex" data-aos="zoom-out">
          <div class="service-item position-relative">
            <div class="icon"><i class="bi bi-building icon"></i></div>
            <h4><a href="#"  data-toggle="modal" data-target="#exampleModalCenter" class="stretched-link">Online Business Registration&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4>
          
          </div>
        </div><!-- End Service Item -->

        <div class="col-xl-3 col-md-6 d-flex" data-aos="zoom-out" data-aos-delay="200">
          <div class="service-item position-relative">
            <div class="icon"><i class="bi bi-receipt-cutoff icon"></i></div>
            <h4><a href="#"  data-toggle="modal" data-target="#exampleModalCenter" class="stretched-link">Accounting & Book Keeping Services</a></h4>
           
          </div>
        </div><!-- End Service Item -->

        <div class="col-xl-3 col-md-6 d-flex" data-aos="zoom-out" data-aos-delay="400">
          <div class="service-item position-relative">
            <div class="icon"><i class="bi bi-currency-rupee icon"></i></div>
            <h4><a href="#"  data-toggle="modal" data-target="#exampleModalCenter" class="stretched-link">Taxes Filling and Tax Return Services</a></h4>
           
          </div>
        </div><!-- End Service Item -->

        <div class="col-xl-3 col-md-6 d-flex" data-aos="zoom-out" data-aos-delay="600">
          <div class="service-item position-relative">
            <div class="icon"><i class="bi bi-journal-album icon"></i></div>
            <h4><a href="#"  data-toggle="modal" data-target="#exampleModalCenter" class="stretched-link">Legal and Compliance Services&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4>
          
          </div>
        </div><!-- End Service Item -->

      </div>

    </div>
  </section><!-- End Featured Services Section -->