@extends('layouts.default-new')


@section('content')

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

<link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet" />


{{-- stariting wala yellow color start --}}
</div>

<div class="bg-img">
  <div class="container-fluid">
    <div class="row">
      <div class="first-section">
        <div class="col-8 containerLeft mt-5">

          <h2>License and Registration</h2>
          <p>In many cities, it is a legal requirement for new enterprises to obtain business licenses.Some business owners might be tempted to postpone applying for a business license until they are earning enough to cover the expense. It is crucial to comply with licensing regulations before a business owner opens its doors for the first time, even if it is unlikely that she will be caught operating without a license before her enterprise takes off. Business licenses not only give a company the legal right to function, but they also give the owner more credibility and enable them to request for support from the entire city.
          </p>
          <a href="signup"><button class="button btn-sm bg-white p-1">
              Get Started
            </button></a>
        </div>
      </div>
    </div>

    @include('snippet.register-company')

  </div>
</div>
</div>
</div>
{{-- staring wala yellow color and form end --}}
{{-- contant wala section chalu  --}}
<section id="features" class="features">
  <div class="container aos-init aos-animate" data-aos="fade-up">

    <ul class="nav nav-tabs row gy-4 d-flex" role="tablist">

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-1" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-binoculars color-cyan"></i>
          <h4>License and Registration </h4>
        </a>
      </li><!-- End Tab 1 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link " data-bs-toggle="tab" data-bs-target="#tab-2" aria-selected="true" role="tab">
          <i class="bi bi-box-seam color-indigo"></i>
          <h4>Benefit </h4>
        </a>
      </li><!-- End Tab 2 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-brightness-high color-teal"></i>
          <h4>Criteria</h4>
        </a>
      </li><!-- End Tab 3 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-command color-red"></i>
          <h4>Process </h4>
        </a>
      </li><!-- End Tab 4 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-easel color-blue"></i>
          <h4>
            Documents required
          </h4>
        </a>
      </li><!-- End Tab 5 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-map color-orange"></i>
          <h4>Requirements of start a Company </h4>
        </a>
      </li><!-- End Tab 6 Nav -->

    </ul>

    <div class="tab-content">

      <div class="tab-pane active show" id="tab-1" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1 aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">
            <h3>License and Registration</h3>
            <p class="fst-italic">
              In many cities, it is a legal requirement for new enterprises to obtain business licenses. Some business owners might be tempted to postpone applying for a business license until they are earning enough to cover the expense. It is crucial to comply with licensing regulations before a business owner opens its doors for the first time, even if it is unlikely that she will be caught operating without a license before her enterprise takes off. Business licenses not only give a company the legal right to function, but they also give the owner more credibility and enable them to request for support from the entire city.
            </p>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 1 -->

      <div class="tab-pane" id="tab-2" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Benefits of having a License </h3>

            <p class="fst-italic">Even though a business license is not necessary for your company to exist, there may still be advantages and skills that you wouldn't otherwise have. Business licenses can be easily and affordably obtained from your secretary of state.</p>
            <p class="fst-italic">You will frequently be given a form to fill out by the secretary of state's office in order to apply for a business license. When running a business, obtaining a business license can be very advantageous. The advantages listed below will become available to you after you have your license.</p>
            <ul>
              <li><i class="bi bi-check-circle-fill"></i> You are legally protected</li>
              <li><i class="bi bi-check-circle-fill"></i> Licensing build credibility</li>
              <li><i class="bi bi-check-circle-fill"></i> Receiving fund</li>
              <li><i class="bi bi-check-circle-fill"></i> Tax compliance</li>
              <li><i class="bi bi-check-circle-fill"></i>Wholesale license benefits</li>
              <li><i class="bi bi-check-circle-fill"></i>Easy entry in foreign market </li>

            </ul>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 2 -->

      <div class="tab-pane" id="tab-3" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Criteria for business license </h3>
            <p>
              Here Are some eligible criteria to apply for a business license are:
            </p>
            <ul>
              <li><i class="bi bi-check-circle-fill"></i>The applicant must be at least eighteen years old and cannot be a minor.
              </li>
              <li><i class="bi bi-check-circle-fill"></i> The candidate cannot be on any type of legal probation for a major offense.</li>

              <li><i class="bi bi-check-circle-fill"></i> The company ought to be legitimate. </li>
              <p>

              </p>
            </ul>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-3.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 3 -->

      <div class="tab-pane" id="tab-4" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Process of getting Business License</h3>
            <p class="fst-italic">Depending on the sort of business and the region, several procedures must be followed to obtain a business license. However, generally speaking, the actions you might need to conduct are:
            </p>
            <p class="fst-italic">
              Find out what kind of business license you need because various businesses could need different licenses.Because they could differ by city or state, find out what is required to get a license in your area.
              Obtain the relevant paperwork, such as business registration documents, insurance proof, and any other licenses or certificates that may be neededBecause .
            </p>
            <ul class="fst-italic">
              <li><i class="bi bi-check-circle-fill"></i> Send in your application and make any required payments.</li>
              <li><i class="bi bi-check-circle-fill"></i> Watch for the examination and approval of your application.</li>
              <li><i class="bi bi-check-circle-fill"></i> It's important to keep in mind that some companies, such home-based firms, do not need a separate business license but still need to establish their company and acquire any required license or certificates. It's a good idea to seek advice on how to apply for a business license in your community from your regional chamber of commerce or business development center.</li>
            </ul>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-4.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 4 -->

      <div class="tab-pane" id="tab-5" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Documents required for business license </h3>
            <p class="fst-italic">
              Depending on the jurisdiction and the type of business, different documents may be needed to obtain a business license. However, the following is a broad list of typical papers that can be needed when submitting an application for a business license:
            </p>
            <p class="fst-italic">
              Registration form for businesses: This form normally contains fundamental information about your company, like the legal name, address, ownership type (sole proprietorship, partnership, corporation), and contact information.
            </p>
            <ul class="fst-italic">
              <li><i class="bi bi-check-circle-fill"></i> Proof of identity: You can be required to present identification documents, such as a copy of a driver's license or passport, as proof of the identity of the business owner or owners.</li>
              <li><i class="bi bi-check-circle-fill"></i> Proof of address: Some countries want evidence of the company address, which can be proven using paperwork like utility bills, a lease, or a property deed.</li>
              <li><i class="bi bi-check-circle-fill"></i> Business plan: For certain sorts of enterprises or for particular licensing requirements, a thorough business plan may be necessary. Your company's goals, your marketing plan, your financial projections, and other important information are often included in a business plan.</li>
              <li><i class="bi bi-check-circle-fill"></i> Registration of trade names: If you conduct business using a trade name, commonly referred to as a "doing business as" or DBA name, you can be required to present proof of registration.</li>
              <li><i class="bi bi-check-circle-fill"></i> Professional licenses: Some companies, such those in the legal, financial, or healthcare industries, may need additional professional licenses or certificates. Include copies of any necessary qualifications or licenses for your profession.</li>
              <li><i class="bi bi-check-circle-fill"></i> Federal Employer Identification Number (EIN): The Internal Revenue Service (IRS) will likely need you to obtain an EIN if your company has workers or is organized as a corporation or partnership. Include a duplicate of the letter confirming your EIN.</li>
            </ul>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-5.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 5 -->

      <div class="tab-pane" id="tab-6" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Document Required for Start Company</h3>

            <ul class="fst-italic">
              <li><i class="bi bi-check-circle-fill"></i> Proof of address</li>
              <li><i class="bi bi-check-circle-fill"></i> Business plan</li>
              <li><i class="bi bi-check-circle-fill"></i> Registration of trade names</li>
            </ul>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-6.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 6 -->

    </div>

  </div>
</section>



{{-- contant wala section end --}}

{{-- yellow wala whatsapp wala start --}}
{{-- <div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">
          <h4 class="ft-600 text-white ft-20">In case you have any query, please email us at <a class="text-white ft-700" href="mailto:info@hubco.in">info@hubco.in</a></h4>
        </div>
      </div>
    </div>
  </div>
</div> --}}
{{-- yellow wala whatsapp wala end --}}



{{-- our client start --}}
{{--
<div class="clients-slider swiper swiper-initialized swiper-horizontal swiper-pointer-events">
  <h1 style = "margin-left: 41%"> OUR CUSTOMER</h1>
  <div class="swiper-wrapper align-items-center" id="swiper-wrapper-146543cd5d3b2779" aria-live="off" style="transform: translate3d(-2472px, 0px, 0px); transition-duration: 0ms;"><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
  <div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div></div>
<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>

 --}}

{{-- our client end --}}

<!-- {{-- new feature start yellow wala  start--}}

<div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">


          <div class="p-l-5" >
    <P>Subscribe for free magazine and our startup network.</P>

        </div>
        <div class="d-flex flex-nowrap">
        <form class="form-inline">
         
          <div class="form-group order-3 p-2  ">
            <label for="inputPassword2" class="sr-only"></label>
            <input type="text" class="form-control" id="inputPassword2" placeholder="your.email@domain.com">
          </div>
          <div class = "order-3 p-2" >
          <button type="submit" class="btn btn-primary btn-sm">Confirm identit</button>
      </div>
    </div>  
        </form>

      
      </div>
      </div>
    </div>
  </div>
</div>

 {{-- new feature start yellow wala end --}} -->


{{-- Faq --}}
<section id="faq" class="faq">
  <div class="container-fluid aos-init aos-animate" data-aos="fade-up">

    <div class="row gy-4">

      <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

        <div class="content px-xl-5">
          <h3>Frequently Asked <strong>Questions</strong></h3>

        </div>

        <div class="accordion accordion-flush px-xl-5" id="faqlist">

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                <i class="bi bi-question-circle question-icon"></i>
                Am I able to launch a business without registering?
              </button>
            </h3>
            <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
                Yes, it is possible to launch a business in India without registering. The simplest type of business structure is a proprietorship, and you can start one without having to file any paperwork. Even if you don't need to register to start a business, there are many advantages to doing so.
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="300">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                <i class="bi bi-question-circle question-icon"></i>
                Does a tiny company require a permit?
              </button>
            </h3>
            <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
                Small enterprises in India are required to get a variety of permits and licenses depending on the nature of their business operations. To comply with Indian rules and regulations, enterprises must get licenses and permits.
              </div>
            </div>
          </div><!-- # Faq item-->

        </div>

      </div>

      <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img" style="background-image: url(&quot;assets/img/faq.jpg&quot;);">&nbsp;</div>
    </div>

  </div>
</section>


@include('home-sections.recent-blog-posts')




{{-- cdn file bootstrap --}}

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script>

@stop