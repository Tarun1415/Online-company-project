


      @extends('layouts.default-new')

    @section('content')


</div>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

<link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet" />


{{-- stariting wala yellow color start --}}
</div>

<div class="bg-img">
  <div class="container-fluid">
    <div class="row">
    <div class="first-section">
      <div class="col-8 containerLeft mt-5">

        <h2> Corporate Compliance</h2>
        <p>A corporation can make sure it is abiding by all the rules and laws that are relevant to its operations by implementing corporate compliance. Generally speaking, this entails creating, carrying out, and overseeing policies, training, knowledge updates, processes, and practices within an organisation in accordance with the legal framework. This entails developing official policies to prevent legal infractions, educating staff about pertinent legislation, assembling a separate legal team for knowledge upgrades, putting compliance procedures into place, and keeping an eye out for any legal violations. A corporation runs a considerable risk of legal responsibility and reputational damage without these. As a result, it's crucial to establish a formal corporate compliance programme.. Therefore, it is essential to have a formal corporate compliance programme. It may be a good idea to discuss building and implementing a compliance plan with a corporate compliance partner in this regard.
        </p>
        <a href="signup"><button class="button btn-sm bg-white p-1" >
              Get Started
            </button></a>
      </div>
</div>
    </div>
    
    @include('snippet.register-company')

  </div>
</div>
</div>
</div>
{{-- staring wala yellow color and form end --}}
{{--
contant wala section chalu  --}}
<section id="features" class="features">
  <div class="container aos-init aos-animate" data-aos="fade-up">

    <ul class="nav nav-tabs row gy-4 d-flex" role="tablist">

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-1" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-binoculars color-cyan"></i>
          <h4>Corporate Compliance In India </h4>
        </a>
      </li><!-- End Tab 1 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-2" aria-selected="true" role="tab">
          <i class="bi bi-box-seam color-indigo"></i>
          <h4>Benefit </h4>
        </a>
      </li><!-- End Tab 2 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-brightness-high color-teal"></i>
          <h4>Criteria</h4>
        </a>
      </li><!-- End Tab 3 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-command color-red"></i>
          <h4>Process </h4>
        </a>
      </li><!-- End Tab 4 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-easel color-blue"></i>
          <h4>
            Documents required
          </h4>
        </a>
      </li><!-- End Tab 5 Nav -->

      <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
        <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6" aria-selected="false" role="tab" tabindex="-1">
          <i class="bi bi-map color-orange"></i>
          <h4>Requirements of start a Company </h4>
        </a>
      </li><!-- End Tab 6 Nav -->

    </ul>

    <div class="tab-content">

      <div class="tab-pane active show" id="tab-1" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1 aos-init aos-animate" data-aos="fade-up" data-aos-delay="100">
            <h3>Corporate Compliance </h3>
            <p class="fst-italic">
              A corporation can make sure it is abiding by all the rules and laws that are relevant to its operations by implementing corporate compliance. Generally speaking, this entails creating, carrying out, and overseeing policies, training, knowledge updates, processes, and practices within an organisation in accordance with the legal framework. This entails developing official policies to prevent legal infractions, educating staff about pertinent legislation, assembling a separate legal team for knowledge upgrades, putting compliance procedures into place, and keeping an eye out for any legal violations. A corporation runs a considerable risk of legal responsibility and reputational damage without these. As a result, it's crucial to establish a formal corporate compliance programme.. Therefore, it is essential to have a formal corporate compliance programme. It may be a good idea to discuss building and implementing a compliance plan with a corporate compliance partner in this regard.
            </p>
            <p class="fst-italic">
              Additionally, it's critical to keep in mind that compliance is a continuous process. As the laws continue to evolve or be updated, it is a routine procedure.
            </p>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 1 -->

      <div class="tab-pane" id="tab-2" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Benefits of Corporate Compliance</h3>

            <p class="fst-italic">

              Companies, employees, shareholders, and stakeholders can all profit from corporate compliance. Among the main benefits are:

            </p>
            <p class="fst-italic">Legal Protection: Adherence to laws and regulations lessens the possibility of facing fines, penalties, or legal action. It assists the business in avoiding reputational harm that could result from non-compliance.</p>
              
            <p class="fst-italic"> Ethical Reputation: The company's image is improved and more socially conscious investors, clients, and partners are drawn in as a result of strong compliance practices that develop a reputation for ethical behavior.</p>
            <p class="fst-italic"> Risk management: Compliance programmes detect and reduce potential risks, ensuring that the business is better equipped to face difficulties and uncertainties.</p>
            <p class="fst-italic"> Employee Trust and Morale: A culture of compliance shows a dedication to employees' welfare, job security, and fair treatment, which boosts employee morale and productivity.</p>
            <p class="fst-italic">Investor Confidence: Investors are more likely to have faith in a company that shows a dedication to compliance, which could lead to an increase in stock valuation.</p>

            
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 2 -->

      <div class="tab-pane" id="tab-3" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Eligibility Criteria for Corporate Compliance</h3>
            <p class="fst-italic">
              The requirements for corporate compliance might change based on the particular laws, rules, and industry norms that a firm must abide by. However, the following typical eligibility requirements that businesses must satisfy for corporate compliance are listed:
            </p>
            <ul>
              <li><i class="bi bi-check-circle-fill"></i> Legal entity
              </li>
              
              <li><i class="bi bi-check-circle-fill"></i> Business license </li>
              
              <li><i class="bi bi-check-circle-fill"></i> Insurance coverage  </li>
              <li><i class="bi bi-check-circle-fill"></i> Environment compliance  </li>
              <li><i class="bi bi-check-circle-fill"></i> Employment right and labor law </li>
              <li><i class="bi bi-check-circle-fill"></i> Financial reporting   </li>
              
            </ul>
            
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-3.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 3 -->

      <div class="tab-pane" id="tab-4" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Process of applying for Corporate Compliance</h3>
            <p>
            A step-by-step manual for applying corporate compliance:
            </p>
            
            <ul>
              <li><i class="bi bi-check-circle-fill"></i>Determine the Relevant Regulations </li>
              <li><i class="bi bi-check-circle-fill"></i> Establish a Compliance Team</li>
              <li><i class="bi bi-check-circle-fill"></i> Performing a Compliance Audit </li>
              <li><i class="bi bi-check-circle-fill"></i> Creating compliance policies and practises</li>
              <li><i class="bi bi-check-circle-fill"></i> Organise Compliance Training</li>
              <li><i class="bi bi-check-circle-fill"></i> Create Monitoring and Reporting Mechanisms</li>
              <li><i class="bi bi-check-circle-fill"></i> Make a committee or officer responsible for compliance</li>
              <li><i class="bi bi-check-circle-fill"></i> Implement compliance technologies</li>
            </ul>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-4.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 4 -->

      <div class="tab-pane" id="tab-5" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Documents Required for Corporate Compliance </h3>
            <p>
            Here is a general list of commonly required documents for corporate compliance :
            </p>
            
            <ul>
              <li><i class="bi bi-check-circle-fill"></i> Bylaws </li>
              <li><i class="bi bi-check-circle-fill"></i> Business license and permitted</li>
              <li><i class="bi bi-check-circle-fill"></i> Financial Statements </li> 
              <li><i class="bi bi-check-circle-fill"></i> Shareholder Agreements</li> 
              <li><i class="bi bi-check-circle-fill"></i> Code of Conducts and ethics policy</li> 
              <li><i class="bi bi-check-circle-fill"></i> Articles of incorporation and formation</li> 
              <li><i class="bi bi-check-circle-fill"></i> Employments contracts </li> 
              <li><i class="bi bi-check-circle-fill"></i> Data privacy policy </li> 
            </ul>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-5.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 5 -->

      <div class="tab-pane" id="tab-6" role="tabpanel">
        <div class="row gy-4">
          <div class="col-lg-8 order-2 order-lg-1">
            <h3>Documents Required for Start Company</h3>
            <ul>
              <li><i class="bi bi-check-circle-fill"></i> Bylaws</li>
              <li><i class="bi bi-check-circle-fill"></i>Shareholder Agreements</li>
              <li><i class="bi bi-check-circle-fill"></i> Data privacy policy</li>
            </ul>
          </div>
          <div class="col-lg-4 order-1 order-lg-2 text-center">
            <img src="assets/img/features-6.svg" alt="" class="img-fluid">
          </div>
        </div>
      </div><!-- End Tab Content 6 -->

    </div>

  </div>
</section>



{{-- contant wala section end --}}

{{-- yellow wala whatsapp wala start --}}
{{-- <div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">
          <h4 class="ft-600 text-white ft-20">In case you have any query, please email us at <a class="text-white ft-700" href="mailto:info@hubco.in">info@hubco.in</a></h4>
        </div>
      </div>
    </div>
  </div>
</div> --}}
{{-- yellow wala whatsapp wala end --}}



{{-- our client start --}}
{{--
<div class="clients-slider swiper swiper-initialized swiper-horizontal swiper-pointer-events">
  <h1 style = "margin-left: 41%"> OUR CUSTOMER</h1>
  <div class="swiper-wrapper align-items-center" id="swiper-wrapper-146543cd5d3b2779" aria-live="off" style="transform: translate3d(-2472px, 0px, 0px); transition-duration: 0ms;"><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
  <div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div></div>
<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>

 --}}

{{-- our client end --}}

<!-- {{-- new feature start yellow wala  start--}}

<div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">


          <div class="p-l-5">
            <P>Subscribe for free magazine and our startup network.</P>

          </div>
          <div class="d-flex flex-nowrap">
            <form class="form-inline">

              <div class="form-group order-3 p-2  ">
                <label for="inputPassword2" class="sr-only"></label>
                <input type="text" class="form-control" id="inputPassword2" placeholder="your.email@domain.com">
              </div>
              <div class="order-3 p-2">
                <button type="submit" class="btn btn-primary btn-sm">Confirm identit</button>
              </div>
          </div>
          </form>


        </div>
      </div>
    </div>
  </div>
</div>

{{-- new feature start yellow wala end --}} -->


{{-- Faq --}}
<section id="faq" class="faq">
  <div class="container-fluid aos-init aos-animate" data-aos="fade-up">

    <div class="row gy-4">

      <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

        <div class="content px-xl-5">
          <h3>Frequently Asked <strong>Questions</strong></h3>
          
        </div>

        <div class="accordion accordion-flush px-xl-5" id="faqlist">

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                <i class="bi bi-question-circle question-icon"></i>
                Does this process require my physical presence?
              </button>
            </h3>
            <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              No, the procedure of forming a company in India is entirely online. You do not need to be physically there at all because you can complete all documents electronically. All the necessary forms and documentation must be digitised and sent to us.
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="300">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                <i class="bi bi-question-circle question-icon"></i>
                Is an audit of a company's books required?
              </button>
            </h3>
            <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              Yes, regardless of its revenue, a private limited firm is required to employ an auditor. In fact, within 30 days of formation, an auditor must be engaged. Given that penalties for non-compliance can reach millions of rupees and possibly result in the blacklisting of directors, compliance is crucial for a private limited business.
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="400">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                <i class="bi bi-question-circle question-icon"></i>
                Who issues the corporation a certificate of registration?
              </button>
            </h3>
            <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              The Ministry of Corporate Affairs makes available the company's registration certificate online.
              </div>
            </div>
          </div><!-- # Faq item-->

        </div>

      </div>

      <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img" style="background-image: url(&quot;assets/img/faq.jpg&quot;);">&nbsp;</div>
    </div>

  </div>
</section>


@include('home-sections.recent-blog-posts')




{{-- cdn file bootstrap --}}

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script>

@stop