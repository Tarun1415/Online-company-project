
          @extends('layouts.default-new')
         
  
        @section('content')
    
    

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    
    <link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet" />

  
    {{-- stariting wala yellow color start --}}
    </div>

    <div class="bg-img">
      
      <div class="container-fluid">
      <div class="row">
               <div class="first-section">
        <div class="col-8 containerLeft mt-5">
          
            <h2> Conversion of Pvt Ltd to One Person Company</h2>
            <p>As per the Companies Act, 2013, which establishes a process to change one kind of company into another, a PLC (Private Limited Company) may be converted into an OPC (One Person Company). With effect from 1 April 2014, Section 18 of the Act expressly permits the conversion of an existing private limited company that has already been registered.
            </p>
            <a href="signup"><button class="button btn-sm bg-white p-1" >
              Get Started
            </button></a>
          </div>
          </div>
        </div>

        @include('snippet.register-company')

      </div>
      </div>
    </div>
    </div> 
    {{-- staring wala yellow color and form end --}}
{{-- 
contant wala section chalu  --}}
    <section id="features" class="features">
        <div class="container aos-init aos-animate" data-aos="fade-up">

            <ul class="nav nav-tabs row gy-4 d-flex" role="tablist">

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-1" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-binoculars color-cyan"></i>
                        <h4>Convert Business In India </h4>
                    </a>
                </li><!-- End Tab 1 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-2" aria-selected="true"
                        role="tab">
                        <i class="bi bi-box-seam color-indigo"></i>
                        <h4>Benefit </h4>
                    </a>
                </li><!-- End Tab 2 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-brightness-high color-teal"></i>
                        <h4>Criteria</h4>
                    </a>
                </li><!-- End Tab 3 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-command color-red"></i>
                        <h4>Process </h4>
                    </a>
                </li><!-- End Tab 4 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-easel color-blue"></i>
                        <h4>
                          Documents required
                        </h4>
                    </a>
                </li><!-- End Tab 5 Nav -->

                <li class="nav-item col-6 col-md-4 col-lg-2" role="presentation">
                    <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6" aria-selected="false"
                        role="tab" tabindex="-1">
                        <i class="bi bi-map color-orange"></i>
                        <h4>Requirements of start a Company </h4>
                    </a>
                </li><!-- End Tab 6 Nav -->

            </ul>

            <div class="tab-content">

                <div class="tab-pane active show" id="tab-1" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1 aos-init aos-animate" data-aos="fade-up"
                            data-aos-delay="100">
                            <h3>Conversion of Pvt Ltd to One Person Company </h3>
                            <p class="fst-italic">
                            As per the Companies Act, 2013, which establishes a process to change one kind of company into another, a PLC (Private Limited Company) may be converted into an OPC (One Person Company). With effect from 1 April 2014, Section 18 of the Act expressly permits the conversion of an existing private limited company that has already been registered.
                            </p>
                            <p class="fst-italic">
                            The duties and legal commitments of the business before conversion would not change as a result of the PLC becoming an OPC, and the new OPC would be responsible for them. Such claims, liabilities, and obligations would also be legally enforceable.
                            </p>
                            <p class="fst-italic">
                            The organizational framework of a private firm frequently disintegrates when one of its promoters decides to leave his job. The expert in this case proposes that you convert your private limited business to an OPC. An OPC is a type of business structure that can be incorporated with just one stakeholder.
                            </p>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 1 -->

                <div class="tab-pane " id="tab-2" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Benefits of converting Pvt Ltd to One Person Company</h3>
                            
                            <p class="fst-italic">
                                
                            Here are the some benefit of converting Pvt Ltd to One Person Company :

                            </p>
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> No formality for the board meeting: 
A one-person business is not required to hold board or general meetings.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Greater Business from Ownership: 
Due to the risks involved in being a sole proprietor, one person companies might draw interested investors.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Is well-known in the market: 
One Person Companies draw qualified applicants to aid in the expansion of the business because they are comparable to Private Limited Companies.</li>
                                <li><i class="bi bi-check-circle-fill"></i> A single director is necessary: 
The One Person Company can be formed with just one Director.</li>
                                <li><i class="bi bi-check-circle-fill"></i>Ease in Managements: 
Management is simpler with a one-person company than with a private limited company.</li>
                                <li><i class="bi bi-check-circle-fill"></i>Offers its Member Limited Liability: 
By limiting responsibility from personal assets, it protects its shareholders in contrast to a sole proprietorship.</li>
                                <li><i class="bi bi-check-circle-fill"></i>Share Transferability in a Simple Way: 
Filling up the share transfer form and giving it to the buyer of the shares is all that is necessary to transfer shares in a One Person Company.</li>
                                
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-2.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 2 -->

                <div class="tab-pane" id="tab-3" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Eligibility Criteria for Converting Pvt Ltd to One Person Company </h3>
                            <p class="fst-italic">
                            The following requirements must be met before you are permitted to Private Limited to a One Person Company.
                            </p>
                            <ul>
                                <li><i class="bi bi-check-circle-fill"></i> The decision to convert should be approved by all of the directors.
                                   </li>
                                   
                                <li><i class="bi bi-check-circle-fill"></i> To the extent that you can defend this conversion—which is, to be honest, a downgrade—your net worth should have been severely decreased.</li>
                                
                                <li><i class="bi bi-check-circle-fill"></i> In the event of your death or incapacitation, you must designate a nominee who will manage your one-person business. </li>
                                <li><i class="bi bi-check-circle-fill"></i> Before proceeding with this conversion, you must receive the consent of your creditors. </li>
                                <li><i class="bi bi-check-circle-fill"></i> The directors of your private limited company must certify in an affidavit that they are willing to resign from their positions in order for your firm to be changed to a one-person company. </li>

                            </ul>
                            
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-3.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 3 -->

                <div class="tab-pane" id="tab-4" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Process of converting Pvt Ltd to Public Ltd</h3>
                            <p class="fst-italic">
                            An overview of the conversion process into a public limited company in accordance with the relevant provisions of the Companies Act of 2013 and the Companies (Incorporation) Rules of 2014 is provided below for your understanding:-
                            </p>
                            
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> Conducting a board meeting and discussing the items on the agenda:

To accept, subject to the consent of the shareholders, the conversion of Pvt. Ltd. to Public Limited.
Subject to the consent of the shareholders, to approve a new set of articles and the memorandum of association.</li>
                                <li><i class="bi bi-check-circle-fill"></i> The announcement of the general meeting.

Giving members at least 21 days' notice before the meeting
A general meeting may be convened with less notice if written or electronic permission from 95% of the members or more is obtained. 
To cast a vote at such a meeting.</li>
                                
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-4.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 4 -->

                <div class="tab-pane" id="tab-5" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Documents required for converting Pvt Ltd to One Person Company</h3>
                            <p class="fst-italic">
                            The following attachments must be filed with a copy of the Special Resolution at the Registrar of Companies:

                            </p>
                            
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> Notice of Extra General Meeting (EGM), which was conducted to obtain Directors' consent for the Private Limited Company's conversion to a One Person Company.</li>
                                <li><i class="bi bi-check-circle-fill"></i> Original copy of the Special Resolution</li>
                                <li><i class="bi bi-check-circle-fill"></i> Modified Articles of Association</li>
                                <li><i class="bi bi-check-circle-fill"></i> Articles of Association Modification</li>
                                <li><i class="bi bi-check-circle-fill"></i> It is optional to submit a real certified copy of the Board Resolution.</li>
                                <li><i class="bi bi-check-circle-fill"></i> E- Form INC 6</li>
                                <li><i class="bi bi-check-circle-fill"></i> Application for a Private Limited Company to Change to a One Person Company with the Required Attachments:</li>
                                <li><i class="bi bi-check-circle-fill"></i> List of all participants and debtors</li>
                                <li><i class="bi bi-check-circle-fill"></i> Most recent balance sheet</li>
                                <li><i class="bi bi-check-circle-fill"></i> No Objection' letter from the creditors and members</li>
                                <li><i class="bi bi-check-circle-fill"></i> Affidavit-based letter of consent from the directors</li>
                                <li><i class="bi bi-check-circle-fill"></i> Process for Converting Pvt Ltd to One Person Company</li>
                                <li><i class="bi bi-check-circle-fill"></i> Call a Board of Directors EGM.</li>
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-5.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 5 -->

                <div class="tab-pane" id="tab-6" role="tabpanel">
                    <div class="row gy-4">
                        <div class="col-lg-8 order-2 order-lg-1">
                            <h3>Document Required for Start Company</h3>
                            
                           
                            <ul class="fst-italic">
                                <li><i class="bi bi-check-circle-fill"></i> Original copy of the Special Resolution</li>
                                <li><i class="bi bi-check-circle-fill"></i> Articles of Association Modification</li>
                                <li><i class="bi bi-check-circle-fill"></i> List of all participants and debtors</li>
                            </ul>
                        </div>
                        <div class="col-lg-4 order-1 order-lg-2 text-center">
                            <img src="assets/img/features-6.svg" alt="" class="img-fluid">
                        </div>
                    </div>
                </div><!-- End Tab Content 6 -->

            </div>

        </div>
    </section>



{{-- contant wala section end --}}

{{-- yellow wala whatsapp wala start --}}
{{-- <div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">
          <h4 class="ft-600 text-white ft-20">In case you have any query, please email us at <a class="text-white ft-700" href="mailto:info@hubco.in">info@hubco.in</a></h4>
        </div>
      </div>
    </div>
  </div>
</div> --}}
{{-- yellow wala whatsapp wala end --}}



{{-- our client start --}}
{{-- 
<div class="clients-slider swiper swiper-initialized swiper-horizontal swiper-pointer-events">
  <h1 style = "margin-left: 41%"> OUR CUSTOMER</h1>
  <div class="swiper-wrapper align-items-center" id="swiper-wrapper-146543cd5d3b2779" aria-live="off" style="transform: translate3d(-2472px, 0px, 0px); transition-duration: 0ms;"><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-active" data-swiper-slide-index="6" role="group" aria-label="7 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-7.png" class="img-fluid" alt=""></div>
    <div class="swiper-slide swiper-slide-next" data-swiper-slide-index="7" role="group" aria-label="8 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-8.png" class="img-fluid" alt=""></div>
  <div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="0" role="group" aria-label="1 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-1.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="1" role="group" aria-label="2 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-2.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="2" role="group" aria-label="3 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-3.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="3" role="group" aria-label="4 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-4.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate" data-swiper-slide-index="4" role="group" aria-label="5 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-5.png" class="img-fluid" alt=""></div><div class="swiper-slide swiper-slide-duplicate swiper-slide-duplicate-prev" data-swiper-slide-index="5" role="group" aria-label="6 / 8" style="width: 86px; margin-right: 120px;"><img src="assets/img/clients/client-6.png" class="img-fluid" alt=""></div></div>
<span class="swiper-notification" aria-live="assertive" aria-atomic="true"></span></div>

 --}}

{{-- our client end --}}

<!-- {{-- new feature start yellow wala  start--}}

<div class="container-fluid p-4 bg-orange">
  <div class="container">
    <div class="row bg-orange padding-20 text-center">
      <div class="bordered">
        <div class="col-xs-12">


          <div class="p-l-5">
    <P>Subscribe for free magazine and our startup network.</P>

        </div>
        <div class="d-flex flex-nowrap">
        <form class="form-inline">
         
          <div class="form-group order-3 p-2  ">
            <label for="inputPassword2" class="sr-only"></label>
            <input type="text" class="form-control" id="inputPassword2" placeholder="your.email@domain.com">
          </div>
          <div class = "order-3 p-2" >
          <button type="submit" class="btn btn-primary btn-sm">Confirm identit</button>
      </div>
    </div>  
        </form>

      
      </div>
      </div>
    </div>
  </div>
</div>

 {{-- new feature start yellow wala end --}} -->



{{-- Faq --}}
<section id="faq" class="faq">
  <div class="container-fluid aos-init aos-animate" data-aos="fade-up">

    <div class="row gy-4">

      <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">

        <div class="content px-xl-5">
          <h3>Frequently Asked <strong>Questions</strong></h3>
       
        </div> 

        <div class="accordion accordion-flush px-xl-5" id="faqlist">

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="200">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-1">
                <i class="bi bi-question-circle question-icon"></i>
                Who in the government has the right to change PVT LTD into OPC?
              </button>
            </h3>
            <div id="faq-content-1" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              Corporate Affairs Ministry
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="300">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-2">
                <i class="bi bi-question-circle question-icon"></i>
                What prerequisites must be met before a Private Limited Company may become a One Person Company?
              </button>
            </h3>
            <div id="faq-content-2" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              You must meet the requirements outlined in the eligibility section of this page before being permitted to Private Limited to a One Person Company.
              </div>
            </div>
          </div><!-- # Faq item-->

          <div class="accordion-item aos-init aos-animate" data-aos="fade-up" data-aos-delay="400">
            <h3 class="accordion-header">
              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-3">
                <i class="bi bi-question-circle question-icon"></i>
                Can an OPC employ people?
              </button>
            </h3>
            <div id="faq-content-3" class="accordion-collapse collapse" data-bs-parent="#faqlist">
              <div class="accordion-body">
              The number of shareholders that can register as an OPC, excluding employees and directors, is fifty. OPC Asset Solutions employs between 51 and 200 people in India.
              </div>
            </div>
          </div><!-- # Faq item-->

         
        </div>

      </div>

      <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img" style="background-image: url(&quot;assets/img/faq.jpg&quot;);">&nbsp;</div>
    </div>

  </div>
</section>


    @include('home-sections.recent-blog-posts')




  {{-- cdn file bootstrap --}}
 
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script>

@stop
