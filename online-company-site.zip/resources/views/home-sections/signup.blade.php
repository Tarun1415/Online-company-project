@extends('layouts.default-new')

@section('content')

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">

    <link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet" />


    {{-- stariting wala yellow color start --}}
    </div>


    <div id="app">
        <div class="main-wrapper">
            <section class="section" id="form_bg_color">
                <div class="container container-login">
                    <div class="row">
                        <div
                            class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
                            <div class="card card-primary border-box">
                                <div class="card-header card-header-auth">
                                    <h4 class="text-center">Sign Up</h4>
                                </div>
                                <div class="card-body card-body-auth">

                                    @if (session()->get('success'))
                                        <div class="text-success">{{ session()->get('success') }}</div>
                                    @endif

                                    <form method="post" action="/registerOnline" enctype='multipart/form-data'
                                        id="">
                                        @csrf
                                        <div class="form-group">
                                            <input type="text" placeholder="Enter Name*" id="nameID"
                                                class="form-control phone-mask @error('user_name') is-invalid @enderror"
                                                name="user_name" autofocus="">
                                            @error('user_name')
                                                <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                            @if (session()->get('error'))
                                                <div class="text-danger">{{ session()->get('error') }}</div>
                                            @endif
                                        </div>
                                        <div class="form-group">
                                            <input type="text" placeholder="Enter Email*" id="emailID"
                                                class="form-control phone-mask @error('user_email') is-invalid @enderror"
                                                name="user_email">
                                            @error('user_email')
                                                <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                            @if (session()->get('error'))
                                                <div class="text-danger">{{ session()->get('error') }}</div>
                                            @endif
                                        </div>
                                        <div class="form-group">

                                            <input type="text" id="basic-default-phone" name="user_contact_number"
                                                pattern="[6-9]{1}[0-9]{9}"
                                                class="form-control phone-mask @error('user_email') is-invalid @enderror"
                                                placeholder="658 799 8941" aria-label="658 799 8941"
                                                aria-describedby="basic-default-phone">

                                            @error('user_contact_number')
                                                <div class="text-danger">{{ $message }}</div>
                                            @enderror
                                            @if (session()->get('error'))
                                                <div class="text-danger">{{ session()->get('error') }}</div>
                                            @endif

                                        </div>

                                        <div class="form-group" id="btn-cen">
                                            <!-- <button type="submit" id="show_hide" onClick="showLogout()" class="btn btn-primary btn-lg btn-block">
                                                                        Login
                                                                    </button> -->
                                            <button type="submit" class="button btn-submit btn-warning">SUBMIT</button>
                                        </div>
                                        <div class="form-group">
                                            <div>
                                                <!-- <a href="">
                                                            Forget Password?
                                                        </a> -->
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>



    @include('home-sections.features')
    @include('home-sections.cta')
    @include('home-sections.onfocus')
    @include('home-sections.services')
    @include('home-sections.faq')
    @include('home-sections.recent-blog-posts')


    {{-- cdn file bootstrap --}}

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>

@stop
