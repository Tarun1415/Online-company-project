@extends('layouts.default-new')
@section('content')

<h1>hello</h1>


    @stop