@extends('layouts.default-new')

        @section('content')
      
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    
    <link href="{{ asset('assets/css/companyregistration.css') }}" rel="stylesheet" />

  
    {{-- stariting wala yellow color start --}}
  </div>




<section id="recent-blog-posts" class="recent-blog-posts">

<div class="container" data-aos="fade-up">

  <div class="section-header">
    <h2 id="head-para">Privacy Policy</h2>
    <p id="head-para" class="fst-italic">Online Company. (hereinafter “onllinecompany.com or we/our, including www.onlinecompany.com and the onlinecompany mobile application”) recognizes the importance of privacy.This privacy policy (hereinafter referred to as the “Policy”) therefore explains how we protect the personal data provided to us on our website www.onlinecompany.com  (hereinafter referred to as the “Site”) or via the mobile application and how this information is part of a service offered through the Website (hereinafter referred to as the "Service") online company is committed to maintaining the confidentiality, integrity and security of all information from our users.
</p>
<p id="head-para" class="fst-italic">Online Company is a professional services provider and is in a way affiliated with a government or governmental agency, regulator or credit reporting agency. The information contained on this website does not guarantee the correctness of the content, details and calculations. Information is subject to change without notice.
</p>
<p id="head-para" class="fst-italic">This notice has been issued and is to be construed in accordance with the provisions of the Information Technology Principles (Reasonable Security Practices and Procedures and Sensitive Personal Information) 2011 under the Information Technology Act 2000 and other applicable laws and regulations requiring disclosure of privacy practices in the collection, use, retention, disclosure and transmission of sensitive personal data or information.
</p>
  </div>


</div>

</section>



@include('home-sections.features')
@include('home-sections.cta')
@include('home-sections.onfocus')
@include('home-sections.services')
@include('home-sections.faq')
@include('home-sections.recent-blog-posts')

  {{-- cdn file bootstrap --}}
 
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
  integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
</script>

@stop
