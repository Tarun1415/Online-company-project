  <!-- ======= Features Section ======= -->
  <section id="features" class="features">
    <div class="container" data-aos="fade-up">

      <ul class="nav nav-tabs row gy-4 d-flex">

        <li class="nav-item col-6 col-md-4 col-lg-2">
          <a class="nav-link active show" data-bs-toggle="tab" data-bs-target="#tab-1">
            <i class="bi bi-building-fill-gear"></i>
            <h4>Company Registration</h4>
          </a>
        </li><!-- End Tab 1 Nav -->

        <li class="nav-item col-6 col-md-4 col-lg-2">
          <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-2">
            <i class="bi bi-file-earmark-richtext-fill"></i>
            <h4>Licenses & Registrations</h4>
          </a>
        </li><!-- End Tab 2 Nav -->

        <li class="nav-item col-6 col-md-4 col-lg-2">
          <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-3">
            <i class="bi bi-folder-check"></i>
            <h4>Corporate Compliance</h4>
          </a>
        </li><!-- End Tab 3 Nav -->

        <li class="nav-item col-6 col-md-4 col-lg-2">
          <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-4">
            <i class="bi bi-buildings-fill"></i>
            <h4>Convert Your Business</h4>
          </a>
        </li><!-- End Tab 4 Nav -->

        <li class="nav-item col-6 col-md-4 col-lg-2">
          <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-5">
            <i class="bi bi-card-checklist"></i>
            <h4>Labour Compliance</h4>
          </a>
        </li><!-- End Tab 5 Nav -->

        <li class="nav-item col-6 col-md-4 col-lg-2">
          <a class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-6">
            <i class="bi bi-person-vcard-fill"></i>
            <h4>GST and Other Indirect Tax</h4>
          </a>
        </li><!-- End Tab 6 Nav -->

      </ul>

      <div class="tab-content">

        <div class="tab-pane active show" id="tab-1">
          <div class="row gy-4">
            <div class="col-lg-8 order-2 order-lg-1" data-aos="fade-up" data-aos-delay="100">

              <div class="accordion accordion-flush px-xl-5" id="ocrlist">
                <h3>Online Company Registration</h3>
                <p>Online company registration is the procedure for incorporating an existing firm or registering a new one using a website or online platform.</p>
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="200">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ocr-content-1">
                      Private Limited Company
                    </button>
                  </h3>
                  <div id="ocr-content-1" class="accordion-collapse collapse" data-bs-parent="#ocrlist">
                    <div class="accordion-body">
                      A particular sort of business structure that is registered as a different legal entity from its owners is a private limited company. It can raise money by issuing shares, has a distinct legal character, and limits on shareholder liability.
                    </div>
                  </div>
                </div><!-- # Faq item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="300">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ocr-content-2">
                      
                      Limited Liability Partnership
                    </button>
                  </h3>
                  <div id="ocr-content-2" class="accordion-collapse collapse" data-bs-parent="#ocrlist">
                    <div class="accordion-body">
                      The flexibility of a partnership and limited liability protection offered by a company are combined in an LLP, a sort of corporate structure. It has a distinct legal identity and is registered as a separate legal entity from its partners.
                    </div>
                  </div>
                </div><!-- # Faq item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ocr-content-3">
                      
                      One Person Company
                    </button>
                  </h3>
                  <div id="ocr-content-3" class="accordion-collapse collapse" data-bs-parent="#ocrlist">
                    <div class="accordion-body">
                      An OPC is a sort of corporate structure that enables a one person to own and manage a corporation. It has a different legal personality from its owner and is registered as a separate legal entity.
                    </div>
                  </div>
                </div><!-- # ocr item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="500">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ocr-content-4">
                      
                      Sole Proprietorship
                    </button>
                  </h3>
                  <div id="ocr-content-4" class="accordion-collapse collapse" data-bs-parent="#ocrlist">
                    <div class="accordion-body">
                      A business structure called a sole proprietorship allows one person to own and run the company. The owner is legally liable for all of the company's obligations and liabilities, and there is no separation between the owner and the business. 
                    </div>
                  </div>
                </div><!-- # ocr item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="600">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ocr-content-5">
                      
                      Nidhi Company
                    </button>
                  </h3>
                  <div id="ocr-content-5" class="accordion-collapse collapse" data-bs-parent="#ocrlist">
                    <div class="accordion-body">
                      A Nidhi business is a non-banking financial business (NBFC) that was established with the sole aim of encouraging its members to practice frugal living and conserving money
                    </div>
                  </div>
                </div>
                
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="600">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ocr-content-6">
                      
                      Producer Company
                    </button>
                  </h3>
                  <div id="ocr-content-6" class="accordion-collapse collapse" data-bs-parent="#ocrlist">
                    <div class="accordion-body">
                      A producer company is a particular kind of business created by 10 or more people who are either actively producing primary produce or have the intention of engaging in any activity linked to primary produce
                    </div>
                  </div>
                </div>


                <div class="accordion-item" data-aos="fade-up" data-aos-delay="600">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ocr-content-7">
                      Partnership Firm
                    </button>
                  </h3>
                  <div id="ocr-content-7" class="accordion-collapse collapse" data-bs-parent="#ocrlist">
                    <div class="accordion-body">
                      When two or more people jointly own and run a business, this sort of business organization is known as a partnership firm.
                    </div>
                  </div>
                </div>
                
                <!-- # Faq item-->
    
              </div>
    

            </div>
            <div class="col-lg-4 order-1 order-lg-2 text-center" data-aos="fade-up" data-aos-delay="0">
              <img src="assets/img/features-1.png" alt="" class="img-fluid">
              <button class="btn btn-primary btn-round mt-4" style="background-color:var(--color-primary)" data-bs-toggle="modal" data-bs-target="#exampleModalCenter">Get Details</button>
            </div>
          </div>
        </div><!-- End Tab Content 1 -->

        <div class="tab-pane" id="tab-2">
          <div class="row gy-4">
            <div class="col-lg-8 order-2 order-lg-1">


              <div class="accordion accordion-flush px-xl-5" id="lrslist">
                <h3>Licenses & Registrations</h3>
                <p>Depending on the sort of business and the sector it serves, different licences and registrations may be needed to launch it. Business licences, tax registrations, permits for particular operations, and certifications and licences specific to certain industries are a few examples of common licences and registrations.</p>
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="200">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lrs-content-1">
                      Digital Signature Certificate
                    </button>
                  </h3>
                  <div id="lrs-content-1" class="accordion-collapse collapse" data-bs-parent="#lrslist">
                    <div class="accordion-body">
                      An electronic signature that is used to verify the signer's identity and guarantee the truthfulness of the document or message being signed is known as a digital signature certificate.
                    </div>
                  </div>
                </div><!-- # Faq item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="300">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lrs-content-2">
                      
                      MSME/SSI Registration
                    </button>
                  </h3>
                  <div id="lrs-content-2" class="accordion-collapse collapse" data-bs-parent="#lrslist">
                    <div class="accordion-body">
                      Small and medium-sized businesses can register with the government through the MSME/SSI Registration process to take advantage of the many incentives and programmes offered by the government
                    </div>
                  </div>
                </div><!-- # Faq item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lrs-content-3">
                      
                      ISO Certification
                    </button>
                  </h3>
                  <div id="lrs-content-3" class="accordion-collapse collapse" data-bs-parent="#lrslist">
                    <div class="accordion-body">
                      Through the ISO Certification process, a business can receive certification from the International Organisation for Standardisation (ISO) for adhering to particular quality management requirements.
                    </div>
                  </div>
                </div><!-- # lrs item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="500">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lrs-content-4">
                      
                      FSSAI Registration Online
                    </button>
                  </h3>
                  <div id="lrs-content-4" class="accordion-collapse collapse" data-bs-parent="#lrslist">
                    <div class="accordion-body">
                      According to the Food Safety and Standards Act of 2006, all enterprises in India that deal with food are required to register with the FSSAI. It guarantees that the company's food items are produced, stored, or delivered in accordance with particular safety requirements. 
                    </div>
                  </div>
                </div><!-- # lrs item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="600">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lrs-content-5">
                      
                      IEC [Import/Export Code]
                    </button>
                  </h3>
                  <div id="lrs-content-5" class="accordion-collapse collapse" data-bs-parent="#lrslist">
                    <div class="accordion-body">
                      Businesses that import or export goods or services from India are given an Import/Export designation (IEC), a 10-digit designation, by the Directorate General of Foreign Trade (DGFT).
                    </div>
                  </div>
                </div>
                
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="600">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lrs-content-6">
                      
                      BIS Registration
                    </button>
                  </h3>
                  <div id="lrs-content-6" class="accordion-collapse collapse" data-bs-parent="#lrslist">
                    <div class="accordion-body">
                      The Bureau of Indian criteria (BIS) can certify a product as satisfying specific quality and safety criteria through the BIS Registration process.
                    </div>
                  </div>
                </div>
                
                <!-- # Faq item-->
    
              </div>

            </div>
            <div class="col-lg-4 order-1 order-lg-2 text-center">
              <img src="assets/img/features-2.svg" alt="" class="img-fluid">
              <button class="btn btn-primary btn-round mt-4" style="background-color:var(--color-primary)" data-bs-toggle="modal" data-bs-target="#exampleModalCenter">Get Details</button>
            </div>
          </div>
        </div><!-- End Tab Content 2 -->


        <div class="tab-pane" id="tab-3">
          <div class="row gy-4">
            <div class="col-lg-8 order-2 order-lg-1">


              <div class="accordion accordion-flush px-xl-5" id="ccslist">
                <h3>Corporate Compliance</h3>
                <p> Corporate compliance is the collection of rules, guidelines, and practices that a company uses to make sure it complies with all applicable laws, rules, and moral principles.</p>
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="200">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ccs-content-1">
                      Annual Auditing - with proper reciept                    
                    </button>
                  </h3>
                  <div id="ccs-content-1" class="accordion-collapse collapse" data-bs-parent="#ccslist">
                    <div class="accordion-body">
                      A company's financial records and transactions are examined annually to make sure they are accurate and compliant with accounting rules.
                    </div>
                  </div>
                </div><!-- # Faq item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="300">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ccs-content-2">
                      RBI Compliance
                    </button>
                  </h3>
                  <div id="ccs-content-2" class="accordion-collapse collapse" data-bs-parent="#ccslist">
                    <div class="accordion-body">
                      RBI Compliance is the term used to describe the set of rules and directives that the Reserve Bank of India (RBI) has given and that all Indian banks and financial institutions must abide by in order to conduct themselves morally and lawfully.
                    </div>
                  </div>
                </div><!-- # Faq item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#ccs-content-3">
                      
                      Balance Sheet Preparation and matching with annual auditing                   
                     </button>
                  </h3>
                  <div id="ccs-content-3" class="accordion-collapse collapse" data-bs-parent="#ccslist">
                    <div class="accordion-body">
                     A balance sheet is a type of financial statement that gives a quick overview of a company's financial situation at one particular time. It displays the assets, liabilities, and equity of the business.

                    </div>
                  </div>
                </div><!-- # ccs item-->
                <!-- # Faq item-->
    
              </div>

            </div>
            <div class="col-lg-4 order-1 order-lg-2 text-center">
              <img src="assets/img/features-3.svg" alt="" class="img-fluid">
              <button class="btn btn-primary btn-round mt-4" style="background-color:var(--color-primary)" data-bs-toggle="modal" data-bs-target="#exampleModalCenter">Get Details</button>
            </div>
          </div>
        </div><!-- End Tab Content 3 -->

        <div class="tab-pane" id="tab-4">
          <div class="row gy-4">
            <div class="col-lg-8 order-2 order-lg-1">


              <div class="accordion accordion-flush px-xl-5" id="cybslist">
                <h3>Convert your business
                </h3>
                <p> Conver your business to other firm.
                </p>
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="200">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#cybs-content-1">
                      Proprietorship to Pvt Ltd Company
                    </button>
                  </h3>
                  <div id="cybs-content-1" class="accordion-collapse collapse" data-bs-parent="#cybslist">
                    <div class="accordion-body">
                      <p> A Proprietorship can become a Private Limited Company for a number of reasons, including:As a Private Limited Company, the owners' or shareholders' liability is constrained to the value of their ownership stake. In the event that the business experiences financial difficulties, this means that the owners' personal assets are safeguarded.</p>
                      <p>
                        Additional sources of funding A Private Limited Company can raise money for the firm by selling shares and soliciting investments. Enhanced credibility: A Private Limited Company has a distinct legal identity, which can boost its standing in the marketplace.
                        </p>
                    </div>
                  </div>
                </div><!-- # Faq item-->
    
                {{-- <div class="accordion-item" data-aos="fade-up" data-aos-delay="300">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#cybs-content-2">
                      
                      Compliance Check - Secretarial Audit.                   
                     </button>
                  </h3>
                  <div id="cybs-content-2" class="accordion-collapse collapse" data-bs-parent="#cybslist">
                    <div class="accordion-body">
                      Secretarial Audit is an independent review of a company's compliance with legal and regulatory requirements under the Companies Act, 2013 and other applicable laws. It focuses on the company's compliance with various provisions of the law and helps to identify any non-compliance and suggest corrective actions.
                    </div>
                  </div>
                </div><!-- # Faq item--> --}}
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#cybs-content-3">
                      Partnership to LLP                 
                     </button>
                  </h3>
                  <div id="cybs-content-3" class="accordion-collapse collapse" data-bs-parent="#cybslist">
                    <div class="accordion-body">
                      As an LLP, the liability of the partners is limited to the amount of their contribution. This means that the personal assets of the partners are protected in case the LLP faces financial difficulties.                   
                     </div>
                  </div>
                </div><!-- # cybs item-->

                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#cybs-content-4">
                      Private to Public Limited Company                    
                     </button>
                  </h3>
                  <div id="cybs-content-4" class="accordion-collapse collapse" data-bs-parent="#cybslist">
                    <div class="accordion-body">
                      More funding opportunities: A Public Limited Company can raise funds from the public by issuing shares, which can be beneficial for expanding the business.                  
                     </div>
                  </div>
                </div><!-- # cybs item-->


                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#cybs-content-5">
                      Private Limited to One Person Company               
                     </button>
                  </h3>
                  <div id="cybs-content-5" class="accordion-collapse collapse" data-bs-parent="#cybslist">
                    <div class="accordion-body">
                    <ul>
                    <li>Tax Benefits: An OPC is taxed like any other company, which can provide tax benefits compared to a sole proprietorship.</li>  
                    <li>
                      Separate Legal Entity: An OPC is a separate legal entity from its owner, which can improve its credibility and reputation in the market.
                    </li>
                    <li>
                      Limited Liability: As an OPC, the liability of the sole shareholder is limited to the extent of his/her shareholding.
                    </li>
                    </ul>                 
                     </div>
                  </div>
                </div><!-- # cybs item-->

               
    
              </div>

            </div>
            <div class="col-lg-4 order-1 order-lg-2 text-center">
              <img src="assets/img/features-4.svg" alt="" class="img-fluid">
              <button class="btn btn-primary btn-round mt-4" style="background-color:var(--color-primary)" data-bs-toggle="modal" data-bs-target="#exampleModalCenter">Get Details</button>
            </div>
          </div>
        </div><!-- End Tab Content 4 -->

        <div class="tab-pane" id="tab-5">
          <div class="row gy-4">
            <div class="col-lg-8 order-2 order-lg-1">


              <div class="accordion accordion-flush px-xl-5" id="lcslist">
                <h3>Labour Compliance
                </h3>
                <p> Labour Compliance refers to the legal framework that governs the relationship between employers and employees. It includes various laws, rules, and regulations that ensure the protection of workers' rights and welfare.
                </p>
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="200">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lcs-content-1">
                      ESI Registration
                    </button>
                  </h3>
                  <div id="lcs-content-1" class="accordion-collapse collapse" data-bs-parent="#lcslist">
                    <div class="accordion-body">
                      ESI (Employee's State Insurance) Registration is a mandatory registration process that businesses with 10 or more employees (in some states, the threshold is 20 employees) need to undergo to provide health insurance benefits to their employees.
                    </div>
                  </div>
                </div><!-- # Faq item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="300">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lcs-content-2">
                      Provident Fund (PF) Registration                   
                     </button>
                  </h3>
                  <div id="lcs-content-2" class="accordion-collapse collapse" data-bs-parent="#lcslist">
                    <div class="accordion-body">
                      Provident Fund (PF) Registration is a mandatory registration process that businesses with 20 or more employees (in some states, the threshold is 10 employees) need to undergo to provide retirement benefits to their employees.
                    </div>
                  </div>
                </div><!-- # Faq item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lcs-content-3">
                      Professional Tax Registration               
                     </button>
                  </h3>
                  <div id="lcs-content-3" class="accordion-collapse collapse" data-bs-parent="#lcslist">
                    <div class="accordion-body">
                      Professional Tax is a tax levied by state governments on salaried employees, professionals, and traders for practicing their profession or conducting their business.                   
                     </div>
                  </div>
                </div><!-- # lcs item-->

                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lcs-content-4">
                      Shops and Establishments License                   
                     </button>
                  </h3>
                  <div id="lcs-content-4" class="accordion-collapse collapse" data-bs-parent="#lcslist">
                    <div class="accordion-body">
                      A Shops and Establishments License is a mandatory registration that all businesses operating within a state must obtain. This license is issued by the respective state government and is meant to regulate the working conditions of employees in shops, commercial establishments, and other businesses.                 
                     </div>
                  </div>
                </div><!-- # lcs item-->


                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lcs-content-5">
                      Employee Stock Option Plan [ESOP]               
                     </button>
                  </h3>
                  <div id="lcs-content-5" class="accordion-collapse collapse" data-bs-parent="#lcslist">
                    <div class="accordion-body">
                      An Employee Stock Option Plan (ESOP) is a program that allows employees of a company to purchase a certain number of company shares at a discounted price.               
                     </div>
                  </div>
                </div><!-- # lcs item-->


                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#lcs-content-6">
                      POSH Compliance                     
                    </button>
                  </h3>
                  <div id="lcs-content-6" class="accordion-collapse collapse" data-bs-parent="#lcslist">
                    <div class="accordion-body">
                      POSH Compliance refers to compliance with the Prevention of Sexual Harassment (POSH) of Women at the Workplace Act, 2013. This act mandates that all employers in India with more than 10 employees implement policies and procedures to prevent sexual harassment in the workplace.
                     </div>
                  </div>
                </div><!-- # lcs item-->

               
    
              </div>

            </div>
            <div class="col-lg-4 order-1 order-lg-2 text-center">
              <img src="assets/img/features-5.svg" alt="" class="img-fluid">
              <button class="btn btn-primary btn-round mt-4" style="background-color:var(--color-primary)" data-bs-toggle="modal" data-bs-target="#exampleModalCenter">Get Details</button>
            </div>
          </div>
        </div><!-- End Tab Content 5 -->

        <div class="tab-pane" id="tab-6">
          <div class="row gy-4">
            <div class="col-lg-8 order-2 order-lg-1">


              <div class="accordion accordion-flush px-xl-5" id="tandotherlist">
                <h3>
                  GST and All other Taxs
                </h3>
                <p>  GST (Goods and Services Tax) is an indirect tax that is levied on the supply of goods and services in India. It was implemented on July 1, 2017, to replace multiple indirect taxes such as Central Excise Duty, Service Tax, Value Added Tax (VAT), etc.
                </p>
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="200">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tandother-content-1">
                      GST Registration
                    </button>
                  </h3>
                  <div id="tandother-content-1" class="accordion-collapse collapse" data-bs-parent="#tandotherlist">
                    <div class="accordion-body">
                      Any business or individual that engages in the supply of goods or services in India and has an annual turnover exceeding Rs. 40 lakhs (for goods suppliers) or Rs. 20 lakhs (for service providers) is required to register for GST.
                    </div>
                  </div>
                </div><!-- # Faq item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="300">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tandother-content-2">
                      GST Filing                   
                     </button>
                  </h3>
                  <div id="tandother-content-2" class="accordion-collapse collapse" data-bs-parent="#tandotherlist">
                    <div class="accordion-body">
                      GST Filing refers to the process of filing GST returns on the GST portal. It involves furnishing details of sales, purchases, and tax paid to the government for a specific period.
                    </div>
                  </div>
                </div><!-- # Faq item-->
    
                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tandother-content-3">
                      GST Advisory              
                     </button>
                  </h3>
                  <div id="tandother-content-3" class="accordion-collapse collapse" data-bs-parent="#tandotherlist">
                    <div class="accordion-body">
                      GST Advisory is a service provided by professionals to help businesses comply with the GST laws and regulations. It involves providing advice and guidance on various aspects of GST, such as registration, filing returns, availing input tax credit, etc.                  
                     </div>
                  </div>
                </div><!-- # tandother item-->

                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tandother-content-4">
                      TDS Return Filing                  
                     </button>
                  </h3>
                  <div id="tandother-content-4" class="accordion-collapse collapse" data-bs-parent="#tandotherlist">
                    <div class="accordion-body">
                      TDS (Tax Deducted at Source) Return Filing refers to the process of filing the details of TDS deducted and deposited by a business or individual to the Income Tax Department.
                     </div>
                  </div>
                </div><!-- # tandother item-->


                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tandother-content-5">
                      Individual Income Tax Filing              
                     </button>
                  </h3>
                  <div id="tandother-content-5" class="accordion-collapse collapse" data-bs-parent="#tandotherlist">
                    <div class="accordion-body">
                      Individual Income Tax Filing refers to the process of filing income tax returns by individuals for the income earned during a financial year.              
                     </div>
                  </div>
                </div><!-- # tandother item-->


                <div class="accordion-item" data-aos="fade-up" data-aos-delay="400">
                  <h3 class="accordion-header">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tandother-content-6">
                      Proprietorship Tax Return Filing                   
                    </button>
                  </h3>
                  <div id="tandother-content-6" class="accordion-collapse collapse" data-bs-parent="#tandotherlist">
                    <div class="accordion-body">
                      Proprietorship Tax Return Filing refers to the process of filing income tax returns by sole proprietors for the income earned by their business during a financial year.
                     </div>
                  </div>
                </div><!-- # tandother item-->
              </div>

            </div>
            <div class="col-lg-4 order-1 order-lg-2 text-center">
              <img src="assets/img/features-6.svg" alt="" class="img-fluid">
              <button class="btn btn-primary btn-round mt-4" style="background-color:var(--color-primary)" data-bs-toggle="modal" data-bs-target="#exampleModalCenter">Get Details</button>
            </div>
          </div>
        </div><!-- End Tab Content 6 -->
      </div>

    </div>
  </section><!-- End Features Section -->