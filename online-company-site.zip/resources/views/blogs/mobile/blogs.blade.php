@extends('layouts.default-new')
@section('content')




<main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          
          <ol>
            <li><a href="/">Home</a></li>
            <li><a href="#">Blog</a></li>
            <li>Blog Details</li>
          </ol>
        </div>

      </div>
    </div><!-- End Breadcrumbs -->

    <!-- ======= Blog Details Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">

        <div class="row g-5">
          <h2 class="title">{{$basic_detais[0]['post_display_name']}}</h2>

          <div class="col-lg-8">


              <div class="post-img">
                <img src="{{asset('upload/blogs/'. $basic_detais[0]['featured_img'])}}" alt="" class="img-fluid" width="100%">
              </div>

             


          </div>


              <div class="col-12">
                <article class="blog-details">

                <div class="meta-top">
                  <ul>
                    <li class="d-flex align-items-center"><i class="bi bi-person"></i> Online Company</li>
                    <li class="d-flex align-items-center"><i class="bi bi-clock"></i> <time datetime="{{ $basic_detais[0]['post_create_date'] }}">{{ \Carbon\Carbon::parse($basic_detais[0]['post_create_date'])->format('M d, Y') }}</time></li>

                    {{-- <li class="d-flex align-items-center"><i class="bi bi-chat-dots"></i> <a href="#">12 Comments</a></li> --}}
                  </ul>
                </div><!-- End meta top -->
  
             <div class="content">
              {{-- <div class="entry-content clr" itemprop="text">
                  <div class="at-above-post addthis_tool" data-url="https://onlinecompany.co.in/all-about-section-12aa-registration/"></div>
              <p>{{$basic_detais[0]['short_info']}}</p> --}}
              <div class="entry-content clr" itemprop="text">
                <div class="at-above-post addthis_tool" data-url="https://onlinecompany.co.in/all-about-section-12aa-registration/"></div>
                <p>{!! $basic_detais[0]['short_info'] !!}</p>
            
            
              
              
              
              
              
              
              
              </div>    
          </div>
              </div>

                </article>

            </div><!-- End Blog Sidebar -->

          </div>
        </div>

      </div>




    
      <div class="col-lg-4">

        <div class="sidebar">


          <div class="sidebar-item recent-posts">
            <h3 class="sidebar-title">Recent Posts</h3>
           
            @foreach($blogs as $blog)
            <div class="mt-3">
              <div class="post-item mt-3">
                <img src="{{asset('upload/blogs/'. $blog['featured_img'])}}" alt="" class="flex-shrink-0">
                <div>
                  <h4><a href="{{url('')}}/blogs/{{$blog['post_url']}}">{{$blog['post_display_name']}}</a></h4>
                  <time datetime="{{ $blog['post_create_date'] }}">{{ \Carbon\Carbon::parse($blog['post_create_date'])->format('M d, Y') }}</time>

                </div>
              </div>
                </div>
@endforeach
              </div>


              

            </div>

          </div><!-- End sidebar recent posts-->



    </section><!-- End Blog Details Section -->




    

  </main><!-- End #main -->









@stop